import { memo, useCallback, useEffect, useRef, useState } from 'react';
import FleetMapModule from '../components/FleetMapModule';
import type {
  DailyFleetStatusPoint,
  FleetAlert,
  FleetGeofence,
  FleetVehicle,
  VehicleCategory,
  MaintenanceRule,
  ServiceLog,
  VehicleMaintenanceStatus,
  FleetMission,
  MissionStatus,
  FuelLog,
  VehicleFuelAnalytics,
  FleetFuelSummary,
} from './types';

export interface HamiFleetModuleProps {
  /** Optional API prefix if mounted on custom subpath, default is '' (calling /api/...) */
  apiBaseUrl?: string;
  className?: string;
  onVehicleSelected?: (vehicle: FleetVehicle) => void;
  onDriverSynced?: (vehicleCode: string, driverName: string) => void;
  onMissionStatusChanged?: (missionId: string, status: MissionStatus) => void;
}

const categorySet: VehicleCategory[] = ['khavar', 'hyundai', 'isuzu', 'nissan', 'other'];
const EMPTY_DRIVERS: never[] = [];
const EMPTY_MAINTENANCE: never[] = [];

const FLEET_CATEGORY_CONFIG = {
  khavar: { label: 'خاور', color: '#2563eb', icon: 'خ' },
  hyundai: { label: 'هیوندای', color: '#7c3aed', icon: 'هـ' },
  isuzu: { label: 'ایسوزو', color: '#0d9488', icon: 'ا' },
  nissan: { label: 'نیسان', color: '#d97706', icon: 'ن' },
  other: { label: 'سایر', color: '#475569', icon: 'س' },
};

function sameShallow(a: Record<string, unknown>, b: Record<string, unknown>) {
  const aKeys = Object.keys(a);
  const bKeys = Object.keys(b);
  return (
    aKeys.length === bKeys.length &&
    aKeys.every((key) => Object.prototype.hasOwnProperty.call(b, key) && Object.is(a[key], b[key]))
  );
}

function mergeVehicleSnapshot(previous: FleetVehicle[], incoming: FleetVehicle[]) {
  const byId = new Map(previous.map((vehicle) => [vehicle.id, vehicle]));
  let changed = previous.length !== incoming.length;
  const merged = incoming.map((vehicle) => {
    const old = byId.get(vehicle.id);
    if (!old) {
      changed = true;
      return vehicle;
    }
    const next = {
      ...vehicle,
      trackHistory: old.trackHistory,
      routeStats: old.routeStats,
      routeStops: old.routeStops,
    };
    if (
      sameShallow(
        old as unknown as Record<string, unknown>,
        next as unknown as Record<string, unknown>
      )
    ) {
      return old;
    }
    changed = true;
    return next;
  });
  if (!changed && merged.some((vehicle, index) => vehicle !== previous[index])) changed = true;
  return changed ? merged : previous;
}

function tehranToday() {
  const d = new Date();
  d.setMinutes(d.getMinutes() - d.getTimezoneOffset());
  return d.toISOString().slice(0, 10);
}

export function HamiFleetModule({
  apiBaseUrl = '',
  className = '',
  onVehicleSelected,
  onDriverSynced,
  onMissionStatusChanged,
}: HamiFleetModuleProps) {
  const [vehicles, setVehicles] = useState<FleetVehicle[]>([]);
  const [alerts, setAlerts] = useState<FleetAlert[]>([]);
  const [geofences, setGeofences] = useState<FleetGeofence[]>([]);
  const [dailyStatus, setDailyStatus] = useState<DailyFleetStatusPoint[]>([]);
  const [day, setDay] = useState(tehranToday());
  const [loading, setLoading] = useState(true);
  const [routeLoading, setRouteLoading] = useState(false);
  const [dailyLoading, setDailyLoading] = useState(false);
  const [alertsLoading, setAlertsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [dailyError, setDailyError] = useState<string | null>(null);
  const [alertsError, setAlertsError] = useState<string | null>(null);
  const [isLive, setIsLive] = useState(false);

  // Maintenance & Oil Service State
  const [maintenanceStatuses, setMaintenanceStatuses] = useState<VehicleMaintenanceStatus[]>([]);
  const [maintenanceRules, setMaintenanceRules] = useState<MaintenanceRule[]>([]);
  const [maintenanceLogs, setMaintenanceLogs] = useState<ServiceLog[]>([]);
  const [maintenanceLoading, setMaintenanceLoading] = useState(false);

  // Missions & Waybills State
  const [missions, setMissions] = useState<FleetMission[]>([]);
  const [missionsLoading, setMissionsLoading] = useState(false);

  // Fuel Management State
  const [fuelLogs, setFuelLogs] = useState<FuelLog[]>([]);
  const [fuelAnalytics, setFuelAnalytics] = useState<{
    fleetSummary: FleetFuelSummary;
    vehicleStats: VehicleFuelAnalytics[];
    stagesHistory: FuelLog[];
  } | null>(null);
  const [fuelLoading, setFuelLoading] = useState(false);

  const selectedDateRef = useRef(day);
  const refreshInFlight = useRef(false);
  const hasLoadedFleet = useRef(false);
  const dailyRequests = useRef(new Map<string, Promise<void>>());
  const alertRequests = useRef(new Map<string, Promise<void>>());
  const routeRequests = useRef(new Set<string>());

  const base = apiBaseUrl.replace(/\/$/, '');

  const refreshFleet = useCallback(async () => {
    if (refreshInFlight.current) return;
    refreshInFlight.current = true;
    if (!hasLoadedFleet.current) setLoading(true);
    try {
      const response = await fetch(`${base}/api/vehicles`, { cache: 'no-store' });
      const payload = await response.json().catch(() => ({}));
      if (!response.ok) {
        throw new Error(payload.error || 'ارتباط با سامانه GPS ایران‌اسمارت برقرار نشد.');
      }
      if (!Array.isArray(payload.vehicles)) {
        throw new Error('پاسخ API فهرست خودروها معتبر نیست.');
      }
      const normalized = (payload.vehicles as FleetVehicle[]).map((v) => ({
        ...v,
        category: categorySet.includes(v.category) ? v.category : 'other',
      }));
      setVehicles((current) => mergeVehicleSnapshot(current, normalized));
      hasLoadedFleet.current = true;
      setIsLive(true);
      setError(null);
    } catch (e) {
      setError(e instanceof Error ? e.message : 'ارتباط با API ایران‌اسمارت برقرار نشد.');
    } finally {
      refreshInFlight.current = false;
      setLoading(false);
    }
  }, [base]);

  const maintenanceInFlight = useRef(false);
  const loadMaintenanceData = useCallback(async () => {
    if (maintenanceInFlight.current) return;
    maintenanceInFlight.current = true;
    setMaintenanceLoading(true);
    try {
      const [rulesRes, logsRes, statusRes] = await Promise.allSettled([
        fetch(`${base}/api/maintenance/rules`)
          .then((r) => (r.ok ? r.json() : null))
          .catch(() => null),
        fetch(`${base}/api/maintenance/logs`)
          .then((r) => (r.ok ? r.json() : null))
          .catch(() => null),
        fetch(`${base}/api/maintenance/status`)
          .then((r) => (r.ok ? r.json() : null))
          .catch(() => null),
      ]);

      if (rulesRes.status === 'fulfilled' && Array.isArray(rulesRes.value?.rules)) {
        setMaintenanceRules(rulesRes.value.rules);
      }
      if (logsRes.status === 'fulfilled' && Array.isArray(logsRes.value?.logs)) {
        setMaintenanceLogs(logsRes.value.logs);
      }
      if (statusRes.status === 'fulfilled' && Array.isArray(statusRes.value?.statuses)) {
        setMaintenanceStatuses(statusRes.value.statuses);
      }
    } catch {
      // Non-fatal
    } finally {
      maintenanceInFlight.current = false;
      setMaintenanceLoading(false);
    }
  }, [base]);

  const missionsInFlight = useRef(false);
  const loadMissionsData = useCallback(async () => {
    if (missionsInFlight.current) return;
    missionsInFlight.current = true;
    setMissionsLoading(true);
    try {
      const res = await fetch(`${base}/api/missions`);
      if (res.ok) {
        const data = await res.json();
        if (Array.isArray(data?.missions)) {
          setMissions(data.missions);
        }
      }
    } catch {
      // Non-fatal
    } finally {
      missionsInFlight.current = false;
      setMissionsLoading(false);
    }
  }, [base]);

  const fuelInFlight = useRef(false);
  const loadFuelData = useCallback(async () => {
    if (fuelInFlight.current) return;
    fuelInFlight.current = true;
    setFuelLoading(true);
    try {
      const [logsRes, analyticsRes] = await Promise.allSettled([
        fetch(`${base}/api/fuel/logs`).then((r) => (r.ok ? r.json() : null)),
        fetch(`${base}/api/fuel/analytics`).then((r) => (r.ok ? r.json() : null)),
      ]);
      if (logsRes.status === 'fulfilled' && Array.isArray(logsRes.value?.logs)) {
        setFuelLogs(logsRes.value.logs);
      }
      if (analyticsRes.status === 'fulfilled' && analyticsRes.value) {
        setFuelAnalytics(analyticsRes.value);
      }
    } catch {
      // Non-fatal
    } finally {
      fuelInFlight.current = false;
      setFuelLoading(false);
    }
  }, [base]);

  const handleMaintenanceRuleSave = useCallback(
    async (rule: Partial<MaintenanceRule>) => {
      const resp = await fetch(`${base}/api/maintenance/rules`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(rule),
      });
      if (!resp.ok) throw new Error('خطا در ذخیره قانون سرویس');
      await loadMaintenanceData();
    },
    [base, loadMaintenanceData]
  );

  const handleMaintenanceRuleDelete = useCallback(
    async (ruleId: string) => {
      const resp = await fetch(`${base}/api/maintenance/rules/${encodeURIComponent(ruleId)}`, {
        method: 'DELETE',
      });
      if (!resp.ok) throw new Error('خطا در حذف قانون');
      await loadMaintenanceData();
    },
    [base, loadMaintenanceData]
  );

  const handleServiceLogRecord = useCallback(
    async (log: Partial<ServiceLog>) => {
      const resp = await fetch(`${base}/api/maintenance/logs`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(log),
      });
      if (!resp.ok) throw new Error('خطا در ثبت لاگ سرویس');
      await Promise.all([loadMaintenanceData(), refreshFleet()]);
    },
    [base, loadMaintenanceData, refreshFleet]
  );

  const handleMissionCreate = useCallback(
    async (mission: Partial<FleetMission>) => {
      const res = await fetch(`${base}/api/missions`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(mission),
      });
      if (!res.ok) throw new Error('خطا در صدور بارنامه');
      await Promise.all([loadMissionsData(), refreshFleet()]);
    },
    [base, loadMissionsData, refreshFleet]
  );

  const handleMissionStatusChange = useCallback(
    async (missionId: string, status: MissionStatus) => {
      const res = await fetch(`${base}/api/missions/${encodeURIComponent(missionId)}/status`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ status }),
      });
      if (!res.ok) throw new Error('خطا در به‌روزرسانی وضعیت مأموریت');
      await Promise.all([loadMissionsData(), refreshFleet()]);
      onMissionStatusChanged?.(missionId, status);
    },
    [base, loadMissionsData, refreshFleet, onMissionStatusChanged]
  );

  const handleMissionDelete = useCallback(
    async (missionId: string) => {
      const res = await fetch(`${base}/api/missions/${encodeURIComponent(missionId)}`, {
        method: 'DELETE',
      });
      if (!res.ok) throw new Error('خطا در حذف مأموریت');
      await Promise.all([loadMissionsData(), refreshFleet()]);
    },
    [base, loadMissionsData, refreshFleet]
  );

  const handleDriverSync = useCallback(
    async (data: {
      vehicleCode?: string;
      imei?: string;
      driverName: string;
      driverPhone?: string;
    }) => {
      const res = await fetch(`${base}/api/drivers/sync`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data),
      });
      if (!res.ok) throw new Error('خطا در همگام‌سازی پرسنل');
      await Promise.all([loadMissionsData(), refreshFleet()]);
      if (data.vehicleCode && data.driverName) {
        onDriverSynced?.(data.vehicleCode, data.driverName);
      }
    },
    [base, loadMissionsData, refreshFleet, onDriverSynced]
  );

  const handleFuelLogCreate = useCallback(
    async (log: Partial<FuelLog>) => {
      const res = await fetch(`${base}/api/fuel/logs`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(log),
      });
      if (!res.ok) throw new Error('خطا در ثبت سوخت‌گیری');
      await loadFuelData();
    },
    [base, loadFuelData]
  );

  const handleFuelLogDelete = useCallback(
    async (logId: string) => {
      const res = await fetch(`${base}/api/fuel/logs/${encodeURIComponent(logId)}`, {
        method: 'DELETE',
      });
      if (!res.ok) throw new Error('خطا در حذف رکورد سوخت‌گیری');
      await loadFuelData();
    },
    [base, loadFuelData]
  );

  // Load geofences
  useEffect(() => {
    fetch(`${base}/api/geofences`)
      .then((r) => r.json())
      .then((data) => {
        if (Array.isArray(data?.geofences)) setGeofences(data.geofences);
      })
      .catch(() => undefined);
  }, [base]);

  const handleGeofencesChange = useCallback(
    (zones: FleetGeofence[]) => {
      setGeofences(zones);
      fetch(`${base}/api/geofences`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ geofences: zones }),
      }).catch(() => undefined);
    },
    [base]
  );

  const loadAlerts = useCallback(() => {
    const requestDay = selectedDateRef.current;
    const existing = alertRequests.current.get(requestDay);
    if (existing) return existing;
    setAlertsLoading(true);
    setAlertsError(null);
    const request = (async () => {
      try {
        const response = await fetch(
          `${base}/api/alerts?date=${encodeURIComponent(requestDay)}`,
          { cache: 'no-store' }
        );
        if (!response.ok) throw new Error('دریافت هشدارها ناموفق بود.');
        const result = await response.json();
        if (selectedDateRef.current === requestDay) {
          setAlerts(Array.isArray(result.alerts) ? result.alerts : []);
        }
      } catch (e) {
        if (selectedDateRef.current === requestDay) {
          setAlertsError(e instanceof Error ? e.message : 'دریافت هشدارها ناموفق بود.');
        }
      } finally {
        if (selectedDateRef.current === requestDay) setAlertsLoading(false);
        alertRequests.current.delete(requestDay);
      }
    })();
    alertRequests.current.set(requestDay, request);
    return request;
  }, [base]);

  const loadDailyStatus = useCallback(
    (date: string) => {
      if (selectedDateRef.current !== date) {
        selectedDateRef.current = date;
        setDailyStatus([]);
        setDailyError(null);
      }
      setDay(date);
      if (!isLive) return Promise.resolve();
      const existing = dailyRequests.current.get(date);
      if (existing) return existing;
      setDailyLoading(true);
      setDailyError(null);
      const request = (async () => {
        try {
          const response = await fetch(
            `${base}/api/daily-status?date=${encodeURIComponent(date)}`,
            { cache: 'no-store' }
          );
          if (!response.ok) throw new Error('دریافت گزارش روزانه ناموفق بود.');
          const result = await response.json();
          if (selectedDateRef.current === date) {
            setDailyStatus(Array.isArray(result.dailyStatus) ? result.dailyStatus : []);
          }
        } catch (e) {
          if (selectedDateRef.current === date) {
            setDailyError(e instanceof Error ? e.message : 'دریافت گزارش روزانه ناموفق بود.');
          }
        } finally {
          if (selectedDateRef.current === date) setDailyLoading(false);
          dailyRequests.current.delete(date);
        }
      })();
      dailyRequests.current.set(date, request);
      return request;
    },
    [base, isLive]
  );

  const loadCurrentDaily = useCallback(() => loadDailyStatus(day), [day, loadDailyStatus]);

  // Polling loop
  useEffect(() => {
    let stopped = false;
    let timer = 0;
    const poll = async () => {
      await refreshFleet();
      void loadAlerts();
      void loadMaintenanceData();
      void loadMissionsData();
      void loadFuelData();
      if (!stopped) timer = window.setTimeout(poll, 60_000);
    };
    void poll();
    return () => {
      stopped = true;
      window.clearTimeout(timer);
    };
  }, [refreshFleet, loadAlerts, loadMaintenanceData, loadMissionsData, loadFuelData]);

  const loadVehicleRoute = useCallback(
    async (vehicle: FleetVehicle) => {
      onVehicleSelected?.(vehicle);
      if (!isLive) return;
      const key = `${vehicle.id}:${day}`;
      if (routeRequests.current.has(key)) return;
      routeRequests.current.add(key);
      setRouteLoading(true);
      try {
        const response = await fetch(
          `${base}/api/playback?imei=${encodeURIComponent(vehicle.id)}&date=${encodeURIComponent(day)}`,
          { cache: 'no-store' }
        );
        if (!response.ok) return;
        const result = await response.json();
        const points = Array.isArray(result.points) ? result.points : [];
        setVehicles((current) =>
          current.map((v) =>
            v.id === vehicle.id
              ? {
                  ...v,
                  trackHistory: points,
                  routeStats: result.stats,
                  routeStops: result.stops,
                }
              : v
          )
        );
      } catch {
        // Keep last position
      } finally {
        routeRequests.current.delete(key);
        setRouteLoading(false);
      }
    },
    [base, day, isLive, onVehicleSelected]
  );

  const handleSaveVehicleMeta = useCallback(
    async (meta: {
      imei: string;
      name: string;
      driverName: string;
      vehicleCode: string;
      category: VehicleCategory;
      plateNumber: string;
      nextServiceKm?: number | '';
    }) => {
      const resp = await fetch(`${base}/api/vehicle-meta`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(meta),
      });
      if (!resp.ok) throw new Error('Failed to save vehicle metadata');
      await refreshFleet();
    },
    [base, refreshFleet]
  );

  return (
    <FleetMapModule
      className={className}
      vehicles={vehicles}
      alerts={alerts}
      geofences={geofences}
      drivers={EMPTY_DRIVERS}
      maintenance={EMPTY_MAINTENANCE}
      dailyStatus={dailyStatus}
      dailyDate={day}
      dailyLoading={dailyLoading}
      dailyError={dailyError}
      alertsLoading={alertsLoading}
      alertsError={alertsError}
      routeLoading={routeLoading}
      maintenanceStatuses={maintenanceStatuses}
      maintenanceRules={maintenanceRules}
      maintenanceLogs={maintenanceLogs}
      maintenanceLoading={maintenanceLoading}
      onMaintenanceRuleSave={handleMaintenanceRuleSave}
      onMaintenanceRuleDelete={handleMaintenanceRuleDelete}
      onServiceLogRecord={handleServiceLogRecord}
      onMaintenanceRefresh={loadMaintenanceData}
      onGeofencesChange={handleGeofencesChange}
      onDailyDateChange={loadDailyStatus}
      onDailyReportOpen={loadCurrentDaily}
      onAlertsOpen={loadAlerts}
      loading={loading}
      error={error}
      onRefresh={refreshFleet}
      onVehicleSelect={loadVehicleRoute}
      onVehicleMetaSave={handleSaveVehicleMeta}
      categoryConfig={FLEET_CATEGORY_CONFIG}
      missions={missions}
      missionsLoading={missionsLoading}
      onMissionCreate={handleMissionCreate}
      onMissionStatusChange={handleMissionStatusChange}
      onMissionDelete={handleMissionDelete}
      onDriverSync={handleDriverSync}
      onMissionsRefresh={loadMissionsData}
      fuelLogs={fuelLogs}
      fuelAnalytics={fuelAnalytics}
      fuelLoading={fuelLoading}
      onFuelLogCreate={handleFuelLogCreate}
      onFuelLogDelete={handleFuelLogDelete}
      onFuelRefresh={loadFuelData}
    />
  );
}

export default memo(HamiFleetModule);
