import { HamiFleetModule } from './modules';

export default function App() {
  return <HamiFleetModule />;
}
