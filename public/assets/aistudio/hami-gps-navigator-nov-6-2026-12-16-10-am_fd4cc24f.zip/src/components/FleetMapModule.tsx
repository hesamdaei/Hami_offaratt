import {
  memo,
  useCallback,
  useEffect,
  useMemo,
  useRef,
  useState,
} from 'react';
import L from 'leaflet';
import workerUrl from 'maplibre-gl/dist/maplibre-gl-worker.mjs?worker&url';
import {
  Navigation,
  Search,
  RefreshCw,
  Download,
  MapPin,
  Share2,
  Truck,
  Clock,
  Gauge,
  User,
  Bell,
  Route,
  Play,
  Pause,
  X,
  ShieldCheck,
  Wrench,
  Compass,
  Layers,
  Crosshair,
  Edit3,
  Plus,
  Trash2,
  ChevronLeft,
  BatteryCharging,
  Power,
  CheckCircle2,
  AlertTriangle,
  CornerUpLeft,
  BarChart3,
  Radio,
  Maximize2,
  Minimize2,
  Check,
  FileText,
  Fuel,
  Info,
  History,
  Zap,
  SlidersHorizontal,
  ClipboardList,
  PackageCheck,
  Send,
  UserCheck,
  Timer,
  Phone,
  TrendingUp,
} from 'lucide-react';
import MonthlyFuelTrendWidget from './MonthlyFuelTrendWidget';

export type VehicleCategory = 'khavar' | 'hyundai' | 'isuzu' | 'nissan' | 'other';
export type AlertKind = 'offline' | 'speeding' | 'geofence' | 'maintenance' | 'safety' | 'other';
export type ServiceType =
  | 'engine_oil'
  | 'gearbox_oil'
  | 'brake_pads'
  | 'filters'
  | 'belts'
  | 'general'
  | 'custom';

export interface VehicleTrackPoint {
  latitude: number;
  longitude: number;
  timestamp?: string | number | Date;
  speedKph?: number;
  heading?: number;
}

export interface RouteStopPoint {
  latitude: number;
  longitude: number;
  startTime: number;
  endTime: number;
  durationMinutes: number;
}

export interface PlaybackRouteStats {
  pointCount: number;
  distanceKm: number;
  maxSpeedKph: number;
  stopCount: number;
}

export interface FleetGeofence {
  id: string;
  name: string;
  latitude: number;
  longitude: number;
  radiusMeters: number;
  color?: string;
  active?: boolean;
  kind?: 'parking' | 'fuel' | 'custom';
  userDefined?: boolean;
}

export interface DailyFleetStatusPoint {
  hour: string;
  moving: number;
  stopped: number;
  offline: number;
  unknown?: number;
}

export interface FleetDriverStats {
  id: string;
  name: string;
  vehicleId?: string;
  score?: number;
  speedingEvents?: number;
  harshEvents?: number;
  idleMinutes?: number;
  distanceKm?: number;
}

export interface MaintenanceItem {
  id: string;
  vehicleId: string;
  title: string;
  dueAt?: string | number | Date;
  dueInKm?: number;
  status: 'upcoming' | 'due' | 'overdue' | 'completed';
}

export interface FleetAlert {
  id: string;
  vehicleId: string;
  kind: AlertKind;
  title: string;
  description?: string;
  occurredAt?: string | number | Date;
  severity?: 'high' | 'medium' | 'low';
}

export interface MaintenanceRule {
  id: string;
  serviceType: ServiceType;
  title: string;
  scope: 'all' | 'category' | 'vehicle';
  category?: VehicleCategory;
  vehicleId?: string;
  kmInterval: number; // لیمیت کیلومتری
  daysInterval: number; // لیمیت روزانه
  warningKmLead: number;
  warningDaysLead: number;
  createdAt: number;
}

export interface ServiceLog {
  id: string;
  vehicleId: string;
  vehicleName: string;
  serviceType: ServiceType;
  title: string;
  serviceKm: number;
  serviceDate: string; // YYYY-MM-DD
  oilBrand?: string;
  workshopName?: string;
  technicianName?: string;
  costToman?: number;
  notes?: string;
  createdAt: number;
}

export interface VehicleMaintenanceStatus {
  vehicleId: string;
  vehicleName: string;
  vehicleCode: string;
  driverName?: string;
  category: VehicleCategory;
  plateNumber?: string;
  currentKm: number;
  currentSpeedKph: number;
  services: Array<{
    ruleId: string;
    serviceType: ServiceType;
    title: string;
    kmInterval: number;
    daysInterval: number;
    lastServiceKm: number;
    lastServiceDate: string;
    kmDriven: number;
    kmRemaining: number;
    kmPercentage: number;
    daysPassed: number;
    daysRemaining: number;
    daysPercentage: number;
    isKmOverdue: boolean;
    isDaysOverdue: boolean;
    isDueSoon: boolean;
    status: 'overdue' | 'due_soon' | 'nominal';
    latestLog?: ServiceLog;
  }>;
  overallStatus: 'overdue' | 'due_soon' | 'nominal';
}

export type MissionStatus = 'loading' | 'in_transit' | 'unloaded' | 'completed';

export interface FleetMission {
  id: string;
  waybillNumber: string;
  vehicleId: string;
  vehicleCode: string;
  vehicleName: string;
  category: VehicleCategory;
  plateNumber?: string;
  driverId?: string;
  driverName: string;
  driverPhone?: string;
  cargoTitle: string;
  weightTons?: number;
  origin: {
    title: string;
    latitude: number;
    longitude: number;
  };
  destination: {
    title: string;
    latitude: number;
    longitude: number;
  };
  totalDistanceKm: number;
  currentDistanceCoveredKm: number;
  remainingDistanceKm?: number;
  progressPercent: number;
  status: MissionStatus;
  startedAt?: string;
  estimatedArrival?: string;
  remainingMinutes?: number;
  etaLabel?: string;
  vehicleCurrentSpeed?: number;
  completedAt?: string;
  notes?: string;
  createdAt: number;
}

export type FuelType = 'diesel' | 'petrol_regular' | 'petrol_super' | 'cng';

export interface FuelLog {
  id: string;
  vehicleId: string;
  vehicleName: string;
  vehicleCode: string;
  category: VehicleCategory;
  plateNumber?: string;
  driverName?: string;
  date: string;
  time?: string;
  odometerKm: number;
  liters: number;
  fuelType: FuelType;
  unitPriceToman?: number;
  totalCostToman: number;
  gasStation?: string;
  fullTank: boolean;
  stageNumber?: number;
  previousOdometerKm?: number;
  kmSincePreviousFuel?: number;
  daysSincePreviousFuel?: number;
  consumptionL100km?: number;
  costPerKmToman?: number;
  isAnomaly?: boolean;
  notes?: string;
  createdAt: number;
}

export interface VehicleFuelAnalytics {
  vehicleId: string;
  vehicleName: string;
  vehicleCode: string;
  plateNumber?: string;
  driverName?: string;
  category: VehicleCategory;
  currentKm: number;
  tankCapacity: number;
  lastFuelLog?: FuelLog | null;
  lastFuelDate?: string;
  lastFuelKm?: number;
  lastFuelStation?: string;
  kmSinceLastFuel: number;
  vehicleAvgConsumption: number;
  estFuelUsedSinceLastRefuel: number;
  estRemainingFuelLiters: number;
  estRemainingRangeKm: number;
  maxTankRangeKm: number;
  refuelUrgency: 'normal' | 'due_soon' | 'critical';
  stagesCount: number;
  totalLiters: number;
  totalCostToman: number;
  anomalyCount: number;
  stages: FuelLog[];
}

export interface FleetFuelSummary {
  totalLiters: number;
  totalCostToman: number;
  totalKmTracked: number;
  fleetAvgConsumption: number;
  totalLogsCount: number;
  criticalCount: number;
  dueSoonCount: number;
  anomaliesCount: number;
}

export interface FleetVehicle {
  id: string;
  imei?: string;
  name: string;
  driverName?: string;
  vehicleCode: string;
  category: VehicleCategory;
  latitude: number;
  longitude: number;
  hasValidGps?: boolean;
  speedKph?: number;
  heading?: number;
  online?: boolean;
  deviceStatus?: number;
  lastSeen?: string | number | Date | null;
  plateNumber?: string;
  locationLabel?: string;
  odometerKm?: number;
  fuelPercent?: number;
  fuelLiters?: number;
  externalPower?: string;
  batteryPercent?: number;
  accStatus?: boolean;
  nextServiceKm?: number;
  driverScore?: number;
  speedingEvents?: number;
  harshEvents?: number;
  idleMinutes?: number;
  distanceTodayKm?: number;
  trackHistory?: VehicleTrackPoint[];
  routeStats?: PlaybackRouteStats;
  routeStops?: RouteStopPoint[];
  hasActiveWaybill?: boolean;
  waybillStatus?: MissionStatus | null;
  waybillNumber?: string;
  tripProgressPercent?: number;
  activeMission?: FleetMission | null;
}

export interface FleetCategoryConfig {
  label?: string;
  color?: string;
  tint?: string;
  icon?: string;
}

export interface NavigationStep {
  name: string;
  distanceMeters: number;
  durationSeconds: number;
  maneuverType: string;
  maneuverModifier?: string;
  location: [number, number] | null;
}

export interface ActiveNavigationRoute {
  fromLabel: string;
  toLabel: string;
  fromCoord: [number, number];
  toCoord: [number, number];
  distanceKm: number;
  durationMinutes: number;
  coordinates: Array<[number, number]>;
  steps: NavigationStep[];
}

export interface FleetMapModuleProps {
  vehicles: FleetVehicle[];
  loading?: boolean;
  error?: string | null;
  alerts?: FleetAlert[];
  geofences?: FleetGeofence[];
  drivers?: FleetDriverStats[];
  maintenance?: MaintenanceItem[];
  dailyStatus?: DailyFleetStatusPoint[];
  dailyDate?: string;
  dailyLoading?: boolean;
  dailyError?: string | null;
  alertsLoading?: boolean;
  alertsError?: string | null;
  routeLoading?: boolean;
  maintenanceStatuses?: VehicleMaintenanceStatus[];
  maintenanceRules?: MaintenanceRule[];
  maintenanceLogs?: ServiceLog[];
  maintenanceLoading?: boolean;
  onMaintenanceRuleSave?: (rule: Partial<MaintenanceRule>) => Promise<void>;
  onMaintenanceRuleDelete?: (ruleId: string) => Promise<void>;
  onServiceLogRecord?: (log: Partial<ServiceLog>) => Promise<void>;
  onMaintenanceRefresh?: () => Promise<void>;
  onGeofencesChange?: (zones: FleetGeofence[]) => void;
  onDailyDateChange?: (date: string) => void;
  onDailyReportOpen?: () => void;
  onAlertsOpen?: () => void;
  onRefresh?: () => void | Promise<void>;
  className?: string;
  onVehicleSelect?: (vehicle: FleetVehicle) => void;
  onAlertSelect?: (alert: FleetAlert) => void;
  onVehicleMetaSave?: (meta: {
    imei: string;
    name: string;
    driverName: string;
    vehicleCode: string;
    category: VehicleCategory;
    plateNumber: string;
    nextServiceKm?: number | '';
  }) => Promise<void>;
  categoryConfig?: Partial<Record<VehicleCategory, FleetCategoryConfig>>;
  visibleMetrics?: Array<'total' | 'moving' | 'stopped' | 'offline' | 'alerts'>;
  missions?: FleetMission[];
  missionsLoading?: boolean;
  onMissionCreate?: (mission: Partial<FleetMission>) => Promise<void>;
  onMissionStatusChange?: (missionId: string, status: MissionStatus) => Promise<void>;
  onMissionDelete?: (missionId: string) => Promise<void>;
  onDriverSync?: (data: {
    vehicleCode?: string;
    imei?: string;
    driverName: string;
    driverPhone?: string;
  }) => Promise<void>;
  onMissionsRefresh?: () => Promise<void>;
  fuelLogs?: FuelLog[];
  fuelAnalytics?: {
    fleetSummary: FleetFuelSummary;
    vehicleStats: VehicleFuelAnalytics[];
    stagesHistory: FuelLog[];
  } | null;
  fuelLoading?: boolean;
  onFuelLogCreate?: (log: Partial<FuelLog>) => Promise<void>;
  onFuelLogDelete?: (logId: string) => Promise<void>;
  onFuelRefresh?: () => Promise<void>;
}

type CategoryMeta = {
  label: string;
  color: string;
  markerClass: string;
  badgeBgClass: string;
  badgeTextClass: string;
  dotClass: string;
  icon: string;
};

const DEFAULT_CATEGORY: Record<VehicleCategory, CategoryMeta> = {
  khavar: {
    label: 'خاور',
    color: '#2563eb',
    markerClass: 'marker-khavar',
    badgeBgClass: 'bg-blue-50',
    badgeTextClass: 'text-blue-700',
    dotClass: 'bg-blue-600',
    icon: 'خ',
  },
  hyundai: {
    label: 'هیوندای',
    color: '#7c3aed',
    markerClass: 'marker-hyundai',
    badgeBgClass: 'bg-violet-50',
    badgeTextClass: 'text-violet-700',
    dotClass: 'bg-violet-600',
    icon: 'هـ',
  },
  isuzu: {
    label: 'ایسوزو',
    color: '#0d9488',
    markerClass: 'marker-isuzu',
    badgeBgClass: 'bg-teal-50',
    badgeTextClass: 'text-teal-700',
    dotClass: 'bg-teal-600',
    icon: 'ا',
  },
  nissan: {
    label: 'نیسان',
    color: '#d97706',
    markerClass: 'marker-nissan',
    badgeBgClass: 'bg-amber-50',
    badgeTextClass: 'text-amber-700',
    dotClass: 'bg-amber-600',
    icon: 'ن',
  },
  other: {
    label: 'سایر',
    color: '#475569',
    markerClass: 'marker-other',
    badgeBgClass: 'bg-slate-100',
    badgeTextClass: 'text-slate-700',
    dotClass: 'bg-slate-500',
    icon: 'س',
  },
};

const SERVICE_TYPE_LABELS: Record<ServiceType, string> = {
  engine_oil: 'تعویض روغن موتور و فیلتر روغن',
  gearbox_oil: 'روغن گیربکس و واسکازین دیفرانسیل',
  brake_pads: 'بازدید و تعویض لنت ترمز',
  filters: 'فیلتر هوا و گازوئیل / سوخت',
  belts: 'تسمه تایم و تسمه دینام',
  general: 'آچارکشی و سرویس دوره‌ای کلی',
  custom: 'سایر سرویس‌های دوره‌ای',
};

type MapStyleMode = 'voyager' | 'vector' | 'dark' | 'satellite';
type SideDrawerType =
  | 'none'
  | 'fleet'
  | 'missions'
  | 'fuel'
  | 'maintenance'
  | 'navigation'
  | 'alerts'
  | 'reports';

const numberFa = (value: number) => new Intl.NumberFormat('fa-IR').format(value);

const formatTime = (value?: string | number | Date | null) => {
  if (!value) return 'ثبت نشده';
  const date = value instanceof Date ? value : new Date(value);
  if (Number.isNaN(date.getTime())) return 'ثبت نشده';
  return new Intl.DateTimeFormat('fa-IR', {
    hour: '2-digit',
    minute: '2-digit',
    month: 'short',
    day: 'numeric',
  }).format(date);
};

const formatHeadingLabel = (deg?: number) => {
  if (deg == null || !Number.isFinite(deg)) return 'نامشخص';
  const dirs = ['شمال', 'شمال‌شرق', 'شرق', 'جنوب‌شرق', 'جنوب', 'جنوب‌غرب', 'غرب', 'شمال‌غرب'];
  const idx = Math.round(((deg % 360) < 0 ? deg + 360 : deg) / 45) % 8;
  return `${dirs[idx]} (${numberFa(Math.round(deg))}°)`;
};

type LocatedFleetVehicle = FleetVehicle & { latitude: number; longitude: number };

const validPosition = (v: FleetVehicle): v is LocatedFleetVehicle =>
  Number.isFinite(v.latitude) &&
  Number.isFinite(v.longitude) &&
  Math.abs(v.latitude) > 0.01 &&
  Math.abs(v.latitude) <= 90 &&
  Math.abs(v.longitude) > 0.01 &&
  Math.abs(v.longitude) <= 180;

const distanceMeters = (lat1: number, lon1: number, lat2: number, lon2: number) => {
  const r = 6371000;
  const rad = (n: number) => (n * Math.PI) / 180;
  const dLat = rad(lat2 - lat1);
  const dLon = rad(lon2 - lon1);
  const a =
    Math.sin(dLat / 2) ** 2 +
    Math.cos(rad(lat1)) * Math.cos(rad(lat2)) * Math.sin(dLon / 2) ** 2;
  return 2 * r * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
};

const neshanUrl = (lat: number, lon: number) =>
  `https://nshn.ir/?lat=${encodeURIComponent(lat)}&lng=${encodeURIComponent(lon)}`;
const baladUrl = (lat: number, lon: number) =>
  `https://balad.ir/location?latitude=${encodeURIComponent(lat)}&longitude=${encodeURIComponent(lon)}&zoom=16`;
const googleMapsUrl = (lat: number, lon: number) =>
  `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(lat)},${encodeURIComponent(lon)}`;

function localDateString() {
  const d = new Date();
  d.setMinutes(d.getMinutes() - d.getTimezoneOffset());
  return d.toISOString().slice(0, 10);
}

function makeVehicleIcon(
  codeLabel: string,
  markerClass: string,
  selected: boolean,
  online: boolean,
  moving: boolean,
  hasActiveWaybill: boolean = false,
  waybillStatus: MissionStatus | null = null,
  tripProgressPercent?: number
) {
  const shortLabel = String(codeLabel).slice(0, 4);
  const waybillClass = hasActiveWaybill && waybillStatus ? `has-waybill-${waybillStatus}` : '';
  const progressBadge =
    hasActiveWaybill && tripProgressPercent != null
      ? `<span class="waybill-progress-badge">${numberFa(tripProgressPercent)}٪</span>`
      : '';

  return L.divIcon({
    className: 'fleet-marker-wrap',
    html: `<span class="fleet-marker ${markerClass} ${waybillClass} ${selected ? 'is-selected' : ''} ${!online ? 'is-offline' : ''} ${moving ? 'is-moving' : ''}">${progressBadge}<span>${shortLabel}</span></span>`,
    iconSize: [38, 38],
    iconAnchor: [19, 19],
    popupAnchor: [0, -18],
  });
}

export function FleetMapModule({
  vehicles,
  loading = false,
  error = null,
  alerts = [],
  geofences = [],
  drivers = [],
  dailyStatus = [],
  dailyDate,
  dailyLoading = false,
  dailyError = null,
  alertsLoading = false,
  alertsError = null,
  routeLoading = false,
  maintenanceStatuses = [],
  maintenanceRules = [],
  maintenanceLogs = [],
  onMaintenanceRuleSave,
  onMaintenanceRuleDelete,
  onServiceLogRecord,
  onMaintenanceRefresh,
  onGeofencesChange,
  onDailyDateChange,
  onDailyReportOpen,
  onAlertsOpen,
  onRefresh,
  className = '',
  onVehicleSelect,
  onAlertSelect,
  onVehicleMetaSave,
  categoryConfig,
  missions = [],
  missionsLoading = false,
  onMissionCreate,
  onMissionStatusChange,
  onMissionDelete,
  onDriverSync,
  onMissionsRefresh,
  fuelLogs = [],
  fuelAnalytics = null,
  fuelLoading = false,
  onFuelLogCreate,
  onFuelLogDelete,
  onFuelRefresh,
}: FleetMapModuleProps) {
  const categories = useMemo(
    () =>
      Object.fromEntries(
        (Object.keys(DEFAULT_CATEGORY) as VehicleCategory[]).map((k) => [
          k,
          { ...DEFAULT_CATEGORY[k], ...categoryConfig?.[k] },
        ])
      ) as Record<VehicleCategory, CategoryMeta>,
    [categoryConfig]
  );

  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [categoryFilter, setCategoryFilter] = useState<VehicleCategory | 'all'>('all');
  const [statusFilter, setStatusFilter] = useState<'all' | 'moving' | 'stopped' | 'offline'>('all');
  const [search, setSearch] = useState('');
  const [notice, setNotice] = useState('');
  const [searchFocused, setSearchFocused] = useState(false);

  // Side Drawer state: 'none' | 'fleet' | 'maintenance' | 'navigation' | 'alerts' | 'reports'
  const [activeDrawer, setActiveDrawer] = useState<SideDrawerType>('none');
  const [opsTab, setOpsTab] = useState<'daily' | 'drivers' | 'maintenance' | 'zones'>('daily');
  const [geofencesVisible, setGeofencesVisible] = useState(true);
  const [mapStyle, setMapStyle] = useState<MapStyleMode>('voyager');
  const [styleMenuOpen, setStyleMenuOpen] = useState(false);

  // Maintenance & Oil Service Specific State
  const [maintSubTab, setMaintSubTab] = useState<'vehicles' | 'rules' | 'logs'>('vehicles');
  const [maintStatusFilter, setMaintStatusFilter] = useState<'all' | 'overdue' | 'due_soon' | 'nominal'>('all');
  const [maintServiceFilter, setMaintServiceFilter] = useState<'all' | ServiceType>('all');
  const [maintSearch, setMaintSearch] = useState('');

  // Modals for Rule Definition & Recording Service Done
  const [ruleModalOpen, setRuleModalOpen] = useState(false);
  const [editingRuleId, setEditingRuleId] = useState<string | null>(null);
  const [ruleTitle, setRuleTitle] = useState('');
  const [ruleServiceType, setRuleServiceType] = useState<ServiceType>('engine_oil');
  const [ruleScope, setRuleScope] = useState<'all' | 'category' | 'vehicle'>('all');
  const [ruleCategory, setRuleCategory] = useState<VehicleCategory>('khavar');
  const [ruleVehicleId, setRuleVehicleId] = useState<string>('');
  const [ruleKmInterval, setRuleKmInterval] = useState('5000');
  const [ruleDaysInterval, setRuleDaysInterval] = useState('90');
  const [ruleWarningKmLead, setRuleWarningKmLead] = useState('500');
  const [ruleWarningDaysLead, setRuleWarningDaysLead] = useState('10');
  const [savingRule, setSavingRule] = useState(false);

  const [logModalOpen, setLogModalOpen] = useState(false);
  const [logVehicleId, setLogVehicleId] = useState('');
  const [logVehicleName, setLogVehicleName] = useState('');
  const [logServiceType, setLogServiceType] = useState<ServiceType>('engine_oil');
  const [logTitle, setLogTitle] = useState('تعویض روغن موتور و فیلترها');
  const [logServiceKm, setLogServiceKm] = useState('');
  const [logServiceDate, setLogServiceDate] = useState(localDateString());
  const [logOilBrand, setLogOilBrand] = useState('بهران سوپر توربو دیزل 15W-40');
  const [logWorkshopName, setLogWorkshopName] = useState('پایانه فتح / شادآباد');
  const [logTechnicianName, setLogTechnicianName] = useState('');
  const [logCostToman, setLogCostToman] = useState('2850000');
  const [logNotes, setLogNotes] = useState('تعویض روغن کامل با فیلتر روغن و هوا');
  const [savingLog, setSavingLog] = useState(false);

  // Historical Route Playback State
  const [routeOpen, setRouteOpen] = useState(false);
  const [routePlaying, setRoutePlaying] = useState(false);
  const [routeSpeedMultiplier, setRouteSpeedMultiplier] = useState<1 | 2 | 4>(1);
  const [routeIndex, setRouteIndex] = useState(0);

  // GPS Road Navigation State
  const [navPickMode, setNavPickMode] = useState(false);
  const [navLoading, setNavLoading] = useState(false);
  const [activeNavRoute, setActiveNavRoute] = useState<ActiveNavigationRoute | null>(null);
  const [placeQuery, setPlaceQuery] = useState('');
  const [placeResults, setPlaceResults] = useState<Array<{ label: string; latitude: number; longitude: number }>>([]);
  const [placeSearching, setPlaceSearching] = useState(false);

  // User's Live GPS Location State
  const [userGps, setUserGps] = useState<{ latitude: number; longitude: number; accuracy: number; speed: number | null } | null>(null);
  const [userGpsActive, setUserGpsActive] = useState(false);
  const watchIdRef = useRef<number | null>(null);

  // Selected Vehicle Reverse Geocoded Address
  const [resolvedAddress, setResolvedAddress] = useState<Record<string, string>>({});

  // Geofence Form State
  const [zoneFormOpen, setZoneFormOpen] = useState(false);
  const [zonePicking, setZonePicking] = useState(false);
  const [zoneName, setZoneName] = useState('');
  const [zoneKind, setZoneKind] = useState<'parking' | 'fuel' | 'custom'>('parking');
  const [zoneLat, setZoneLat] = useState('');
  const [zoneLon, setZoneLon] = useState('');
  const [zoneRadius, setZoneRadius] = useState('800');

  // Edit Vehicle Metadata Modal State
  const [editingVehicle, setEditingVehicle] = useState<FleetVehicle | null>(null);
  const [editName, setEditName] = useState('');
  const [editDriver, setEditDriver] = useState('');
  const [editCode, setEditCode] = useState('');
  const [editCategory, setEditCategory] = useState<VehicleCategory>('khavar');
  const [editPlate, setEditPlate] = useState('');
  const [editServiceKm, setEditServiceKm] = useState('');
  const [savingMeta, setSavingMeta] = useState(false);

  // Fullscreen Map State & Handlers
  const rootContainerRef = useRef<HTMLDivElement>(null);
  const [isFullscreen, setIsFullscreen] = useState(false);

  useEffect(() => {
    const handleFullscreenChange = () => {
      setIsFullscreen(Boolean(document.fullscreenElement));
      setTimeout(() => {
        mapRef.current?.invalidateSize();
      }, 150);
    };
    document.addEventListener('fullscreenchange', handleFullscreenChange);
    return () => {
      document.removeEventListener('fullscreenchange', handleFullscreenChange);
    };
  }, []);

  const toggleFullscreen = useCallback(async () => {
    try {
      if (!document.fullscreenElement) {
        if (rootContainerRef.current?.requestFullscreen) {
          await rootContainerRef.current.requestFullscreen();
        } else if ((rootContainerRef.current as any)?.webkitRequestFullscreen) {
          await (rootContainerRef.current as any).webkitRequestFullscreen();
        }
      } else {
        if (document.exitFullscreen) {
          await document.exitFullscreen();
        } else if ((document as any)?.webkitExitFullscreen) {
          await (document as any).webkitExitFullscreen();
        }
      }
      setTimeout(() => {
        mapRef.current?.invalidateSize();
      }, 150);
    } catch (err) {
      console.warn('Fullscreen toggle error:', err);
    }
  }, []);

  // Missions & Waybills State (مدیریت بارنامه، رانندگان و وضعیت سفر)
  const [missionsTab, setMissionsTab] = useState<'active' | 'new' | 'sync'>('active');
  const [missionStatusFilter, setMissionStatusFilter] = useState<'all' | MissionStatus>('all');
  const [newWaybillNumber, setNewWaybillNumber] = useState('');
  const [newVehicleCode, setNewVehicleCode] = useState('');
  const [newDriverName, setNewDriverName] = useState('');
  const [newDriverPhone, setNewDriverPhone] = useState('');
  const [newCargoTitle, setNewCargoTitle] = useState('');
  const [newCargoWeight, setNewCargoWeight] = useState('3.5');
  const [newOriginTitle, setNewOriginTitle] = useState('پایانه و انبار مرکزی حامی (فتح)');
  const [newDestTitle, setNewDestTitle] = useState('شهرک صنعتی کاسپین قزوین');
  const [newDistanceKm, setNewDistanceKm] = useState('140');
  const [savingMission, setSavingMission] = useState(false);

  // Quick Driver Sync State (همگام‌سازی پرسنل و ناوگان)
  const [syncCode, setSyncCode] = useState('1');
  const [syncDriver, setSyncDriver] = useState('');
  const [syncPhone, setSyncPhone] = useState('');
  const [syncingDriver, setSyncingDriver] = useState(false);

  // Fuel Management State (مدیریت و تحلیل سوخت‌گیری و مراحل پیمایش)
  const [fuelTab, setFuelTab] = useState<'analysis' | 'stages'>('analysis');
  const [fuelModalOpen, setFuelModalOpen] = useState(false);
  const [fuelVehicleId, setFuelVehicleId] = useState('');
  const [fuelVehicleCode, setFuelVehicleCode] = useState('');
  const [fuelVehicleName, setFuelVehicleName] = useState('');
  const [fuelDate, setFuelDate] = useState(localDateString());
  const [fuelTime, setFuelTime] = useState('08:30');
  const [fuelOdometer, setFuelOdometer] = useState('');
  const [fuelLiters, setFuelLiters] = useState('110');
  const [fuelType, setFuelType] = useState<FuelType>('diesel');
  const [fuelPricePerLiter, setFuelPricePerLiter] = useState('600');
  const [fuelTotalCost, setFuelTotalCost] = useState('66000');
  const [fuelGasStation, setFuelGasStation] = useState('جایگاه اختصاصی ۲۱۴ فتح (بزرگراه متوسلیان)');
  const [fuelFullTank, setFuelFullTank] = useState(true);
  const [fuelNotes, setFuelNotes] = useState('');
  const [savingFuel, setSavingFuel] = useState(false);
  const [showFuelTrendWidget, setShowFuelTrendWidget] = useState(true);

  const [selectedDate, setSelectedDate] = useState(dailyDate || localDateString());

  const cleanVehicles = useMemo(() => vehicles.filter(validPosition), [vehicles]);
  const selected = useMemo(
    () => cleanVehicles.find((v) => v.id === selectedId),
    [cleanVehicles, selectedId]
  );

  const filtered = useMemo(() => {
    return cleanVehicles.filter((v) => {
      const matchesCategory = categoryFilter === 'all' || v.category === categoryFilter;
      const isOnline = v.online !== false;
      const isMoving = isOnline && (v.speedKph ?? 0) > 0;
      const isStopped = isOnline && (v.speedKph ?? 0) === 0;
      const matchesStatus =
        statusFilter === 'all' ||
        (statusFilter === 'moving' && isMoving) ||
        (statusFilter === 'stopped' && isStopped) ||
        (statusFilter === 'offline' && !isOnline);

      const q = search.trim().toLocaleLowerCase('fa-IR');
      const matchesSearch =
        !q ||
        `${v.name} ${v.driverName ?? ''} ${v.vehicleCode} ${v.plateNumber ?? ''} ${v.id}`
          .toLocaleLowerCase('fa-IR')
          .includes(q);
      return matchesCategory && matchesStatus && matchesSearch;
    });
  }, [cleanVehicles, categoryFilter, statusFilter, search]);

  const categoryCounts = useMemo(
    () =>
      Object.fromEntries(
        (Object.keys(categories) as VehicleCategory[]).map((cat) => [
          cat,
          cleanVehicles.filter((v) => v.category === cat).length,
        ])
      ) as Record<VehicleCategory, number>,
    [categories, cleanVehicles]
  );

  const movingCount = useMemo(
    () => cleanVehicles.filter((v) => v.online !== false && (v.speedKph ?? 0) > 0).length,
    [cleanVehicles]
  );
  const stoppedCount = useMemo(
    () => cleanVehicles.filter((v) => v.online !== false && (v.speedKph ?? 0) === 0).length,
    [cleanVehicles]
  );
  const offlineCount = useMemo(
    () => cleanVehicles.filter((v) => v.online === false).length,
    [cleanVehicles]
  );

  // Maintenance Statistics Calculations
  const overdueMaintCount = useMemo(
    () => maintenanceStatuses.filter((s) => s.overallStatus === 'overdue').length,
    [maintenanceStatuses]
  );
  const dueSoonMaintCount = useMemo(
    () => maintenanceStatuses.filter((s) => s.overallStatus === 'due_soon').length,
    [maintenanceStatuses]
  );

  // Filtered Maintenance Statuses for the Drawer
  const filteredMaintStatuses = useMemo(() => {
    return maintenanceStatuses.filter((item) => {
      if (maintStatusFilter === 'overdue' && item.overallStatus !== 'overdue') return false;
      if (maintStatusFilter === 'due_soon' && item.overallStatus !== 'due_soon') return false;
      if (maintStatusFilter === 'nominal' && item.overallStatus !== 'nominal') return false;

      if (maintServiceFilter !== 'all') {
        const hasService = item.services.some((s) => s.serviceType === maintServiceFilter);
        if (!hasService) return false;
      }

      if (maintSearch.trim()) {
        const q = maintSearch.trim().toLocaleLowerCase('fa-IR');
        const match =
          item.vehicleName.toLocaleLowerCase('fa-IR').includes(q) ||
          item.vehicleCode.includes(q) ||
          (item.driverName && item.driverName.toLocaleLowerCase('fa-IR').includes(q)) ||
          (item.plateNumber && item.plateNumber.includes(q));
        if (!match) return false;
      }
      return true;
    });
  }, [maintenanceStatuses, maintStatusFilter, maintServiceFilter, maintSearch]);

  const selectedVehicleMaintStatus = useMemo(
    () => (selected ? maintenanceStatuses.find((s) => s.vehicleId === selected.id) : null),
    [selected, maintenanceStatuses]
  );

  const route = useMemo(
    () =>
      selected?.trackHistory?.filter(
        (p) =>
          Number.isFinite(p.latitude) &&
          Number.isFinite(p.longitude) &&
          Math.abs(p.latitude) > 0.01 &&
          Math.abs(p.longitude) > 0.01
      ) ?? [],
    [selected?.trackHistory]
  );

  const playbackPoints = useMemo(
    () => (route.length ? route.slice(0, Math.min(route.length, routeIndex + 1)) : []),
    [route, routeIndex]
  );

  const driverRows = useMemo(
    () =>
      drivers.length
        ? drivers
        : cleanVehicles
            .filter((v) => v.driverName)
            .map((v) => ({
              id: v.id,
              name: v.driverName || '—',
              vehicleId: v.id,
              score: v.driverScore ?? 96,
              speedingEvents: (v.speedKph ?? 0) > 85 ? 1 : 0,
              harshEvents: 0,
              idleMinutes: v.idleMinutes,
              distanceKm: v.distanceTodayKm,
            })),
    [drivers, cleanVehicles]
  );

  // Toast notice auto-dismiss
  useEffect(() => {
    if (!notice) return;
    const timer = window.setTimeout(() => setNotice(''), 2800);
    return () => window.clearTimeout(timer);
  }, [notice]);

  useEffect(() => {
    if (dailyDate) setSelectedDate(dailyDate);
  }, [dailyDate]);

  // Playback timer
  useEffect(() => {
    if (!routePlaying || route.length < 2) return;
    const intervalMs = Math.round(700 / routeSpeedMultiplier);
    const timer = window.setInterval(() => {
      setRouteIndex((i) => {
        if (i >= route.length - 1) {
          setRoutePlaying(false);
          return i;
        }
        return i + 1;
      });
    }, intervalMs);
    return () => window.clearInterval(timer);
  }, [routePlaying, route.length, routeSpeedMultiplier]);

  // Reverse geocode selected vehicle
  useEffect(() => {
    if (!selected || !validPosition(selected)) return;
    if (selected.locationLabel || resolvedAddress[selected.id]) return;
    let cancelled = false;
    fetch(
      `/api/reverse-geocode?lat=${encodeURIComponent(selected.latitude)}&lon=${encodeURIComponent(selected.longitude)}`
    )
      .then((r) => r.json())
      .then((data) => {
        if (!cancelled && data?.address) {
          setResolvedAddress((prev) => ({ ...prev, [selected.id]: data.address }));
        }
      })
      .catch(() => undefined);
    return () => {
      cancelled = true;
    };
  }, [selected, resolvedAddress]);

  const selectVehicle = useCallback(
    (vehicle: FleetVehicle) => {
      setSelectedId(vehicle.id);
      onVehicleSelect?.(vehicle);
    },
    [onVehicleSelect]
  );

  // Calculate Road Navigation Route
  const calculateNavigationRoute = useCallback(
    async (
      fromCoord: [number, number],
      fromLabel: string,
      toCoord: [number, number],
      toLabel: string
    ) => {
      setNavLoading(true);
      try {
        const resp = await fetch(
          `/api/navigate?fromLat=${fromCoord[0]}&fromLon=${fromCoord[1]}&toLat=${toCoord[0]}&toLon=${toCoord[1]}`
        );
        if (!resp.ok) throw new Error('خطا در محاسبه مسیر پیمایش');
        const data = await resp.json();
        setActiveNavRoute({
          fromLabel,
          toLabel,
          fromCoord,
          toCoord,
          distanceKm: data.distanceKm,
          durationMinutes: data.durationMinutes,
          coordinates: data.coordinates || [fromCoord, toCoord],
          steps: data.steps || [],
        });
        setActiveDrawer('navigation');
        setNotice(`مسیر پیمایش تا «${toLabel}» محاسبه شد (${numberFa(data.distanceKm)} کیلومتر)`);
      } catch {
        setNotice('محاسبه مسیر جاده‌ای در حال حاضر در دسترس نیست.');
      } finally {
        setNavLoading(false);
        setNavPickMode(false);
      }
    },
    []
  );

  // Toggle User's Live GPS Tracking
  const toggleUserGps = useCallback(() => {
    if (userGpsActive) {
      if (watchIdRef.current !== null) {
        navigator.geolocation.clearWatch(watchIdRef.current);
        watchIdRef.current = null;
      }
      setUserGpsActive(false);
      setUserGps(null);
      setNotice('ردیاب موقعیت دستگاه شما خاموش شد');
      return;
    }
    if (!('geolocation' in navigator)) {
      setNotice('مرورگر شما از موقعیت‌یاب GPS پشتیبانی نمی‌کند');
      return;
    }
    setNotice('در حال دریافت موقعیت GPS شما...');
    const id = navigator.geolocation.watchPosition(
      (pos) => {
        setUserGps({
          latitude: pos.coords.latitude,
          longitude: pos.coords.longitude,
          accuracy: pos.coords.accuracy,
          speed: pos.coords.speed ? Math.round(pos.coords.speed * 3.6) : 0,
        });
        setUserGpsActive(true);
      },
      () => {
        setNotice('دسترسی به موقعیت مکانی مرورگر مجاز نشد');
        setUserGpsActive(false);
      },
      { enableHighAccuracy: true, maximumAge: 10000, timeout: 15000 }
    );
    watchIdRef.current = id;
  }, [userGpsActive]);

  useEffect(() => {
    return () => {
      if (watchIdRef.current !== null) {
        navigator.geolocation.clearWatch(watchIdRef.current);
      }
    };
  }, []);

  // Leaflet Map Instance & Layers Refs
  const mapContainerRef = useRef<HTMLDivElement | null>(null);
  const mapRef = useRef<L.Map | null>(null);
  const baseLayerRef = useRef<L.Layer | null>(null);
  const markersLayerRef = useRef<L.LayerGroup | null>(null);
  const geofencesLayerRef = useRef<L.LayerGroup | null>(null);
  const playbackLayerRef = useRef<L.LayerGroup | null>(null);
  const navRouteLayerRef = useRef<L.LayerGroup | null>(null);
  const userGpsLayerRef = useRef<L.LayerGroup | null>(null);
  const fittedOnceRef = useRef(false);
  const lastSelectedIdRef = useRef<string | null>(null);

  const zonePickingRef = useRef(zonePicking);
  zonePickingRef.current = zonePicking;
  const navPickModeRef = useRef(navPickMode);
  navPickModeRef.current = navPickMode;
  const selectedVehicleRef = useRef(selected);
  selectedVehicleRef.current = selected;
  const userGpsRef = useRef(userGps);
  userGpsRef.current = userGps;

  // Initialize Leaflet Map
  useEffect(() => {
    const el = mapContainerRef.current;
    if (!el || mapRef.current) return;

    const map = L.map(el, {
      center: [35.6973, 51.2466],
      zoom: 11,
      zoomControl: false,
      attributionControl: false,
    });

    L.control.zoom({ position: 'topleft' }).addTo(map);

    markersLayerRef.current = L.layerGroup().addTo(map);
    geofencesLayerRef.current = L.layerGroup().addTo(map);
    playbackLayerRef.current = L.layerGroup().addTo(map);
    navRouteLayerRef.current = L.layerGroup().addTo(map);
    userGpsLayerRef.current = L.layerGroup().addTo(map);

    map.on('click', (e: L.LeafletMouseEvent) => {
      const { lat, lng } = e.latlng;
      if (zonePickingRef.current) {
        setZoneLat(lat.toFixed(6));
        setZoneLon(lng.toFixed(6));
        setZonePicking(false);
        setNotice('مرکز محدوده روی نقشه انتخاب شد');
        return;
      }
      if (navPickModeRef.current) {
        const sel = selectedVehicleRef.current;
        const usr = userGpsRef.current;
        if (sel) {
          void calculateNavigationRoute(
            [sel.latitude, sel.longitude],
            sel.name,
            [lat, lng],
            `مقصد انتخابی (${lat.toFixed(4)}, ${lng.toFixed(4)})`
          );
        } else if (usr) {
          void calculateNavigationRoute(
            [usr.latitude, usr.longitude],
            'موقعیت من',
            [lat, lng],
            `مقصد انتخابی (${lat.toFixed(4)}, ${lng.toFixed(4)})`
          );
        } else {
          setNotice('ابتدا یک خودرو یا «موقعیت من» را به‌عنوان مبدأ انتخاب کنید');
          setNavPickMode(false);
        }
      }
    });

    mapRef.current = map;

    const ro = new ResizeObserver(() => {
      map.invalidateSize({ animate: false });
    });
    ro.observe(el);

    return () => {
      ro.disconnect();
      map.remove();
      mapRef.current = null;
    };
  }, [calculateNavigationRoute]);

  // Switch Base Map Tile Layer
  useEffect(() => {
    const map = mapRef.current;
    if (!map) return;

    if (baseLayerRef.current && map.hasLayer(baseLayerRef.current)) {
      map.removeLayer(baseLayerRef.current);
      baseLayerRef.current = null;
    }

    let cancelled = false;

    if (mapStyle === 'vector') {
      const fallbackTile = L.tileLayer(
        'https://{s}.basemaps.cartocdn.com/rastertiles/voyager/{z}/{x}/{y}{r}.png',
        { subdomains: 'abcd', maxZoom: 19 }
      ).addTo(map);
      baseLayerRef.current = fallbackTile;

      void Promise.all([
        import('@maplibre/maplibre-gl-leaflet'),
        import('maplibre-gl'),
        import('maplibre-gl/dist/maplibre-gl.css'),
      ])
        .then(([plugin, lib]) => {
          if (cancelled || !mapRef.current) return;
          lib.setWorkerUrl(workerUrl);
          const vectorLayer = plugin.maplibreGL({
            style: 'https://tiles.openfreemap.org/styles/liberty',
            attributionControl: false,
          });
          vectorLayer.addTo(mapRef.current);
          if (baseLayerRef.current && mapRef.current.hasLayer(baseLayerRef.current)) {
            mapRef.current.removeLayer(baseLayerRef.current);
          }
          baseLayerRef.current = vectorLayer;
        })
        .catch(() => undefined);
    } else if (mapStyle === 'dark') {
      const darkTile = L.tileLayer(
        'https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png',
        { subdomains: 'abcd', maxZoom: 19 }
      ).addTo(map);
      baseLayerRef.current = darkTile;
    } else if (mapStyle === 'satellite') {
      const satTile = L.tileLayer(
        'https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}',
        { maxZoom: 18 }
      ).addTo(map);
      baseLayerRef.current = satTile;
    } else {
      const voyagerTile = L.tileLayer(
        'https://{s}.basemaps.cartocdn.com/rastertiles/voyager/{z}/{x}/{y}{r}.png',
        { subdomains: 'abcd', maxZoom: 19 }
      ).addTo(map);
      baseLayerRef.current = voyagerTile;
    }

    return () => {
      cancelled = true;
    };
  }, [mapStyle]);

  // Render Fleet Vehicle Markers on Map
  useEffect(() => {
    const group = markersLayerRef.current;
    if (!group) return;
    group.clearLayers();

    filtered.forEach((vehicle, index) => {
      const catMeta = categories[vehicle.category] || categories.other;
      const isSelected = selected?.id === vehicle.id;
      const isOnline = vehicle.online !== false;
      const isMoving = isOnline && (vehicle.speedKph ?? 0) > 0;
      const codeLabel =
        /^\d+$/.test(vehicle.vehicleCode) && vehicle.vehicleCode.length <= 4
          ? vehicle.vehicleCode
          : String(index + 1).padStart(2, '0');

      const mission =
        vehicle.activeMission ||
        missions.find(
          (m) =>
            m.status !== 'completed' &&
            (String(m.vehicleId) === String(vehicle.id) ||
              (m.vehicleCode && String(m.vehicleCode) === String(vehicle.vehicleCode)))
        );
      const hasActiveWaybill = Boolean(mission);
      const waybillStatus = mission?.status || null;
      const tripProgressPercent = mission?.progressPercent ?? vehicle.tripProgressPercent;

      const icon = makeVehicleIcon(
        codeLabel,
        catMeta.markerClass,
        isSelected,
        isOnline,
        isMoving,
        hasActiveWaybill,
        waybillStatus,
        tripProgressPercent
      );

      const statusClass = !isOnline
        ? 'hami-popup-status-offline'
        : isMoving
          ? 'hami-popup-status-moving'
          : 'hami-popup-status-stopped';

      const missionSection = mission
        ? `
        <div style="margin-top:6px; padding:6px 8px; background:#f0fdf4; border:1px solid #86efac; border-radius:8px; font-size:11px;">
          <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:4px;">
            <strong style="color:#166534; font-size:11px;">📜 بارنامه: ${mission.waybillNumber}</strong>
            <span style="font-size:9.5px; font-weight:800; background:#dcfce7; color:#15803d; padding:1px 6px; border-radius:4px;">
              ${mission.status === 'in_transit' ? '🟢 در مسیر' : mission.status === 'loading' ? '🟡 بارگیری' : mission.status === 'unloaded' ? '🔵 تخلیه شد' : 'اتمام'}
            </span>
          </div>
          <div style="color:#1e293b; font-weight:700; margin-bottom:2px; font-size:11px;">${mission.cargoTitle}</div>
          <div style="color:#475569; font-size:10px; margin-bottom:4px;">مقصد: ${mission.destination.title}</div>
          <div style="background:#e2e8f0; height:6px; border-radius:4px; overflow:hidden; margin-bottom:4px;">
            <div style="background:#10b981; width:${mission.progressPercent}%; height:100%; border-radius:4px;"></div>
          </div>
          <div style="display:flex; justify-content:space-between; font-size:10px; color:#334155; font-weight:600;">
            <span>پیشرفت: <strong style="color:#047857;">${numberFa(mission.progressPercent)}٪</strong></span>
            <span style="color:#0369a1;">${mission.etaLabel || ''}</span>
          </div>
        </div>
      `
        : '';

      const marker = L.marker([vehicle.latitude, vehicle.longitude], { icon });
      marker.bindPopup(
        `<div class="hami-popup">
          <div class="hami-popup-title">${vehicle.name}</div>
          <div class="hami-popup-meta">${catMeta.label} · کد ${vehicle.vehicleCode} ${vehicle.driverName ? `· راننده: ${vehicle.driverName}` : ''}</div>
          ${vehicle.plateNumber ? `<div class="hami-popup-plate">پلاک: ${vehicle.plateNumber}</div>` : ''}
          <div class="${statusClass}">
            ${!isOnline ? 'آفلاین' : isMoving ? `در حرکت (${numberFa(vehicle.speedKph ?? 0)} km/h)` : 'متوقف (۰ km/h)'}
          </div>
          ${missionSection}
        </div>`
      );
      marker.on('click', () => {
        selectVehicle(vehicle);
      });
      marker.addTo(group);
    });
  }, [filtered, categories, selected?.id, selectVehicle, missions]);

  // Auto-Fit Bounds or FlyTo Selected Vehicle
  useEffect(() => {
    const map = mapRef.current;
    if (!map) return;

    const currentSelectionId = selected?.id ?? null;
    const selectionChanged = currentSelectionId !== lastSelectedIdRef.current;

    if (selected && validPosition(selected) && selectionChanged) {
      map.flyTo([selected.latitude, selected.longitude], Math.max(map.getZoom(), 14), {
        duration: 0.45,
      });
      fittedOnceRef.current = true;
    } else if (cleanVehicles.length > 0 && !fittedOnceRef.current) {
      const coords: Array<[number, number]> = cleanVehicles.map((v) => [
        v.latitude,
        v.longitude,
      ]);
      if (coords.length === 1) {
        map.setView(coords[0], 13);
      } else {
        map.fitBounds(L.latLngBounds(coords).pad(0.15), { maxZoom: 13, animate: false });
      }
      fittedOnceRef.current = true;
    }

    lastSelectedIdRef.current = currentSelectionId;
  }, [cleanVehicles, selected]);

  const fitAllVehicles = useCallback(() => {
    const map = mapRef.current;
    if (!map || !cleanVehicles.length) return;
    setSelectedId(null);
    const coords: Array<[number, number]> = cleanVehicles.map((v) => [v.latitude, v.longitude]);
    if (coords.length === 1) {
      map.setView(coords[0], 13);
    } else {
      map.fitBounds(L.latLngBounds(coords).pad(0.15), { maxZoom: 13 });
    }
  }, [cleanVehicles]);

  // Render Geofence Circles
  useEffect(() => {
    const group = geofencesLayerRef.current;
    if (!group) return;
    group.clearLayers();
    if (!geofencesVisible) return;

    geofences
      .filter((z) => z.active !== false && z.radiusMeters > 0)
      .forEach((zone) => {
        const circle = L.circle([zone.latitude, zone.longitude], {
          radius: zone.radiusMeters,
          color: zone.color || '#2563eb',
          fillColor: zone.color || '#2563eb',
          fillOpacity: 0.12,
          weight: 2,
          dashArray: '6 5',
        });
        circle.bindTooltip(zone.name, { direction: 'top' });
        circle.addTo(group);
      });
  }, [geofences, geofencesVisible]);

  // Render Historical Route Playback Polyline & Stops
  useEffect(() => {
    const group = playbackLayerRef.current;
    if (!group) return;
    group.clearLayers();
    if (!routeOpen || playbackPoints.length === 0) return;

    const routeColor = selected ? categories[selected.category]?.color || '#2563eb' : '#2563eb';
    const latlngs: Array<[number, number]> = playbackPoints.map((p) => [
      p.latitude,
      p.longitude,
    ]);

    if (latlngs.length > 1) {
      L.polyline(latlngs, {
        color: routeColor,
        weight: 5,
        opacity: 0.88,
        lineCap: 'round',
      }).addTo(group);
    }

    (selected?.routeStops || []).forEach((stop, idx) => {
      const stopMarker = L.marker([stop.latitude, stop.longitude], {
        icon: L.divIcon({
          className: 'fleet-marker-wrap',
          html: `<span class="stop-pin-marker" title="توقف ${stop.durationMinutes} دقیقه">P${idx + 1}</span>`,
          iconSize: [24, 24],
          iconAnchor: [12, 12],
        }),
      });
      stopMarker.bindPopup(
        `<div class="hami-popup">
          <div class="hami-popup-title">توقف شماره ${numberFa(idx + 1)}</div>
          <div class="hami-popup-meta">مدت توقف: ${numberFa(stop.durationMinutes)} دقیقه</div>
          <div class="hami-popup-meta">از ${formatTime(stop.startTime)} تا ${formatTime(stop.endTime)}</div>
        </div>`
      );
      stopMarker.addTo(group);
    });

    const head = playbackPoints[playbackPoints.length - 1];
    L.circleMarker([head.latitude, head.longitude], {
      radius: 9,
      color: '#ffffff',
      weight: 3,
      fillColor: routeColor,
      fillOpacity: 1,
    })
      .bindTooltip(
        `${formatTime(head.timestamp)} · ${numberFa(head.speedKph ?? 0)} km/h`,
        { permanent: false, direction: 'top' }
      )
      .addTo(group);
  }, [routeOpen, playbackPoints, selected, categories]);

  // Render Active Road Navigation Route
  useEffect(() => {
    const group = navRouteLayerRef.current;
    const map = mapRef.current;
    if (!group) return;
    group.clearLayers();
    if (!activeNavRoute) return;

    const poly = L.polyline(activeNavRoute.coordinates, {
      color: '#059669',
      weight: 6,
      opacity: 0.9,
      lineCap: 'round',
    }).addTo(group);

    const destMarker = L.marker(activeNavRoute.toCoord, {
      icon: L.divIcon({
        className: 'fleet-marker-wrap',
        html: `<span class="dest-pin-marker">م</span>`,
        iconSize: [30, 30],
        iconAnchor: [15, 15],
      }),
    });
    destMarker.bindPopup(
      `<div class="hami-popup">
        <div class="hami-popup-title">مقصد پیمایش: ${activeNavRoute.toLabel}</div>
        <div class="hami-popup-status-moving">
          مسافت: ${numberFa(activeNavRoute.distanceKm)} کیلومتر · زمان: ~${numberFa(activeNavRoute.durationMinutes)} دقیقه
        </div>
      </div>`
    );
    destMarker.addTo(group);

    if (map && activeNavRoute.coordinates.length > 1) {
      map.fitBounds(poly.getBounds().pad(0.2), { maxZoom: 14 });
    }
  }, [activeNavRoute]);

  // Render User's Live GPS Marker
  useEffect(() => {
    const group = userGpsLayerRef.current;
    if (!group) return;
    group.clearLayers();
    if (!userGps) return;

    L.circle([userGps.latitude, userGps.longitude], {
      radius: Math.max(30, Math.min(userGps.accuracy, 500)),
      color: '#0284c7',
      fillColor: '#0284c7',
      fillOpacity: 0.12,
      weight: 1,
    }).addTo(group);

    L.marker([userGps.latitude, userGps.longitude], {
      icon: L.divIcon({
        className: 'fleet-marker-wrap',
        html: `<span class="user-gps-marker"></span>`,
        iconSize: [22, 22],
        iconAnchor: [11, 11],
      }),
    })
      .bindPopup(
        `<div class="hami-popup">
          <div class="hami-popup-title">موقعیت زنده شما (GPS)</div>
          <div class="hami-popup-meta">دقت: ~${numberFa(Math.round(userGps.accuracy))} متر</div>
        </div>`
      )
      .addTo(group);
  }, [userGps]);

  const shareVehicle = async (vehicle: FleetVehicle) => {
    const url = neshanUrl(vehicle.latitude, vehicle.longitude);
    const text = `سامانه پیمایش حامی\n${vehicle.name} · کد ${vehicle.vehicleCode}${vehicle.driverName ? ` · راننده: ${vehicle.driverName}` : ''}\nموقعیت: ${vehicle.latitude.toFixed(6)}, ${vehicle.longitude.toFixed(6)}\n${url}`;
    try {
      if (navigator.share) {
        await navigator.share({ title: `موقعیت ${vehicle.name} در حامی`, text, url });
      } else {
        await navigator.clipboard.writeText(text);
        setNotice('لینک و مختصات موقعیت در حافظه کپی شد');
      }
    } catch (e) {
      if (e instanceof Error && e.name === 'AbortError') return;
      try {
        await navigator.clipboard.writeText(text);
        setNotice('لینک و مختصات موقعیت در حافظه کپی شد');
      } catch {
        setNotice('امکان کپی خودکار در این مرورگر فعال نیست');
      }
    }
  };

  const exportCsv = () => {
    const rows = [
      [
        'کد وسیله',
        'نام وسیله',
        'دسته',
        'راننده',
        'پلاک',
        'وضعیت',
        'سرعت (km/h)',
        'عرض جغرافیایی',
        'طول جغرافیایی',
        'آخرین دریافت',
      ],
      ...filtered.map((v) => [
        v.vehicleCode,
        v.name,
        categories[v.category]?.label || v.category,
        v.driverName ?? '',
        v.plateNumber ?? '',
        v.online === false ? 'آفلاین' : (v.speedKph ?? 0) > 0 ? 'در حال حرکت' : 'متوقف',
        String(v.speedKph ?? 0),
        String(v.latitude),
        String(v.longitude),
        formatTime(v.lastSeen),
      ]),
    ];
    const csv =
      '\ufeff' +
      rows
        .map((row) => row.map((cell) => `"${String(cell).replace(/"/g, '""')}"`).join(','))
        .join('\r\n');
    const link = document.createElement('a');
    link.href = URL.createObjectURL(new Blob([csv], { type: 'text/csv;charset=utf-8' }));
    link.download = `hami-fleet-${new Date().toISOString().slice(0, 10)}.csv`;
    link.click();
    URL.revokeObjectURL(link.href);
    setNotice('فایل گزارش اکسل (CSV) ناوگان دانلود شد');
  };

  const beginRoutePlayback = () => {
    if (!selected) return;
    if (routeLoading) {
      setNotice('در حال بارگذاری نقاط مسیر از سرور...');
      return;
    }
    if (route.length < 2) {
      setNotice('برای این خودرو در تاریخ انتخابی مسیر حرکتی ثبت نشده است');
      return;
    }
    setRouteOpen(true);
    setRouteIndex(0);
    setRoutePlaying(true);
    const map = mapRef.current;
    if (map) {
      const coords: Array<[number, number]> = route.map((p) => [p.latitude, p.longitude]);
      map.fitBounds(L.latLngBounds(coords).pad(0.18), { maxZoom: 14 });
    }
  };

  const searchDestinationPlace = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!placeQuery.trim()) return;
    setPlaceSearching(true);
    try {
      const resp = await fetch(`/api/geocode?q=${encodeURIComponent(placeQuery.trim())}`);
      const data = await resp.json();
      setPlaceResults(Array.isArray(data.results) ? data.results : []);
      if (!data.results?.length) {
        setNotice('مکانی با این عبارت یافت نشد');
      }
    } catch {
      setNotice('خطا در جست‌وجوی آدرس');
    } finally {
      setPlaceSearching(false);
    }
  };

  const openEditModal = (v: FleetVehicle) => {
    setEditingVehicle(v);
    setEditName(v.name);
    setEditDriver(v.driverName || '');
    setEditCode(v.vehicleCode);
    setEditCategory(v.category);
    setEditPlate(v.plateNumber || '');
    setEditServiceKm(v.nextServiceKm != null ? String(v.nextServiceKm) : '');
  };

  const handleSaveMeta = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingVehicle || !onVehicleMetaSave) return;
    setSavingMeta(true);
    try {
      await onVehicleMetaSave({
        imei: editingVehicle.id,
        name: editName,
        driverName: editDriver,
        vehicleCode: editCode,
        category: editCategory,
        plateNumber: editPlate,
        nextServiceKm: editServiceKm === '' ? '' : Number(editServiceKm),
      });
      setEditingVehicle(null);
      setNotice('اطلاعات خودرو و راننده با موفقیت ذخیره شد');
    } catch {
      setNotice('ذخیره اطلاعات خودرو ناموفق بود');
    } finally {
      setSavingMeta(false);
    }
  };

  // Open Record Service (Oil Change) Modal
  const openRecordLogModal = (target: {
    vehicleId: string;
    vehicleName: string;
    currentKm?: number;
    serviceType?: ServiceType;
    title?: string;
  }) => {
    setLogVehicleId(target.vehicleId);
    setLogVehicleName(target.vehicleName);
    setLogServiceType(target.serviceType || 'engine_oil');
    setLogTitle(target.title || SERVICE_TYPE_LABELS[target.serviceType || 'engine_oil']);
    setLogServiceKm(target.currentKm != null ? String(target.currentKm) : '40000');
    setLogServiceDate(localDateString());
    setLogOilBrand(
      target.serviceType === 'engine_oil'
        ? 'بهران سوپر توربو دیزل 15W-40'
        : target.serviceType === 'gearbox_oil'
          ? 'ایرانول رویال دیزل 85W-90'
          : 'اصلی شرکتی'
    );
    setLogWorkshopName('پایانه فتح / شادآباد');
    setLogTechnicianName('');
    setLogCostToman(target.serviceType === 'engine_oil' ? '2850000' : '1500000');
    setLogNotes(`سرویس ${target.title || 'تعویض روغن'} با فیلتر سرکان`);
    setLogModalOpen(true);
  };

  // Open Add/Edit Maintenance Rule Modal
  const openRuleModal = (rule?: MaintenanceRule) => {
    if (rule) {
      setEditingRuleId(rule.id);
      setRuleTitle(rule.title);
      setRuleServiceType(rule.serviceType);
      setRuleScope(rule.scope);
      setRuleCategory(rule.category || 'khavar');
      setRuleVehicleId(rule.vehicleId || '');
      setRuleKmInterval(String(rule.kmInterval));
      setRuleDaysInterval(String(rule.daysInterval));
      setRuleWarningKmLead(String(rule.warningKmLead));
      setRuleWarningDaysLead(String(rule.warningDaysLead));
    } else {
      setEditingRuleId(null);
      setRuleTitle('تعویض روغن موتور و فیلتر روغن');
      setRuleServiceType('engine_oil');
      setRuleScope('category');
      setRuleCategory('khavar');
      setRuleVehicleId(selected?.id || cleanVehicles[0]?.id || '');
      setRuleKmInterval('5000');
      setRuleDaysInterval('90');
      setRuleWarningKmLead('500');
      setRuleWarningDaysLead('10');
    }
    setRuleModalOpen(true);
  };

  const handleSaveRule = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!onMaintenanceRuleSave) return;
    setSavingRule(true);
    try {
      await onMaintenanceRuleSave({
        id: editingRuleId || `rule-${Date.now()}`,
        serviceType: ruleServiceType,
        title: ruleTitle.trim() || SERVICE_TYPE_LABELS[ruleServiceType],
        scope: ruleScope,
        category: ruleScope === 'category' ? ruleCategory : undefined,
        vehicleId: ruleScope === 'vehicle' ? ruleVehicleId : undefined,
        kmInterval: Math.max(500, Number(ruleKmInterval) || 5000),
        daysInterval: Math.max(7, Number(ruleDaysInterval) || 90),
        warningKmLead: Math.max(50, Number(ruleWarningKmLead) || 500),
        warningDaysLead: Math.max(1, Number(ruleWarningDaysLead) || 10),
      });
      setRuleModalOpen(false);
      setNotice('قانون سرویس با لیمیت‌های کیلومتری و روزانه با موفقیت ثبت شد');
    } catch {
      setNotice('ثبت قانون سرویس ناموفق بود');
    } finally {
      setSavingRule(false);
    }
  };

  const handleRecordLog = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!onServiceLogRecord) return;
    setSavingLog(true);
    try {
      await onServiceLogRecord({
        vehicleId: logVehicleId,
        vehicleName: logVehicleName,
        serviceType: logServiceType,
        title: logTitle.trim() || SERVICE_TYPE_LABELS[logServiceType],
        serviceKm: Number(logServiceKm) || 0,
        serviceDate: logServiceDate,
        oilBrand: logOilBrand.trim() || undefined,
        workshopName: logWorkshopName.trim() || undefined,
        technicianName: logTechnicianName.trim() || undefined,
        costToman: logCostToman ? Number(logCostToman) : undefined,
        notes: logNotes.trim() || undefined,
      });
      setLogModalOpen(false);
      setNotice(`تعویض روغن / سرویس برای «${logVehicleName}» با موفقیت ثبت و کنتور لیمیت‌ها ریست شد`);
    } catch {
      setNotice('ثبت سرویس ناموفق بود');
    } finally {
      setSavingLog(false);
    }
  };

  // Missions Handlers
  const handleCreateMissionSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!onMissionCreate) return;
    const targetVeh = cleanVehicles.find((v) => v.vehicleCode === newVehicleCode);
    if (!targetVeh && !newVehicleCode) {
      setNotice('لطفاً خودرو را انتخاب کنید');
      return;
    }
    setSavingMission(true);
    try {
      await onMissionCreate({
        waybillNumber: newWaybillNumber.trim() || `ب-${Math.floor(10000 + Math.random() * 90000)}`,
        vehicleCode: newVehicleCode || targetVeh?.vehicleCode || '1',
        vehicleName: targetVeh?.name || `خودرو کد ${newVehicleCode}`,
        vehicleId: targetVeh?.id || '355139085795257',
        category: targetVeh?.category || 'khavar',
        driverName: newDriverName.trim() || targetVeh?.driverName || 'راننده ثبت نشده',
        driverPhone: newDriverPhone.trim() || undefined,
        cargoTitle: newCargoTitle.trim() || 'محموله عمومی',
        weightTons: Number(newCargoWeight) || 3.5,
        origin: {
          title: newOriginTitle.trim() || 'تهران، انبار مرکزی حامی',
          latitude: targetVeh?.latitude || 35.6892,
          longitude: targetVeh?.longitude || 51.389,
        },
        destination: {
          title: newDestTitle.trim() || 'قزوین، شهرک صنعتی کاسپین',
          latitude: 36.2688,
          longitude: 50.0041,
        },
        totalDistanceKm: Number(newDistanceKm) || 120,
        currentDistanceCoveredKm: 0,
        progressPercent: 0,
        status: 'loading',
      });
      setNewWaybillNumber('');
      setNewCargoTitle('');
      setMissionsTab('active');
      setNotice('بارنامه جدید با موفقیت صادر شد و مأموریت فعال گردید');
    } catch {
      setNotice('خطا در صدور بارنامه');
    } finally {
      setSavingMission(false);
    }
  };

  const handleMissionStatusUpdate = async (missionId: string, status: MissionStatus) => {
    if (!onMissionStatusChange) return;
    try {
      await onMissionStatusChange(missionId, status);
      const labels: Record<MissionStatus, string> = {
        loading: 'در حال بارگیری',
        in_transit: 'در مسیر به سمت مقصد',
        unloaded: 'تخلیه شد',
        completed: 'مأموریت پایان یافت',
      };
      setNotice(`وضعیت مأموریت به «${labels[status]}» تغییر یافت`);
    } catch {
      setNotice('خطا در تغییر وضعیت مأموریت');
    }
  };

  const handleMissionRemove = async (missionId: string) => {
    if (!onMissionDelete) return;
    if (!confirm('آیا از حذف این مأموریت و لغو بارنامه اطمینان دارید؟')) return;
    try {
      await onMissionDelete(missionId);
      setNotice('بارنامه و مأموریت حذف گردید');
    } catch {
      setNotice('خطا در حذف مأموریت');
    }
  };

  const handleDriverSyncSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!onDriverSync) return;
    if (!syncDriver.trim()) {
      setNotice('نام راننده الزامی است');
      return;
    }
    setSyncingDriver(true);
    try {
      await onDriverSync({
        vehicleCode: syncCode,
        driverName: syncDriver.trim(),
        driverPhone: syncPhone.trim() || undefined,
      });
      setNotice(`راننده کد ${syncCode} به «${syncDriver.trim()}» به‌روزرسانی شد و با اطلاعات دستگاه همگام گردید`);
      setSyncDriver('');
      setSyncPhone('');
    } catch {
      setNotice('خطا در همگام‌سازی پرسنل و ناوگان');
    } finally {
      setSyncingDriver(false);
    }
  };

  // Fuel Handlers
  const openNewFuelModal = (targetVehicle?: FleetVehicle) => {
    const v = targetVehicle || selected || cleanVehicles[0];
    if (v) {
      setFuelVehicleId(v.id);
      setFuelVehicleCode(v.vehicleCode);
      setFuelVehicleName(v.name);
      const approxKm = v.odometerKm != null && v.odometerKm > 0 ? v.odometerKm : 42500;
      setFuelOdometer(String(approxKm));
      setFuelType(v.category === 'nissan' ? 'petrol_regular' : 'diesel');
    }
    setFuelDate(localDateString());
    setFuelTime(
      new Date().toLocaleTimeString('fa-IR', { hour: '2-digit', minute: '2-digit', hour12: false })
    );
    setFuelLiters('100');
    setFuelPricePerLiter(v?.category === 'nissan' ? '3000' : '600');
    setFuelTotalCost(v?.category === 'nissan' ? '300000' : '60000');
    setFuelGasStation('جایگاه ۲۱۴ فتح (بزرگراه متوسلیان)');
    setFuelFullTank(true);
    setFuelNotes('');
    setFuelModalOpen(true);
  };

  const handleSaveFuelSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!onFuelLogCreate) return;
    setSavingFuel(true);
    try {
      const v = cleanVehicles.find((veh) => veh.id === fuelVehicleId);
      await onFuelLogCreate({
        vehicleId: fuelVehicleId,
        vehicleCode: fuelVehicleCode,
        vehicleName: fuelVehicleName,
        category: v?.category || 'khavar',
        date: fuelDate,
        time: fuelTime,
        odometerKm: Number(fuelOdometer) || 0,
        liters: Number(fuelLiters) || 0,
        fuelType: fuelType,
        unitPriceToman: Number(fuelPricePerLiter) || 600,
        totalCostToman: Number(fuelTotalCost) || 0,
        gasStation: fuelGasStation.trim() || 'جایگاه سوخت',
        fullTank: fuelFullTank,
        notes: fuelNotes.trim() || undefined,
      });
      setFuelModalOpen(false);
      setNotice(`سوخت‌گیری برای «${fuelVehicleName}» با موفقیت ثبت و تحلیل پیمایش به‌روزرسانی شد`);
    } catch {
      setNotice('خطا در ثبت سوخت‌گیری');
    } finally {
      setSavingFuel(false);
    }
  };

  const handleDeleteFuelLog = async (logId: string) => {
    if (!onFuelLogDelete) return;
    if (!confirm('آیا از حذف این رکورد سوخت‌گیری اطمینان دارید؟')) return;
    try {
      await onFuelLogDelete(logId);
      setNotice('رکورد سوخت‌گیری حذف شد');
    } catch {
      setNotice('خطا در حذف رکورد');
    }
  };

  const currentPlaybackPoint = playbackPoints[playbackPoints.length - 1];

  const activeMissionsCount = missions.filter((m) => m.status !== 'completed').length;
  const fuelUrgentCount = fuelAnalytics?.fleetSummary?.criticalCount || 0;

  return (
    <div
      ref={rootContainerRef}
      className={`relative w-screen h-screen overflow-hidden bg-slate-900 text-slate-900 select-none ${className}`}
      dir="rtl"
    >
      {/* 1. Full-Bleed Map (Covers 100% of Screen) */}
      <div ref={mapContainerRef} className="absolute inset-0 w-full h-full z-0 hami-leaflet-map" />

      {/* 2. Floating Search & Side-Menu Trigger Card (Top-Right Edge) */}
      <div className="absolute top-3 right-3 left-3 sm:left-auto sm:w-[500px] z-20 flex flex-col gap-2">
        <div className="bg-white/95 backdrop-blur-md rounded-2xl border border-slate-200/90 shadow-xl p-3 space-y-2.5">
          {/* Brand & Live GPS Status Row */}
          <div className="flex items-center justify-between gap-3">
            <div className="flex items-center gap-2.5 min-w-0">
              <div className="w-8 h-8 rounded-xl bg-blue-600 text-white flex items-center justify-center shrink-0 shadow-xs">
                <Compass className="w-4 h-4" />
              </div>
              <div className="min-w-0">
                <div className="text-xs lg:text-sm font-extrabold text-slate-900 truncate flex items-center gap-1.5">
                  <span>حامی</span>
                  <span className="text-[10px] font-normal text-slate-400">|</span>
                  <span className="text-slate-700 text-xs font-bold truncate">سامانه پیمایش جی‌پی‌اس</span>
                </div>
              </div>
            </div>

            {/* Quick Fullscreen and Live Status */}
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={toggleFullscreen}
                className="hidden sm:flex items-center gap-1 text-[11px] font-semibold text-slate-600 bg-slate-100 hover:bg-slate-200 px-2.5 py-1 rounded-full cursor-pointer transition-colors"
                title={isFullscreen ? 'خروج از حالت تمام‌صفحه (Esc)' : 'تمام‌صفحه نقشه'}
              >
                {isFullscreen ? <Minimize2 className="w-3.5 h-3.5 text-emerald-600" /> : <Maximize2 className="w-3.5 h-3.5 text-slate-600" />}
                <span>{isFullscreen ? 'خروج تمام‌صفحه' : 'تمام‌صفحه'}</span>
              </button>

              <div className="flex items-center gap-1.5 shrink-0 text-[11px] font-semibold text-slate-600 bg-slate-100 px-2.5 py-1 rounded-full">
                <span className={`w-2 h-2 rounded-full ${loading ? 'bg-amber-500 animate-pulse' : 'bg-emerald-500'}`} />
                <span className="tabular-nums font-bold text-slate-800">{numberFa(cleanVehicles.length)}</span>
                <span>خودرو زنده</span>
              </div>
            </div>
          </div>

          {/* Search Box */}
          <div className="relative">
            <label className="flex items-center gap-2 px-3 h-10 rounded-xl border border-slate-200 bg-slate-50 focus-within:bg-white focus-within:border-blue-500 transition-colors">
              <Search className="w-4 h-4 text-slate-400 shrink-0" />
              <input
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                onFocus={() => setSearchFocused(true)}
                placeholder="جست‌وجوی خودرو، راننده، کد یا پلاک…"
                className="w-full bg-transparent border-0 outline-none text-xs text-slate-800 placeholder:text-slate-400"
              />
              {search && (
                <button
                  type="button"
                  onClick={() => setSearch('')}
                  className="text-slate-400 hover:text-slate-600 cursor-pointer p-1"
                >
                  <X className="w-3.5 h-3.5" />
                </button>
              )}
            </label>

            {/* Live Instant Search Results Dropdown */}
            {search.trim().length > 0 && searchFocused && (
              <div className="absolute top-11 right-0 left-0 bg-white rounded-xl border border-slate-200 shadow-2xl max-h-60 overflow-y-auto p-1.5 z-50 divide-y divide-slate-100">
                {filtered.slice(0, 8).map((v) => (
                  <button
                    key={v.id}
                    type="button"
                    onClick={() => {
                      selectVehicle(v);
                      setSearchFocused(false);
                    }}
                    className="w-full text-right p-2 rounded-lg hover:bg-blue-50 flex items-center justify-between gap-2 text-xs cursor-pointer"
                  >
                    <div className="min-w-0">
                      <div className="font-bold text-slate-900 truncate">{v.name}</div>
                      <div className="text-[11px] text-slate-500 truncate">
                        کد {v.vehicleCode} {v.driverName ? `· ${v.driverName}` : ''}
                      </div>
                    </div>
                    <span className="text-[11px] font-bold text-blue-600 shrink-0 tabular-nums">
                      {v.speedKph ? `${numberFa(v.speedKph)} km/h` : 'متوقف'}
                    </span>
                  </button>
                ))}
                {!filtered.length && (
                  <div className="py-4 text-center text-xs text-slate-400">خودرویی با این نام یافت نشد.</div>
                )}
              </div>
            )}
          </div>

          {/* Quick Category Filter Bar */}
          <div className="flex items-center gap-1 overflow-x-auto pb-0.5 text-xs font-semibold">
            <button
              type="button"
              onClick={() => setCategoryFilter('all')}
              className={`px-2.5 py-1 rounded-lg border transition-colors whitespace-nowrap cursor-pointer ${
                categoryFilter === 'all'
                  ? 'bg-blue-600 text-white border-blue-600 font-bold'
                  : 'bg-slate-50 text-slate-600 border-slate-200 hover:bg-slate-100'
              }`}
            >
              همه ({numberFa(cleanVehicles.length)})
            </button>
            {(Object.keys(categories) as VehicleCategory[]).map((cat) => (
              <button
                key={cat}
                type="button"
                onClick={() => setCategoryFilter(categoryFilter === cat ? 'all' : cat)}
                className={`flex items-center gap-1 px-2 py-1 rounded-lg border transition-colors whitespace-nowrap cursor-pointer ${
                  categoryFilter === cat
                    ? 'bg-blue-50 text-blue-700 border-blue-300 font-bold'
                    : 'bg-slate-50 text-slate-600 border-slate-200 hover:bg-slate-100'
                }`}
              >
                <span className={`w-1.5 h-1.5 rounded-full ${categories[cat].dotClass}`} />
                <span>{categories[cat].label}</span>
                <span className="text-[10px] text-slate-400 tabular-nums">
                  ({numberFa(categoryCounts[cat] || 0)})
                </span>
              </button>
            ))}
          </div>

          {/* Side-Menu Triggers (۷ ماژول کاربردی از اطراف) */}
          <div className="grid grid-cols-7 gap-1 pt-1 border-t border-slate-100 text-center">
            {/* 1. ناوگان */}
            <button
              type="button"
              onClick={() => setActiveDrawer(activeDrawer === 'fleet' ? 'none' : 'fleet')}
              className={`flex flex-col items-center justify-center gap-0.5 py-1.5 px-0.5 rounded-xl border transition-colors cursor-pointer ${
                activeDrawer === 'fleet'
                  ? 'bg-blue-600 text-white border-blue-600 shadow-xs'
                  : 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-blue-50'
              }`}
            >
              <Truck className="w-3.5 h-3.5" />
              <span className="text-[9.5px] font-bold">ناوگان</span>
            </button>

            {/* 2. بارنامه و سفر (Requested Feature) */}
            <button
              type="button"
              onClick={() => {
                setActiveDrawer(activeDrawer === 'missions' ? 'none' : 'missions');
                onMissionsRefresh?.();
              }}
              className={`relative flex flex-col items-center justify-center gap-0.5 py-1.5 px-0.5 rounded-xl border transition-colors cursor-pointer ${
                activeDrawer === 'missions'
                  ? 'bg-emerald-600 text-white border-emerald-600 shadow-xs font-black'
                  : 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-emerald-50'
              }`}
            >
              <ClipboardList className="w-3.5 h-3.5" />
              <span className="text-[9.5px] font-bold">بارنامه</span>
              {activeMissionsCount > 0 && (
                <span className="absolute -top-1 -right-1 w-4 h-4 rounded-full bg-emerald-600 text-white font-bold text-[8.5px] flex items-center justify-center">
                  {numberFa(activeMissionsCount)}
                </span>
              )}
            </button>

            {/* 3. سوخت‌گیری (Requested Feature) */}
            <button
              type="button"
              onClick={() => {
                setActiveDrawer(activeDrawer === 'fuel' ? 'none' : 'fuel');
                onFuelRefresh?.();
              }}
              className={`relative flex flex-col items-center justify-center gap-0.5 py-1.5 px-0.5 rounded-xl border transition-colors cursor-pointer ${
                activeDrawer === 'fuel'
                  ? 'bg-teal-600 text-white border-teal-600 shadow-xs font-black'
                  : 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-teal-50'
              }`}
            >
              <Fuel className="w-3.5 h-3.5" />
              <span className="text-[9.5px] font-bold">سوخت</span>
              {fuelUrgentCount > 0 && (
                <span className="absolute -top-1 -right-1 w-4 h-4 rounded-full bg-rose-500 text-white font-bold text-[8.5px] flex items-center justify-center animate-pulse">
                  {numberFa(fuelUrgentCount)}
                </span>
              )}
            </button>

            {/* 4. تعمیرات و روغن */}
            <button
              type="button"
              onClick={() => {
                setActiveDrawer(activeDrawer === 'maintenance' ? 'none' : 'maintenance');
                onMaintenanceRefresh?.();
              }}
              className={`relative flex flex-col items-center justify-center gap-0.5 py-1.5 px-0.5 rounded-xl border transition-colors cursor-pointer ${
                activeDrawer === 'maintenance'
                  ? 'bg-amber-500 text-slate-950 border-amber-500 shadow-xs font-black'
                  : 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-amber-50'
              }`}
            >
              <Wrench className="w-3.5 h-3.5" />
              <span className="text-[9.5px] font-bold">روغن</span>
              {overdueMaintCount > 0 && (
                <span className="absolute -top-1 -right-1 w-4 h-4 rounded-full bg-rose-600 text-white font-bold text-[8.5px] flex items-center justify-center animate-pulse">
                  {numberFa(overdueMaintCount)}
                </span>
              )}
            </button>

            {/* 5. پیمایش مسیر */}
            <button
              type="button"
              onClick={() => setActiveDrawer(activeDrawer === 'navigation' ? 'none' : 'navigation')}
              className={`flex flex-col items-center justify-center gap-0.5 py-1.5 px-0.5 rounded-xl border transition-colors cursor-pointer ${
                activeDrawer === 'navigation'
                  ? 'bg-sky-600 text-white border-sky-600 shadow-xs'
                  : 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-sky-50'
              }`}
            >
              <Navigation className="w-3.5 h-3.5" />
              <span className="text-[9.5px] font-bold">پیمایش</span>
            </button>

            {/* 6. هشدارها */}
            <button
              type="button"
              onClick={() => {
                setActiveDrawer(activeDrawer === 'alerts' ? 'none' : 'alerts');
                onAlertsOpen?.();
              }}
              className={`relative flex flex-col items-center justify-center gap-0.5 py-1.5 px-0.5 rounded-xl border transition-colors cursor-pointer ${
                activeDrawer === 'alerts'
                  ? 'bg-rose-600 text-white border-rose-600 shadow-xs'
                  : 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-rose-50'
              }`}
            >
              <Bell className="w-3.5 h-3.5" />
              <span className="text-[9.5px] font-bold">هشدار</span>
              {alerts.length > 0 && (
                <span className="absolute -top-1 -right-1 w-4 h-4 rounded-full bg-rose-500 text-white font-bold text-[8.5px] flex items-center justify-center">
                  {numberFa(alerts.length)}
                </span>
              )}
            </button>

            {/* 7. گزارش و آمار */}
            <button
              type="button"
              onClick={() => {
                setActiveDrawer(activeDrawer === 'reports' ? 'none' : 'reports');
                onDailyReportOpen?.();
              }}
              className={`flex flex-col items-center justify-center gap-0.5 py-1.5 px-0.5 rounded-xl border transition-colors cursor-pointer ${
                activeDrawer === 'reports'
                  ? 'bg-slate-900 text-white border-slate-900 shadow-xs'
                  : 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100'
              }`}
            >
              <BarChart3 className="w-3.5 h-3.5" />
              <span className="text-[9.5px] font-bold">گزارش</span>
            </button>
          </div>
        </div>
      </div>

      {/* 3. Floating Quick Tools on Top-Left Edge */}
      <div className="absolute top-3 left-3 z-20 flex flex-col gap-2">
        {/* HTML5 Fullscreen Map Toggle (Requested Feature) */}
        <button
          type="button"
          onClick={toggleFullscreen}
          className={`w-10 h-10 rounded-xl border shadow-md flex items-center justify-center transition-colors cursor-pointer ${
            isFullscreen
              ? 'bg-emerald-600 text-white border-emerald-600 shadow-emerald-500/30'
              : 'bg-white/95 backdrop-blur-md text-slate-700 border-slate-200/90 hover:text-slate-900 hover:bg-slate-50'
          }`}
          title={isFullscreen ? 'خروج از حالت تمام‌صفحه نقشه (Esc)' : 'حالت تمام‌صفحه نقشه (Fullscreen)'}
        >
          {isFullscreen ? <Minimize2 className="w-4 h-4" /> : <Maximize2 className="w-4 h-4" />}
        </button>

        {/* Map Layers Tool with Dropdown */}
        <div className="relative">
          <button
            type="button"
            onClick={() => setStyleMenuOpen((v) => !v)}
            className="w-10 h-10 rounded-xl bg-white/95 backdrop-blur-md border border-slate-200/90 shadow-md text-slate-700 hover:text-slate-900 flex items-center justify-center transition-colors cursor-pointer"
            title="انتخاب لایه نقشه"
          >
            <Layers className="w-4 h-4" />
          </button>
          {styleMenuOpen && (
            <div className="absolute top-12 left-0 bg-white rounded-xl border border-slate-200 shadow-2xl p-1.5 flex flex-col gap-1 z-30 min-w-[130px] text-xs font-semibold">
              {(
                [
                  { id: 'voyager', label: 'نقشه روشن' },
                  { id: 'vector', label: 'وکتور' },
                  { id: 'dark', label: 'حالت شب' },
                  { id: 'satellite', label: 'ماهواره' },
                ] as const
              ).map((st) => (
                <button
                  key={st.id}
                  type="button"
                  onClick={() => {
                    setMapStyle(st.id);
                    setStyleMenuOpen(false);
                  }}
                  className={`text-right px-2.5 py-1.5 rounded-lg transition-colors cursor-pointer ${
                    mapStyle === st.id
                      ? 'bg-blue-600 text-white font-bold'
                      : 'text-slate-700 hover:bg-slate-100'
                  }`}
                >
                  {st.label}
                </button>
              ))}
            </div>
          )}
        </div>

        {/* Fit All Fleet on Map */}
        <button
          type="button"
          onClick={fitAllVehicles}
          className="w-10 h-10 rounded-xl bg-white/95 backdrop-blur-md border border-slate-200/90 shadow-md text-slate-700 hover:text-slate-900 flex items-center justify-center transition-colors cursor-pointer"
          title="بزرگ‌نمایی روی کل ناوگان"
        >
          <Compass className="w-4 h-4" />
        </button>

        {/* Toggle User GPS */}
        <button
          type="button"
          onClick={toggleUserGps}
          className={`w-10 h-10 rounded-xl border shadow-md flex items-center justify-center transition-colors cursor-pointer ${
            userGpsActive
              ? 'bg-sky-600 text-white border-sky-600'
              : 'bg-white/95 backdrop-blur-md text-slate-700 border-slate-200/90 hover:text-slate-900'
          }`}
          title="موقعیت GPS من"
        >
          <Crosshair className="w-4 h-4" />
        </button>

        {/* Toggle Geofence Circles */}
        <button
          type="button"
          onClick={() => setGeofencesVisible((v) => !v)}
          className={`w-10 h-10 rounded-xl border shadow-md flex items-center justify-center transition-colors cursor-pointer ${
            geofencesVisible
              ? 'bg-blue-50 text-blue-700 border-blue-300'
              : 'bg-white/95 backdrop-blur-md text-slate-700 border-slate-200/90 hover:text-slate-900'
          }`}
          title="نمایش محدوده‌های جغرافیایی"
        >
          <MapPin className="w-4 h-4" />
        </button>

        {/* Export CSV */}
        <button
          type="button"
          onClick={exportCsv}
          className="w-10 h-10 rounded-xl bg-white/95 backdrop-blur-md border border-slate-200/90 shadow-md text-slate-700 hover:text-slate-900 flex items-center justify-center transition-colors cursor-pointer"
          title="خروجی فایل اکسل (CSV)"
        >
          <Download className="w-4 h-4" />
        </button>

        {/* Toggle Monthly Fuel Trend Widget */}
        <button
          type="button"
          onClick={() => setShowFuelTrendWidget((v) => !v)}
          className={`w-10 h-10 rounded-xl border shadow-md flex items-center justify-center transition-colors cursor-pointer ${
            showFuelTrendWidget
              ? 'bg-teal-50 text-teal-700 border-teal-300'
              : 'bg-white/95 backdrop-blur-md text-slate-700 border-slate-200/90 hover:text-slate-900'
          }`}
          title="نمایش / پنهان‌سازی ویجت روند مصرف سوخت ماهانه"
        >
          <TrendingUp className="w-4 h-4" />
        </button>

        {/* Refresh Live GPS */}
        <button
          type="button"
          onClick={() => void onRefresh?.()}
          disabled={loading || !onRefresh}
          className="w-10 h-10 rounded-xl bg-white/95 backdrop-blur-md border border-slate-200/90 shadow-md text-slate-700 hover:text-slate-900 disabled:opacity-50 flex items-center justify-center transition-colors cursor-pointer"
          title="به‌روزرسانی موقعیت‌های GPS"
        >
          <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin text-blue-600' : ''}`} />
        </button>
      </div>

      {/* 4. Bottom-Left Floating Monthly Fuel Trend Widget & Telemetry */}
      <div className="absolute bottom-4 left-4 z-20 flex flex-col gap-2 pointer-events-auto max-w-[calc(100vw-32px)]">
        {showFuelTrendWidget && (
          <MonthlyFuelTrendWidget
            fuelLogs={fuelLogs}
            fleetSummary={fuelAnalytics?.fleetSummary}
            isFloating={true}
            defaultCollapsed={true}
            onClose={() => setShowFuelTrendWidget(false)}
          />
        )}

        <div className="hidden md:flex items-center gap-3 bg-white/95 backdrop-blur-md border border-slate-200/90 shadow-lg px-3.5 py-2 rounded-xl text-xs font-semibold text-slate-700">
          <span className="flex items-center gap-1.5">
            <span className="w-2 h-2 rounded-full bg-emerald-500" />
            <span>در حرکت: <strong className="text-slate-900 tabular-nums">{numberFa(movingCount)}</strong></span>
          </span>
          <span className="text-slate-300">|</span>
          <span className="flex items-center gap-1.5">
            <span className="w-2 h-2 rounded-full bg-amber-500" />
            <span>متوقف: <strong className="text-slate-900 tabular-nums">{numberFa(stoppedCount)}</strong></span>
          </span>
          <span className="text-slate-300">|</span>
          <span className="flex items-center gap-1.5">
            <span className="w-2 h-2 rounded-full bg-slate-400" />
            <span>آفلاین: <strong className="text-slate-900 tabular-nums">{numberFa(offlineCount)}</strong></span>
          </span>
        </div>
      </div>

      {/* 5. Interactive Pick Mode Banner on Map */}
      {(zonePicking || navPickMode) && (
        <div className="absolute top-14 left-1/2 -translate-x-1/2 z-[600] bg-slate-900 text-white px-4 py-2.5 rounded-xl shadow-2xl text-xs font-bold flex items-center gap-3 animate-bounce">
          <Radio className="w-4 h-4 text-emerald-400 animate-pulse" />
          <span>
            {zonePicking
              ? 'روی نقشه کلیک کنید تا مرکز محدوده جغرافیایی ثبت شود'
              : `روی نقشه کلیک کنید تا مسیر پیمایش از «${selected?.name || 'موقعیت شما'}» ترسیم شود`}
          </span>
          <button
            type="button"
            onClick={() => {
              setZonePicking(false);
              setNavPickMode(false);
            }}
            className="px-2.5 py-1 rounded bg-white text-slate-900 text-xs font-bold cursor-pointer"
          >
            لغو
          </button>
        </div>
      )}

      {/* 6. Slide-Out Side Drawers (افزوده شدن منوها از اطراف) */}
      {activeDrawer !== 'none' && (
        <div className="absolute top-0 right-0 bottom-0 w-full sm:w-[440px] z-30 bg-white shadow-2xl border-l border-slate-200 flex flex-col transition-transform duration-300">
          {/* Drawer Header */}
          <div className="p-3.5 border-b border-slate-200 flex items-center justify-between gap-3 bg-slate-50">
            <div className="flex items-center gap-2 min-w-0">
              {activeDrawer === 'fleet' && <Truck className="w-5 h-5 text-blue-600 shrink-0" />}
              {activeDrawer === 'missions' && <ClipboardList className="w-5 h-5 text-emerald-600 shrink-0" />}
              {activeDrawer === 'fuel' && <Fuel className="w-5 h-5 text-teal-600 shrink-0" />}
              {activeDrawer === 'maintenance' && <Wrench className="w-5 h-5 text-amber-600 shrink-0" />}
              {activeDrawer === 'navigation' && <Navigation className="w-5 h-5 text-sky-600 shrink-0" />}
              {activeDrawer === 'alerts' && <Bell className="w-5 h-5 text-rose-600 shrink-0" />}
              {activeDrawer === 'reports' && <BarChart3 className="w-5 h-5 text-slate-900 shrink-0" />}
              <span className="text-sm font-extrabold text-slate-900 truncate">
                {activeDrawer === 'fleet' && 'فهرست ناوگان خودروها'}
                {activeDrawer === 'missions' && 'مدیریت بارنامه، رانندگان و رهگیری سفر'}
                {activeDrawer === 'fuel' && 'تحلیل و ثبت میزان سوخت‌گیری ناوگان'}
                {activeDrawer === 'maintenance' && 'مدیریت تعمیرات، سرویس و تعویض روغن'}
                {activeDrawer === 'navigation' && 'پیمایش و مسیریاب جاده‌ای'}
                {activeDrawer === 'alerts' && 'مرکز هشدارها و رویدادها'}
                {activeDrawer === 'reports' && 'گزارش‌های روزانه و محدوده‌ها'}
              </span>
            </div>
            <button
              type="button"
              onClick={() => setActiveDrawer('none')}
              className="w-8 h-8 rounded-lg text-slate-400 hover:text-slate-800 hover:bg-slate-200/70 flex items-center justify-center cursor-pointer transition-colors shrink-0"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          {/* Drawer Content: FLEET LIST */}
          {activeDrawer === 'fleet' && (
            <div className="flex-1 flex flex-col min-h-0 p-3 gap-3 overflow-hidden">
              <div className="grid grid-cols-4 gap-1 p-1 bg-slate-100 rounded-lg shrink-0 text-xs font-semibold">
                {(
                  [
                    { id: 'all', label: 'همه' },
                    { id: 'moving', label: 'در حرکت' },
                    { id: 'stopped', label: 'متوقف' },
                    { id: 'offline', label: 'آفلاین' },
                  ] as const
                ).map((st) => (
                  <button
                    key={st.id}
                    type="button"
                    onClick={() => setStatusFilter(st.id)}
                    className={`py-1.5 rounded-md transition-colors cursor-pointer text-center ${
                      statusFilter === st.id
                        ? 'bg-white text-slate-900 shadow-xs font-bold'
                        : 'text-slate-600 hover:text-slate-900'
                    }`}
                  >
                    {st.label}
                  </button>
                ))}
              </div>

              <div className="flex-1 overflow-y-auto divide-y divide-slate-100 pr-1">
                {filtered.map((vehicle) => {
                  const cat = categories[vehicle.category] || categories.other;
                  const isSelected = selected?.id === vehicle.id;
                  const isOnline = vehicle.online !== false;
                  const isMoving = isOnline && (vehicle.speedKph ?? 0) > 0;

                  return (
                    <button
                      key={vehicle.id}
                      type="button"
                      onClick={() => {
                        selectVehicle(vehicle);
                        if (window.innerWidth < 640) setActiveDrawer('none');
                      }}
                      className={`w-full text-right py-2.5 px-2.5 flex items-center gap-3 transition-colors rounded-xl cursor-pointer ${
                        isSelected
                          ? 'bg-blue-50/90 border border-blue-300'
                          : 'hover:bg-slate-50 border border-transparent'
                      }`}
                    >
                      <div
                        className={`w-9 h-9 rounded-full flex items-center justify-center font-bold text-xs tabular-nums shrink-0 ${cat.badgeBgClass} ${cat.badgeTextClass}`}
                      >
                        {vehicle.vehicleCode.slice(0, 4)}
                      </div>
                      <div className="min-w-0 flex-1">
                        <div className="flex items-center justify-between gap-2">
                          <span className="text-xs font-bold text-slate-900 truncate">
                            {vehicle.name}
                          </span>
                          <span
                            className={`text-[11px] font-bold tabular-nums shrink-0 ${
                              !isOnline
                                ? 'text-slate-400'
                                : isMoving
                                  ? 'text-emerald-600'
                                  : 'text-amber-600'
                            }`}
                          >
                            {!isOnline
                              ? 'آفلاین'
                              : isMoving
                                ? `${numberFa(vehicle.speedKph ?? 0)} km/h`
                                : 'متوقف'}
                          </span>
                        </div>
                        <div className="text-[11px] text-slate-500 flex items-center gap-1.5 mt-0.5 truncate">
                          <span>{cat.label}</span>
                          <span aria-hidden="true">·</span>
                          <span>کد {vehicle.vehicleCode}</span>
                          {vehicle.driverName && (
                            <>
                              <span aria-hidden="true">·</span>
                              <span className="text-slate-700 font-medium truncate">
                                {vehicle.driverName}
                              </span>
                            </>
                          )}
                        </div>
                        {vehicle.plateNumber && (
                          <div className="text-[10px] text-slate-400 mt-0.5 truncate">
                            پلاک: {vehicle.plateNumber}
                          </div>
                        )}
                      </div>
                    </button>
                  );
                })}
              </div>
            </div>
          )}

          {/* Drawer Content: MAINTENANCE, SERVICES & OIL CHANGES (FEATURE REQUEST) */}
          {activeDrawer === 'maintenance' && (
            <div className="flex-1 flex flex-col min-h-0 p-3.5 gap-3 overflow-hidden">
              {/* Internal Sub-Tabs: 1. وضعیت خودروها | 2. قوانین و لیمیت‌ها | 3. سوابق تعویض */}
              <div className="grid grid-cols-3 gap-1 p-1 bg-slate-100 rounded-xl shrink-0 text-xs font-bold">
                <button
                  type="button"
                  onClick={() => setMaintSubTab('vehicles')}
                  className={`py-1.5 rounded-lg transition-colors cursor-pointer text-center ${
                    maintSubTab === 'vehicles' ? 'bg-white text-blue-600 shadow-xs' : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  وضعیت سرویس
                </button>
                <button
                  type="button"
                  onClick={() => setMaintSubTab('rules')}
                  className={`py-1.5 rounded-lg transition-colors cursor-pointer text-center ${
                    maintSubTab === 'rules' ? 'bg-white text-blue-600 shadow-xs' : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  تعریف قوانین ({numberFa(maintenanceRules.length)})
                </button>
                <button
                  type="button"
                  onClick={() => setMaintSubTab('logs')}
                  className={`py-1.5 rounded-lg transition-colors cursor-pointer text-center ${
                    maintSubTab === 'logs' ? 'bg-white text-blue-600 shadow-xs' : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  سوابق تعویض ({numberFa(maintenanceLogs.length)})
                </button>
              </div>

              {/* Sub-Tab 1: Live Maintenance Status of Vehicles */}
              {maintSubTab === 'vehicles' && (
                <div className="flex-1 flex flex-col min-h-0 gap-3 overflow-hidden">
                  {/* Status Badges Strip */}
                  <div className="grid grid-cols-3 gap-2 text-center shrink-0">
                    <button
                      type="button"
                      onClick={() => setMaintStatusFilter(maintStatusFilter === 'overdue' ? 'all' : 'overdue')}
                      className={`p-2 rounded-xl border transition-colors cursor-pointer ${
                        maintStatusFilter === 'overdue'
                          ? 'border-rose-500 bg-rose-50 text-rose-800'
                          : 'border-slate-200 bg-slate-50 text-slate-700 hover:bg-rose-50/50'
                      }`}
                    >
                      <div className="text-[10px] font-semibold text-rose-600">تعویض فوری</div>
                      <div className="text-sm font-black tabular-nums text-rose-700">{numberFa(overdueMaintCount)}</div>
                    </button>
                    <button
                      type="button"
                      onClick={() => setMaintStatusFilter(maintStatusFilter === 'due_soon' ? 'all' : 'due_soon')}
                      className={`p-2 rounded-xl border transition-colors cursor-pointer ${
                        maintStatusFilter === 'due_soon'
                          ? 'border-amber-500 bg-amber-50 text-amber-800'
                          : 'border-slate-200 bg-slate-50 text-slate-700 hover:bg-amber-50/50'
                      }`}
                    >
                      <div className="text-[10px] font-semibold text-amber-600">نزدیک موعد</div>
                      <div className="text-sm font-black tabular-nums text-amber-700">{numberFa(dueSoonMaintCount)}</div>
                    </button>
                    <button
                      type="button"
                      onClick={() => setMaintStatusFilter(maintStatusFilter === 'nominal' ? 'all' : 'nominal')}
                      className={`p-2 rounded-xl border transition-colors cursor-pointer ${
                        maintStatusFilter === 'nominal'
                          ? 'border-emerald-500 bg-emerald-50 text-emerald-800'
                          : 'border-slate-200 bg-slate-50 text-slate-700 hover:bg-emerald-50/50'
                      }`}
                    >
                      <div className="text-[10px] font-semibold text-emerald-600">در بازه مجاز</div>
                      <div className="text-sm font-black tabular-nums text-emerald-700">
                        {numberFa(maintenanceStatuses.length - overdueMaintCount - dueSoonMaintCount)}
                      </div>
                    </button>
                  </div>

                  {/* Filter and Search within Maintenance */}
                  <div className="flex gap-2 shrink-0">
                    <input
                      value={maintSearch}
                      onChange={(e) => setMaintSearch(e.target.value)}
                      placeholder="جست‌وجوی خودرو در سرویس‌ها…"
                      className="flex-1 h-9 px-3 rounded-lg border border-slate-200 bg-slate-50 text-xs outline-none focus:border-blue-500"
                    />
                    <select
                      value={maintServiceFilter}
                      onChange={(e) => setMaintServiceFilter(e.target.value as any)}
                      className="h-9 px-2.5 rounded-lg border border-slate-200 bg-white text-xs font-semibold text-slate-700 outline-none"
                    >
                      <option value="all">همه قطعات و سرویس‌ها</option>
                      <option value="engine_oil">روغن موتور و فیلتر</option>
                      <option value="gearbox_oil">واسکازین گیربکس</option>
                      <option value="brake_pads">لنت ترمز</option>
                      <option value="filters">فیلتر سوخت و هوا</option>
                      <option value="belts">تسمه‌ها</option>
                    </select>
                  </div>

                  {/* Vehicle Maintenance Cards List */}
                  <div className="flex-1 overflow-y-auto space-y-3 pr-1">
                    {filteredMaintStatuses.map((mStatus) => {
                      const v = cleanVehicles.find((x) => x.id === mStatus.vehicleId);
                      const cat = categories[mStatus.category] || categories.other;

                      return (
                        <div
                          key={mStatus.vehicleId}
                          className={`p-3.5 rounded-2xl border transition-all ${
                            mStatus.overallStatus === 'overdue'
                              ? 'border-rose-200 bg-rose-50/30'
                              : mStatus.overallStatus === 'due_soon'
                                ? 'border-amber-200 bg-amber-50/20'
                                : 'border-slate-200 bg-white'
                          }`}
                        >
                          {/* Vehicle Header Info */}
                          <div className="flex items-center justify-between gap-2 pb-2.5 border-b border-slate-100">
                            <div className="flex items-center gap-2.5 min-w-0">
                              <span
                                className={`w-7 h-7 rounded-lg flex items-center justify-center font-black text-xs shrink-0 ${cat.badgeBgClass} ${cat.badgeTextClass}`}
                              >
                                {cat.icon}
                              </span>
                              <div className="min-w-0">
                                <div className="text-xs font-extrabold text-slate-900 truncate">
                                  {mStatus.vehicleName}
                                </div>
                                <div className="text-[11px] text-slate-500 truncate">
                                  کد {mStatus.vehicleCode} {mStatus.driverName ? `· ${mStatus.driverName}` : ''}
                                  {mStatus.plateNumber && ` · پلاک ${mStatus.plateNumber}`}
                                </div>
                              </div>
                            </div>

                            <div className="text-left shrink-0">
                              <span
                                className={`text-[10px] font-black px-2 py-0.5 rounded-md ${
                                  mStatus.overallStatus === 'overdue'
                                    ? 'bg-rose-100 text-rose-800'
                                    : mStatus.overallStatus === 'due_soon'
                                      ? 'bg-amber-100 text-amber-800'
                                      : 'bg-emerald-100 text-emerald-800'
                                }`}
                              >
                                {mStatus.overallStatus === 'overdue'
                                  ? '🔴 تعویض فوری'
                                  : mStatus.overallStatus === 'due_soon'
                                    ? '🟡 نزدیک موعد'
                                    : '🟢 مجاز'}
                              </span>
                              <div className="text-[10px] font-mono text-slate-400 mt-1 tabular-nums">
                                کارکرد: {numberFa(mStatus.currentKm)} km
                              </div>
                            </div>
                          </div>

                          {/* Applied Services & Triple Limit Rules */}
                          <div className="space-y-3 pt-2.5">
                            {mStatus.services.map((srv) => (
                              <div
                                key={srv.ruleId}
                                className="bg-white/80 border border-slate-100 rounded-xl p-2.5 space-y-2 text-xs"
                              >
                                <div className="flex items-center justify-between gap-2">
                                  <span className="font-bold text-slate-800 flex items-center gap-1.5">
                                    <Fuel className="w-3.5 h-3.5 text-blue-600" />
                                    <span>{srv.title}</span>
                                  </span>
                                  <span
                                    className={`text-[10px] font-extrabold px-1.5 py-0.5 rounded ${
                                      srv.status === 'overdue'
                                        ? 'bg-rose-100 text-rose-700'
                                        : srv.status === 'due_soon'
                                          ? 'bg-amber-100 text-amber-700'
                                          : 'bg-slate-100 text-slate-600'
                                    }`}
                                  >
                                    {srv.status === 'overdue'
                                      ? 'منقضی'
                                      : srv.status === 'due_soon'
                                        ? 'نزدیک موعد'
                                        : 'نرمال'}
                                  </span>
                                </div>

                                {/* 1. لیمیت کیلومتری (Kilometer Limit) */}
                                <div className="space-y-1">
                                  <div className="flex items-center justify-between text-[11px] text-slate-600">
                                    <span>
                                      لیمیت کیلومتری ({numberFa(srv.kmInterval)} km):
                                    </span>
                                    <span className="font-mono tabular-nums font-bold">
                                      {srv.kmRemaining <= 0 ? (
                                        <span className="text-rose-600">
                                          {numberFa(Math.abs(srv.kmRemaining))} km اضافه پیمایش
                                        </span>
                                      ) : (
                                        <span className="text-slate-700">
                                          {numberFa(srv.kmRemaining)} km مانده ({numberFa(srv.kmDriven)} طی‌شده)
                                        </span>
                                      )}
                                    </span>
                                  </div>
                                  <div className="w-full h-1.5 bg-slate-100 rounded-full overflow-hidden">
                                    <div
                                      className={`h-full rounded-full transition-all ${
                                        srv.isKmOverdue
                                          ? 'bg-rose-600'
                                          : srv.isDueSoon
                                            ? 'bg-amber-500'
                                            : 'bg-blue-600'
                                      }`}
                                      style={{ width: `${Math.min(100, srv.kmPercentage)}%` }}
                                    />
                                  </div>
                                </div>

                                {/* 2. لیمیت روزانه (Daily / Calendar Limit) */}
                                <div className="space-y-1">
                                  <div className="flex items-center justify-between text-[11px] text-slate-600">
                                    <span>
                                      لیمیت روزانه ({numberFa(srv.daysInterval)} روز):
                                    </span>
                                    <span className="font-mono tabular-nums font-bold">
                                      {srv.daysRemaining <= 0 ? (
                                        <span className="text-rose-600">
                                          {numberFa(Math.abs(srv.daysRemaining))} روز تاخیر
                                        </span>
                                      ) : (
                                        <span className="text-slate-700">
                                          {numberFa(srv.daysRemaining)} روز مانده ({numberFa(srv.daysPassed)} روز گذشته)
                                        </span>
                                      )}
                                    </span>
                                  </div>
                                  <div className="w-full h-1.5 bg-slate-100 rounded-full overflow-hidden">
                                    <div
                                      className={`h-full rounded-full transition-all ${
                                        srv.isDaysOverdue
                                          ? 'bg-rose-600'
                                          : srv.isDueSoon
                                            ? 'bg-amber-500'
                                            : 'bg-emerald-500'
                                      }`}
                                      style={{ width: `${Math.min(100, srv.daysPercentage)}%` }}
                                    />
                                  </div>
                                </div>

                                {srv.latestLog && (
                                  <div className="text-[10px] text-slate-400 bg-slate-50 rounded-lg p-1.5 mt-1">
                                    آخرین تعویض: {formatTime(srv.latestLog.serviceDate)} در کیلومتر{' '}
                                    {numberFa(srv.latestLog.serviceKm)} {srv.latestLog.oilBrand ? `(${srv.latestLog.oilBrand})` : ''}
                                  </div>
                                )}

                                {/* Action Buttons for this vehicle's service */}
                                <div className="flex items-center gap-1.5 pt-1.5 border-t border-slate-100">
                                  <button
                                    type="button"
                                    onClick={() =>
                                      openRecordLogModal({
                                        vehicleId: mStatus.vehicleId,
                                        vehicleName: mStatus.vehicleName,
                                        currentKm: mStatus.currentKm,
                                        serviceType: srv.serviceType,
                                        title: srv.title,
                                      })
                                    }
                                    className="flex-1 py-1.5 px-2 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white text-[11px] font-bold flex items-center justify-center gap-1 transition-colors cursor-pointer"
                                  >
                                    <Check className="w-3 h-3" />
                                    <span>ثبت تعویض روغن / ریست دوره</span>
                                  </button>

                                  <button
                                    type="button"
                                    onClick={() => {
                                      const r = maintenanceRules.find((x) => x.id === srv.ruleId);
                                      openRuleModal(r);
                                    }}
                                    className="py-1.5 px-2 rounded-lg border border-slate-200 hover:bg-slate-100 text-slate-700 text-[11px] font-semibold transition-colors cursor-pointer"
                                    title="ویرایش قوانین و لیمیت‌ها"
                                  >
                                    <SlidersHorizontal className="w-3 h-3" />
                                  </button>

                                  {v && (
                                    <button
                                      type="button"
                                      onClick={() => {
                                        selectVehicle(v);
                                        setActiveDrawer('none');
                                      }}
                                      className="py-1.5 px-2 rounded-lg border border-slate-200 hover:bg-blue-50 text-blue-700 text-[11px] font-semibold transition-colors cursor-pointer"
                                      title="مشاهده خودرو روی نقشه"
                                    >
                                      <MapPin className="w-3 h-3" />
                                    </button>
                                  )}
                                </div>
                              </div>
                            ))}
                          </div>
                        </div>
                      );
                    })}
                    {!filteredMaintStatuses.length && (
                      <div className="py-12 text-center text-xs text-slate-400">
                        موردی با فیلتر انتخابی یافت نشد.
                      </div>
                    )}
                  </div>
                </div>
              )}

              {/* Sub-Tab 2: Rules & Limits Definition (تعریف قوانین سه‌گانه) */}
              {maintSubTab === 'rules' && (
                <div className="flex-1 flex flex-col min-h-0 gap-3 overflow-hidden">
                  <div className="flex items-center justify-between shrink-0">
                    <span className="text-xs text-slate-500 font-semibold">
                      قوانین فعال تعویض روغن و سرویس ناوگان
                    </span>
                    <button
                      type="button"
                      onClick={() => openRuleModal()}
                      className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold transition-colors cursor-pointer"
                    >
                      <Plus className="w-3.5 h-3.5" />
                      <span>تعریف قانون جدید</span>
                    </button>
                  </div>

                  <div className="flex-1 overflow-y-auto space-y-2.5 pr-1">
                    {maintenanceRules.map((rule) => (
                      <div
                        key={rule.id}
                        className="p-3.5 rounded-2xl border border-slate-200 bg-white space-y-2 text-xs"
                      >
                        <div className="flex items-center justify-between">
                          <span className="font-extrabold text-slate-900 flex items-center gap-1.5">
                            <Wrench className="w-4 h-4 text-blue-600" />
                            <span>{rule.title}</span>
                          </span>
                          <span className="text-[10px] font-semibold text-slate-500 bg-slate-100 px-2 py-0.5 rounded-md">
                            {rule.scope === 'all'
                              ? 'کل ناوگان'
                              : rule.scope === 'category'
                                ? `دسته ${categories[rule.category || 'khavar']?.label}`
                                : 'خودروی اختصاصی'}
                          </span>
                        </div>

                        {/* Service Limits Badges (کیلومتری و روزانه) */}
                        <div className="grid grid-cols-2 gap-2 py-1 text-center">
                          <div className="bg-slate-50 p-1.5 rounded-lg border border-slate-100">
                            <div className="text-[10px] text-slate-400">لیمیت کیلومتری</div>
                            <div className="font-bold text-slate-800 tabular-nums">
                              {numberFa(rule.kmInterval)} km
                            </div>
                          </div>
                          <div className="bg-slate-50 p-1.5 rounded-lg border border-slate-100">
                            <div className="text-[10px] text-slate-400">لیمیت روزانه</div>
                            <div className="font-bold text-slate-800 tabular-nums">
                              {numberFa(rule.daysInterval)} روز
                            </div>
                          </div>
                        </div>

                        <div className="flex items-center justify-between text-[11px] text-slate-400 pt-1 border-t border-slate-100">
                          <span>
                            اخطار زودهنگام: {numberFa(rule.warningKmLead)} km قبل / {numberFa(rule.warningDaysLead)} روز قبل
                          </span>
                          <div className="flex items-center gap-1">
                            <button
                              type="button"
                              onClick={() => openRuleModal(rule)}
                              className="p-1 text-blue-600 hover:bg-blue-50 rounded cursor-pointer"
                              title="ویرایش قانون"
                            >
                              <Edit3 className="w-3.5 h-3.5" />
                            </button>
                            <button
                              type="button"
                              onClick={() => {
                                if (confirm(`آیا از حذف قانون «${rule.title}» مطمئن هستید؟`)) {
                                  onMaintenanceRuleDelete?.(rule.id);
                                }
                              }}
                              className="p-1 text-rose-500 hover:bg-rose-50 rounded cursor-pointer"
                              title="حذف قانون"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Sub-Tab 3: Service History Logs (سوابق تعویض روغن) */}
              {maintSubTab === 'logs' && (
                <div className="flex-1 flex flex-col min-h-0 gap-3 overflow-hidden">
                  <div className="flex items-center justify-between shrink-0">
                    <span className="text-xs text-slate-500 font-semibold">
                      تاریخچه لاگ‌های سرویس و تعویض روغن ثبت‌شده
                    </span>
                    <button
                      type="button"
                      onClick={() =>
                        openRecordLogModal({
                          vehicleId: selected?.id || cleanVehicles[0]?.id || '',
                          vehicleName: selected?.name || cleanVehicles[0]?.name || '',
                          currentKm: selected?.odometerKm,
                        })
                      }
                      className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold transition-colors cursor-pointer"
                    >
                      <Plus className="w-3.5 h-3.5" />
                      <span>ثبت سرویس جدید</span>
                    </button>
                  </div>

                  <div className="flex-1 overflow-y-auto space-y-2.5 pr-1">
                    {maintenanceLogs.map((log) => (
                      <div
                        key={log.id}
                        className="p-3 rounded-2xl border border-slate-200 bg-white space-y-1.5 text-xs"
                      >
                        <div className="flex items-center justify-between">
                          <span className="font-extrabold text-slate-900">{log.vehicleName}</span>
                          <span className="font-mono text-[11px] text-slate-500 tabular-nums">
                            {formatTime(log.serviceDate)}
                          </span>
                        </div>
                        <div className="text-[11px] font-semibold text-blue-700 flex items-center gap-1">
                          <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                          <span>{log.title}</span>
                          <span className="text-slate-400">·</span>
                          <span className="tabular-nums">کیلومتر {numberFa(log.serviceKm)} km</span>
                        </div>
                        {log.oilBrand && (
                          <div className="text-[11px] text-slate-600">برند روغن: {log.oilBrand}</div>
                        )}
                        {log.workshopName && (
                          <div className="text-[10px] text-slate-400">
                            محل سرویس: {log.workshopName} {log.technicianName ? `(${log.technicianName})` : ''}
                          </div>
                        )}
                        {log.notes && (
                          <div className="text-[11px] text-slate-500 bg-slate-50 rounded-lg p-1.5 mt-1">
                            {log.notes}
                          </div>
                        )}
                      </div>
                    ))}
                    {!maintenanceLogs.length && (
                      <div className="py-12 text-center text-xs text-slate-400">
                        هنوز سابقه‌ای ثبت نشده است. با کلیک بر روی دکمه بالا اولین سرویس را ثبت کنید.
                      </div>
                    )}
                  </div>
                </div>
              )}
            </div>
          )}

          {/* Drawer Content: MISSIONS & WAYBILLS (مدیریت بارنامه، رهگیری زنده، وضعیت سفر و همگام‌سازی پرسنل حامی) */}
          {activeDrawer === 'missions' && (
            <div className="flex-1 flex flex-col min-h-0 overflow-hidden bg-slate-50">
              {/* Drawer Sub-Tabs */}
              <div className="flex items-center gap-1 p-3 bg-white border-b border-slate-200">
                <button
                  type="button"
                  onClick={() => setMissionsTab('active')}
                  className={`flex-1 py-1.5 px-2 rounded-lg text-xs font-bold flex items-center justify-center gap-1.5 transition-colors cursor-pointer ${
                    missionsTab === 'active'
                      ? 'bg-blue-600 text-white shadow-xs'
                      : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                  }`}
                >
                  <ClipboardList className="w-3.5 h-3.5" />
                  <span>مأموریت‌ها و بارنامه‌ها</span>
                  {activeMissionsCount > 0 && (
                    <span className="w-4 h-4 rounded-full bg-emerald-500 text-white text-[10px] flex items-center justify-center font-mono">
                      {numberFa(activeMissionsCount)}
                    </span>
                  )}
                </button>

                <button
                  type="button"
                  onClick={() => setMissionsTab('new')}
                  className={`flex-1 py-1.5 px-2 rounded-lg text-xs font-bold flex items-center justify-center gap-1.5 transition-colors cursor-pointer ${
                    missionsTab === 'new'
                      ? 'bg-blue-600 text-white shadow-xs'
                      : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                  }`}
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>صدور بارنامه</span>
                </button>

                <button
                  type="button"
                  onClick={() => setMissionsTab('sync')}
                  className={`flex-1 py-1.5 px-2 rounded-lg text-xs font-bold flex items-center justify-center gap-1.5 transition-colors cursor-pointer ${
                    missionsTab === 'sync'
                      ? 'bg-blue-600 text-white shadow-xs'
                      : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                  }`}
                >
                  <UserCheck className="w-3.5 h-3.5" />
                  <span>همگام‌سازی حامی</span>
                </button>
              </div>

              {/* Sub-Tab 1: Active Missions List */}
              {missionsTab === 'active' && (
                <div className="flex-1 overflow-y-auto p-3 space-y-3">
                  {/* Status Filter Pills */}
                  <div className="flex items-center gap-1.5 overflow-x-auto pb-1 text-[11px] no-scrollbar">
                    {(
                      [
                        { id: 'all', label: 'همه مأموریت‌ها' },
                        { id: 'loading', label: 'در حال بارگیری' },
                        { id: 'in_transit', label: 'در مسیر' },
                        { id: 'unloaded', label: 'تخلیه شد' },
                        { id: 'completed', label: 'پایان یافته' },
                      ] as const
                    ).map((filter) => (
                      <button
                        key={filter.id}
                        type="button"
                        onClick={() => setMissionStatusFilter(filter.id)}
                        className={`px-2.5 py-1 rounded-full whitespace-nowrap font-bold transition-colors cursor-pointer ${
                          missionStatusFilter === filter.id
                            ? 'bg-slate-900 text-white shadow-xs'
                            : 'bg-white text-slate-600 border border-slate-200 hover:bg-slate-100'
                        }`}
                      >
                        {filter.label}
                      </button>
                    ))}
                  </div>

                  {/* Missions Cards */}
                  <div className="space-y-3">
                    {missions
                      .filter((m) =>
                        missionStatusFilter === 'all' ? true : m.status === missionStatusFilter
                      )
                      .map((m) => {
                        const targetVeh = cleanVehicles.find(
                          (v) => v.vehicleCode === m.vehicleCode || v.id === m.vehicleId
                        );
                        const isMoving = (targetVeh?.speedKph ?? 0) > 0;
                        const progress = Math.min(100, Math.max(0, m.progressPercent ?? 0));

                        return (
                          <div
                            key={m.id}
                            className={`p-3.5 rounded-2xl border bg-white shadow-xs space-y-3 transition-all ${
                              m.status === 'in_transit'
                                ? 'border-emerald-300 ring-1 ring-emerald-200/60'
                                : m.status === 'loading'
                                  ? 'border-amber-300'
                                  : m.status === 'unloaded'
                                    ? 'border-sky-300'
                                    : 'border-slate-200 opacity-75'
                            }`}
                          >
                            {/* Card Header: Vehicle + Waybill + Status Badge */}
                            <div className="flex items-start justify-between gap-2">
                              <div>
                                <div className="flex items-center gap-1.5 flex-wrap">
                                  <span className="font-extrabold text-sm text-slate-900">
                                    {m.vehicleName}
                                  </span>
                                  <span className="px-1.5 py-0.5 rounded-md bg-slate-100 text-slate-700 font-mono font-bold text-[11px]">
                                    کد {m.vehicleCode}
                                  </span>
                                </div>
                                <div className="text-[11px] text-blue-700 font-semibold flex items-center gap-1 mt-0.5">
                                  <ClipboardList className="w-3 h-3" />
                                  <span>شماره بارنامه: {m.waybillNumber}</span>
                                </div>
                              </div>

                              <div className="flex flex-col items-end gap-1">
                                <span
                                  className={`px-2 py-0.5 rounded-full text-[10px] font-bold flex items-center gap-1 ${
                                    m.status === 'in_transit'
                                      ? 'bg-emerald-100 text-emerald-800'
                                      : m.status === 'loading'
                                        ? 'bg-amber-100 text-amber-800'
                                        : m.status === 'unloaded'
                                          ? 'bg-sky-100 text-sky-800'
                                          : 'bg-slate-100 text-slate-600'
                                  }`}
                                >
                                  {m.status === 'in_transit' && (
                                    <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
                                  )}
                                  <span>
                                    {m.status === 'in_transit'
                                      ? 'در مسیر (اعزام)'
                                      : m.status === 'loading'
                                        ? 'در حال بارگیری'
                                        : m.status === 'unloaded'
                                          ? 'تخلیه شد'
                                          : 'پایان یافته'}
                                  </span>
                                </span>
                                {targetVeh && (
                                  <span className="text-[10px] text-slate-500 font-mono tabular-nums">
                                    سرعت GPS: {numberFa(targetVeh.speedKph ?? 0)} km/h
                                  </span>
                                )}
                              </div>
                            </div>

                            {/* Driver and Cargo Details */}
                            <div className="p-2 rounded-xl bg-slate-50 border border-slate-100 space-y-1.5 text-xs">
                              <div className="flex items-center justify-between">
                                <div className="flex items-center gap-1.5 text-slate-700 font-semibold">
                                  <User className="w-3.5 h-3.5 text-slate-500" />
                                  <span>راننده: {m.driverName}</span>
                                </div>
                                {m.driverPhone && (
                                  <a
                                    href={`tel:${m.driverPhone}`}
                                    className="flex items-center gap-1 text-[11px] text-emerald-700 hover:text-emerald-800 font-mono dir-ltr font-bold"
                                  >
                                    <Phone className="w-3 h-3" />
                                    <span>{m.driverPhone}</span>
                                  </a>
                                )}
                              </div>

                              <div className="text-[11px] text-slate-600 flex items-center justify-between pt-1 border-t border-slate-200/60">
                                <span>محموله: {m.cargoTitle}</span>
                                <span className="font-mono text-slate-700 font-bold">
                                  {numberFa(m.weightTons || 3.5)} تن
                                </span>
                              </div>

                              <div className="text-[11px] text-slate-600 flex items-center justify-between">
                                <span className="truncate max-w-[150px]">
                                  {m.origin?.title || 'مبدأ'} ➔ {m.destination?.title || 'مقصد'}
                                </span>
                                <span className="font-mono text-slate-700 font-bold tabular-nums">
                                  فاصله کل: {numberFa(m.totalDistanceKm)} km
                                </span>
                              </div>
                            </div>

                            {/* Live Trip Progress Bar & ETA Section */}
                            <div className="space-y-1.5 p-2.5 rounded-xl bg-blue-50/70 border border-blue-100">
                              <div className="flex items-center justify-between text-xs">
                                <span className="font-bold text-blue-900 flex items-center gap-1">
                                  <Send className="w-3 h-3 text-blue-600" />
                                  <span>پیشرفت سفر زنده روی نقشه:</span>
                                </span>
                                <span className="font-mono font-extrabold text-blue-700 text-sm tabular-nums">
                                  {numberFa(progress)}٪
                                </span>
                              </div>

                              {/* Progress bar */}
                              <div className="w-full h-2 rounded-full bg-blue-200/80 overflow-hidden">
                                <div
                                  className={`h-full rounded-full transition-all duration-500 ${
                                    m.status === 'in_transit'
                                      ? 'bg-emerald-500'
                                      : m.status === 'unloaded'
                                        ? 'bg-sky-500'
                                        : 'bg-blue-600'
                                  }`}
                                  style={{ width: `${progress}%` }}
                                />
                              </div>

                              {/* ETA Calculation Box */}
                              <div className="flex items-center justify-between text-[11px] pt-1">
                                <div className="flex items-center gap-1 text-slate-700 font-semibold">
                                  <Timer className="w-3.5 h-3.5 text-blue-600" />
                                  <span>تخمین زمان رسیدن (ETA):</span>
                                  <span className="font-bold text-emerald-700 mr-1">
                                    {m.etaLabel ||
                                      (m.status === 'completed'
                                        ? 'رسیده به مقصد'
                                        : m.status === 'unloaded'
                                          ? 'تخلیه کامل شد'
                                          : `~${m.remainingMinutes ? numberFa(m.remainingMinutes) : '—'} دقیقه دیگر`)}
                                  </span>
                                </div>
                                <span className="text-slate-500 text-[10px] tabular-nums font-mono">
                                  مانده: {numberFa(m.remainingDistanceKm ?? 0)} km
                                </span>
                              </div>
                            </div>

                            {/* Status Change Buttons Bar (ثبت وضعیت سفر: امکان تغییر وضعیت مأموریت) */}
                            <div className="space-y-1.5 pt-1">
                              <div className="text-[10px] font-bold text-slate-500">
                                تغییر وضعیت مأموریت و بارنامه:
                              </div>
                              <div className="grid grid-cols-4 gap-1">
                                <button
                                  type="button"
                                  onClick={() => handleMissionStatusUpdate(m.id, 'loading')}
                                  className={`py-1.5 px-1 rounded-lg text-[10px] font-bold text-center transition-colors cursor-pointer border ${
                                    m.status === 'loading'
                                      ? 'bg-amber-500 text-white border-amber-500 shadow-xs'
                                      : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-100'
                                  }`}
                                >
                                  بارگیری
                                </button>
                                <button
                                  type="button"
                                  onClick={() => handleMissionStatusUpdate(m.id, 'in_transit')}
                                  className={`py-1.5 px-1 rounded-lg text-[10px] font-bold text-center transition-colors cursor-pointer border ${
                                    m.status === 'in_transit'
                                      ? 'bg-emerald-600 text-white border-emerald-600 shadow-xs'
                                      : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-100'
                                  }`}
                                >
                                  در مسیر
                                </button>
                                <button
                                  type="button"
                                  onClick={() => handleMissionStatusUpdate(m.id, 'unloaded')}
                                  className={`py-1.5 px-1 rounded-lg text-[10px] font-bold text-center transition-colors cursor-pointer border ${
                                    m.status === 'unloaded'
                                      ? 'bg-sky-600 text-white border-sky-600 shadow-xs'
                                      : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-100'
                                  }`}
                                >
                                  تخلیه شد
                                </button>
                                <button
                                  type="button"
                                  onClick={() => handleMissionStatusUpdate(m.id, 'completed')}
                                  className={`py-1.5 px-1 rounded-lg text-[10px] font-bold text-center transition-colors cursor-pointer border ${
                                    m.status === 'completed'
                                      ? 'bg-slate-700 text-white border-slate-700 shadow-xs'
                                      : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-100'
                                  }`}
                                >
                                  اتمام سفر
                                </button>
                              </div>
                            </div>

                            {/* Card Footer: View on Map & Delete */}
                            <div className="flex items-center justify-between pt-2 border-t border-slate-100">
                              <button
                                type="button"
                                onClick={() => {
                                  if (targetVeh) {
                                    setSelectedId(targetVeh.id);
                                    const map = mapRef.current;
                                    if (map) {
                                      map.flyTo([targetVeh.latitude, targetVeh.longitude], 14, {
                                        duration: 0.8,
                                      });
                                    }
                                    if (window.innerWidth < 640) setActiveDrawer('none');
                                  }
                                }}
                                className="text-xs font-bold text-blue-600 hover:text-blue-800 flex items-center gap-1 cursor-pointer"
                              >
                                <MapPin className="w-3.5 h-3.5" />
                                <span>نمایش خودرو روی نقشه</span>
                              </button>

                              <button
                                type="button"
                                onClick={() => handleMissionRemove(m.id)}
                                className="text-xs font-bold text-rose-500 hover:text-rose-700 flex items-center gap-1 cursor-pointer"
                                title="حذف مأموریت"
                              >
                                <Trash2 className="w-3.5 h-3.5" />
                                <span>حذف</span>
                              </button>
                            </div>
                          </div>
                        );
                      })}

                    {!missions.length && (
                      <div className="py-14 text-center space-y-3">
                        <PackageCheck className="w-10 h-10 text-slate-300 mx-auto" />
                        <div className="text-xs font-bold text-slate-500">
                          هیچ بارنامه یا مأموریت فعالی در سامانه ثبت نشده است.
                        </div>
                        <button
                          type="button"
                          onClick={() => setMissionsTab('new')}
                          className="px-4 py-2 rounded-xl bg-blue-600 text-white text-xs font-bold cursor-pointer hover:bg-blue-700 shadow-xs"
                        >
                          صدور اولین بارنامه
                        </button>
                      </div>
                    )}
                  </div>
                </div>
              )}

              {/* Sub-Tab 2: Issue New Waybill Form */}
              {missionsTab === 'new' && (
                <form
                  onSubmit={handleCreateMissionSubmit}
                  className="flex-1 overflow-y-auto p-4 space-y-3.5"
                >
                  <div className="p-3 rounded-xl bg-blue-50 border border-blue-200 text-xs text-blue-800 leading-relaxed">
                    با صدور بارنامه جدید، اطلاعات مأموریت به همراه درصد پیشرفت سفر به صورت زنده روی
                    آیکون خودرو در نقشه نمایش داده می‌شود.
                  </div>

                  {/* Vehicle Picker */}
                  <label className="flex flex-col gap-1 text-xs font-bold text-slate-700">
                    <span>انتخاب خودرو از ناوگان *</span>
                    <select
                      value={newVehicleCode}
                      onChange={(e) => {
                        const code = e.target.value;
                        setNewVehicleCode(code);
                        const v = cleanVehicles.find((veh) => veh.vehicleCode === code);
                        if (v) {
                          setNewDriverName(v.driverName || '');
                          setNewDriverPhone(
                            v.vehicleCode === '1'
                              ? '09121112233'
                              : v.vehicleCode === '5'
                                ? '09123334455'
                                : '09120000000'
                          );
                        }
                      }}
                      required
                      className="h-10 px-3 rounded-xl border border-slate-300 bg-white text-xs font-semibold"
                    >
                      <option value="">-- انتخاب خودرو --</option>
                      {cleanVehicles.map((v) => (
                        <option key={v.id} value={v.vehicleCode}>
                          کد {v.vehicleCode} - {v.name} ({v.driverName || 'بدون راننده'})
                        </option>
                      ))}
                    </select>
                  </label>

                  {/* Waybill Number */}
                  <div className="grid grid-cols-2 gap-2">
                    <label className="flex flex-col gap-1 text-xs font-bold text-slate-700">
                      <span>شماره بارنامه حامی</span>
                      <input
                        type="text"
                        value={newWaybillNumber}
                        onChange={(e) => setNewWaybillNumber(e.target.value)}
                        placeholder="مثلاً ب-۹۸۴۲۵"
                        className="h-10 px-3 rounded-xl border border-slate-300 bg-white text-xs font-mono font-bold"
                      />
                    </label>

                    <label className="flex flex-col gap-1 text-xs font-bold text-slate-700">
                      <span>وزن محموله (تن)</span>
                      <input
                        type="number"
                        step="0.1"
                        value={newCargoWeight}
                        onChange={(e) => setNewCargoWeight(e.target.value)}
                        placeholder="مثلاً 3.5"
                        className="h-10 px-3 rounded-xl border border-slate-300 bg-white text-xs font-mono font-bold"
                      />
                    </label>
                  </div>

                  {/* Driver Name & Phone */}
                  <div className="grid grid-cols-2 gap-2">
                    <label className="flex flex-col gap-1 text-xs font-bold text-slate-700">
                      <span>نام راننده</span>
                      <input
                        type="text"
                        value={newDriverName}
                        onChange={(e) => setNewDriverName(e.target.value)}
                        placeholder="نام و نام خانوادگی"
                        required
                        className="h-10 px-3 rounded-xl border border-slate-300 bg-white text-xs font-semibold"
                      />
                    </label>

                    <label className="flex flex-col gap-1 text-xs font-bold text-slate-700">
                      <span>تلفن همراه راننده</span>
                      <input
                        type="text"
                        value={newDriverPhone}
                        onChange={(e) => setNewDriverPhone(e.target.value)}
                        placeholder="0912..."
                        className="h-10 px-3 rounded-xl border border-slate-300 bg-white text-xs font-mono"
                      />
                    </label>
                  </div>

                  {/* Cargo Title */}
                  <label className="flex flex-col gap-1 text-xs font-bold text-slate-700">
                    <span>عنوان و مشخصات بار</span>
                    <input
                      type="text"
                      value={newCargoTitle}
                      onChange={(e) => setNewCargoTitle(e.target.value)}
                      placeholder="مثلاً پالت قطعات یدکی خودرو و متعلقات"
                      required
                      className="h-10 px-3 rounded-xl border border-slate-300 bg-white text-xs font-semibold"
                    >
                    </input>
                  </label>

                  {/* Origin & Destination */}
                  <label className="flex flex-col gap-1 text-xs font-bold text-slate-700">
                    <span>مبدأ بارگیری</span>
                    <input
                      type="text"
                      value={newOriginTitle}
                      onChange={(e) => setNewOriginTitle(e.target.value)}
                      placeholder="مثلاً تهران، انبار مرکزی حامی"
                      required
                      className="h-10 px-3 rounded-xl border border-slate-300 bg-white text-xs font-semibold"
                    />
                  </label>

                  <label className="flex flex-col gap-1 text-xs font-bold text-slate-700">
                    <span>مقصد تخلیه</span>
                    <input
                      type="text"
                      value={newDestTitle}
                      onChange={(e) => setNewDestTitle(e.target.value)}
                      placeholder="مثلاً قزوین، شهرک صنعتی کاسپین"
                      required
                      className="h-10 px-3 rounded-xl border border-slate-300 bg-white text-xs font-semibold"
                    />
                  </label>

                  <label className="flex flex-col gap-1 text-xs font-bold text-slate-700">
                    <span>مسافت تخمینی کل مسیر (کیلومتر)</span>
                    <input
                      type="number"
                      value={newDistanceKm}
                      onChange={(e) => setNewDistanceKm(e.target.value)}
                      placeholder="140"
                      required
                      className="h-10 px-3 rounded-xl border border-slate-300 bg-white text-xs font-mono font-bold"
                    />
                  </label>

                  <button
                    type="submit"
                    disabled={savingMission}
                    className="w-full py-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold shadow-md flex items-center justify-center gap-2 cursor-pointer mt-2"
                  >
                    <ClipboardList className="w-4 h-4" />
                    <span>{savingMission ? 'در حال صدور بارنامه...' : 'صدور بارنامه و اعزام به مأموریت'}</span>
                  </button>
                </form>
              )}

              {/* Sub-Tab 3: Sync Personnel and Fleet (همگام‌سازی پرسنل و ناوگان در سیستم حامی) */}
              {missionsTab === 'sync' && (
                <form
                  onSubmit={handleDriverSyncSubmit}
                  className="flex-1 overflow-y-auto p-4 space-y-4"
                >
                  <div className="p-3.5 rounded-2xl bg-emerald-50 border border-emerald-200 space-y-2 text-xs text-emerald-900 leading-relaxed">
                    <div className="font-extrabold flex items-center gap-1.5 text-emerald-800">
                      <UserCheck className="w-4 h-4 text-emerald-600" />
                      <span>اتصال دوطرفه به سیستم پرسنل و ناوگان حامی</span>
                    </div>
                    <div>
                      طبق سناریوی مورد نظر: با تغییر راننده کد یک (یا هر کد دیگر) در سامانه حامی،
                      اطلاعات دستگاه GPS، سوابق و مأموریت‌های فعال به صورت آنی و بلادرنگ همگام‌سازی
                      می‌گردد.
                    </div>
                  </div>

                  {/* Sync Code Select */}
                  <label className="flex flex-col gap-1 text-xs font-bold text-slate-700">
                    <span>انتخاب کد دستگاه / ناوگان</span>
                    <select
                      value={syncCode}
                      onChange={(e) => {
                        const code = e.target.value;
                        setSyncCode(code);
                        const v = cleanVehicles.find((veh) => veh.vehicleCode === code);
                        if (v) {
                          setSyncDriver(v.driverName || '');
                          setSyncPhone('09121112233');
                        }
                      }}
                      className="h-10 px-3 rounded-xl border border-slate-300 bg-white text-xs font-semibold"
                    >
                      {cleanVehicles.map((v) => (
                        <option key={v.id} value={v.vehicleCode}>
                          کد {v.vehicleCode} - {v.name} (فعلی: {v.driverName || 'بدون راننده'})
                        </option>
                      ))}
                    </select>
                  </label>

                  {/* New Driver Name */}
                  <label className="flex flex-col gap-1 text-xs font-bold text-slate-700">
                    <span>نام و نام خانوادگی راننده جدید در سیستم حامی</span>
                    <input
                      type="text"
                      value={syncDriver}
                      onChange={(e) => setSyncDriver(e.target.value)}
                      placeholder="مثلاً اصغر رستمی"
                      required
                      className="h-10 px-3 rounded-xl border border-slate-300 bg-white text-xs font-semibold"
                    />
                  </label>

                  {/* Driver Phone */}
                  <label className="flex flex-col gap-1 text-xs font-bold text-slate-700">
                    <span>شماره تلفن همراه راننده</span>
                    <input
                      type="text"
                      value={syncPhone}
                      onChange={(e) => setSyncPhone(e.target.value)}
                      placeholder="09121112233"
                      className="h-10 px-3 rounded-xl border border-slate-300 bg-white text-xs font-mono"
                    />
                  </label>

                  <button
                    type="submit"
                    disabled={syncingDriver}
                    className="w-full py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold shadow-md flex items-center justify-center gap-2 cursor-pointer mt-2"
                  >
                    <UserCheck className="w-4 h-4" />
                    <span>
                      {syncingDriver
                        ? 'در حال همگام‌سازی...'
                        : 'به‌روزرسانی راننده و همگام‌سازی با دستگاه'}
                    </span>
                  </button>

                  {/* Quick Preview of Current Driver Linkages */}
                  <div className="pt-2">
                    <div className="text-[11px] font-bold text-slate-500 mb-2">
                      وضعیت فعلی اتصال پرسنل به ناوگان حامی:
                    </div>
                    <div className="space-y-1.5">
                      {cleanVehicles.map((v) => (
                        <div
                          key={v.id}
                          className="p-2.5 rounded-xl border border-slate-200 bg-white flex items-center justify-between text-xs"
                        >
                          <div className="flex items-center gap-2">
                            <span className="w-6 h-6 rounded-lg bg-blue-100 text-blue-800 text-[11px] font-mono font-bold flex items-center justify-center">
                              {v.vehicleCode}
                            </span>
                            <div>
                              <div className="font-bold text-slate-800">{v.name}</div>
                              <div className="text-[10px] text-slate-500">{v.plateNumber}</div>
                            </div>
                          </div>
                          <div className="text-left">
                            <div className="font-semibold text-slate-700 text-xs">
                              {v.driverName || 'بدون راننده'}
                            </div>
                            <div className="text-[10px] text-emerald-600 font-mono">متصل به GPS</div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                </form>
              )}
            </div>
          )}

          {/* Drawer Content: FUEL (مدیریت، ثبت و تحلیل میزان سوخت‌گیری و مراحل پیمایش) */}
          {activeDrawer === 'fuel' && (
            <div className="flex-1 flex flex-col min-h-0 overflow-hidden bg-slate-50">
              {/* Drawer Sub-Tabs & Action */}
              <div className="p-3 bg-white border-b border-slate-200 space-y-2">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-1">
                    <button
                      type="button"
                      onClick={() => setFuelTab('analysis')}
                      className={`py-1.5 px-3 rounded-lg text-xs font-bold transition-colors cursor-pointer ${
                        fuelTab === 'analysis'
                          ? 'bg-amber-500 text-white shadow-xs'
                          : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                      }`}
                    >
                      تحلیل و مصرف ناوگان
                    </button>
                    <button
                      type="button"
                      onClick={() => setFuelTab('stages')}
                      className={`py-1.5 px-3 rounded-lg text-xs font-bold transition-colors cursor-pointer ${
                        fuelTab === 'stages'
                          ? 'bg-amber-500 text-white shadow-xs'
                          : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                      }`}
                    >
                      مراحل سوخت‌گیری ({numberFa(fuelLogs.length)})
                    </button>
                  </div>

                  <button
                    type="button"
                    onClick={() => openNewFuelModal()}
                    className="py-1.5 px-2.5 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold flex items-center gap-1 shadow-xs cursor-pointer"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    <span>ثبت سوخت‌گیری</span>
                  </button>
                </div>
              </div>

              {/* Sub-Tab 1: Fleet Fuel Analysis & Vehicle Cards */}
              {fuelTab === 'analysis' && (
                <div className="flex-1 overflow-y-auto p-3 space-y-3.5">
                  {/* 4 Summary KPI Cards */}
                  {fuelAnalytics?.fleetSummary && (
                    <div className="grid grid-cols-2 gap-2">
                      <div className="p-2.5 rounded-xl bg-white border border-slate-200 shadow-xs space-y-0.5">
                        <div className="text-[10px] text-slate-500 font-semibold">مجموع سوخت مصرفی ناوگان</div>
                        <div className="text-sm font-extrabold text-slate-900 font-mono tabular-nums">
                          {numberFa(fuelAnalytics.fleetSummary.totalLiters)} لیتر
                        </div>
                      </div>

                      <div className="p-2.5 rounded-xl bg-white border border-slate-200 shadow-xs space-y-0.5">
                        <div className="text-[10px] text-slate-500 font-semibold">هزینه کل سوخت</div>
                        <div className="text-sm font-extrabold text-emerald-700 font-mono tabular-nums">
                          {numberFa(fuelAnalytics.fleetSummary.totalCostToman)} تومان
                        </div>
                      </div>

                      <div className="p-2.5 rounded-xl bg-white border border-slate-200 shadow-xs space-y-0.5">
                        <div className="text-[10px] text-slate-500 font-semibold">میانگین مصرف ناوگان</div>
                        <div className="text-sm font-extrabold text-blue-700 font-mono tabular-nums">
                          {numberFa(fuelAnalytics.fleetSummary.fleetAvgConsumption)} L/100km
                        </div>
                      </div>

                      <div className="p-2.5 rounded-xl bg-white border border-slate-200 shadow-xs space-y-0.5">
                        <div className="text-[10px] text-slate-500 font-semibold">وضعیت باک بحرانی</div>
                        <div className="text-sm font-extrabold text-rose-600 font-mono tabular-nums">
                          {numberFa(fuelAnalytics.fleetSummary.criticalCount)} خودرو
                        </div>
                      </div>
                    </div>
                  )}

                  {/* Monthly Fuel Trend Recharts Widget */}
                  <MonthlyFuelTrendWidget
                    fuelLogs={fuelLogs}
                    fleetSummary={fuelAnalytics?.fleetSummary}
                    isFloating={false}
                  />

                  {/* Vehicle Fuel Cards */}
                  <div className="space-y-3">
                    <div className="text-xs font-bold text-slate-700">
                      وضعیت سوخت، مصرف و پیمایش هر خودرو:
                    </div>

                    {fuelAnalytics?.vehicleStats?.map((stat) => {
                      const veh = cleanVehicles.find((v) => v.id === stat.vehicleId);
                      const fuelPct = Math.min(
                        100,
                        Math.max(
                          0,
                          Math.round((stat.estRemainingFuelLiters / (stat.tankCapacity || 100)) * 100)
                        )
                      );
                      const isLow = stat.refuelUrgency === 'critical' || fuelPct < 20;

                      return (
                        <div
                          key={stat.vehicleId}
                          className="p-3.5 rounded-2xl border border-slate-200 bg-white shadow-xs space-y-3"
                        >
                          {/* Card Header */}
                          <div className="flex items-start justify-between">
                            <div>
                              <div className="flex items-center gap-1.5">
                                <span className="font-extrabold text-sm text-slate-900">
                                  {stat.vehicleName}
                                </span>
                                <span className="px-1.5 py-0.5 rounded-md bg-slate-100 text-slate-700 font-mono font-bold text-[11px]">
                                  کد {stat.vehicleCode}
                                </span>
                              </div>
                              <div className="text-[11px] text-slate-500 mt-0.5">
                                راننده: {stat.driverName || 'ثبت نشده'}
                              </div>
                            </div>

                            <span
                              className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                                isLow
                                  ? 'bg-rose-100 text-rose-800 animate-pulse'
                                  : 'bg-emerald-100 text-emerald-800'
                              }`}
                            >
                              {isLow ? 'نیاز فوری به سوخت‌گیری' : 'وضعیت باک مطلوب'}
                            </span>
                          </div>

                          {/* Primary Metric: پیمایش بعد از آخرین سوخت‌گیری */}
                          <div className="p-2.5 rounded-xl bg-amber-50/80 border border-amber-200/80 space-y-1">
                            <div className="flex items-center justify-between text-xs">
                              <span className="font-bold text-amber-900 flex items-center gap-1">
                                <Route className="w-3.5 h-3.5 text-amber-600" />
                                <span>پیمایش بعد از آخرین سوخت‌گیری:</span>
                              </span>
                              <span className="font-mono font-extrabold text-amber-800 text-sm tabular-nums">
                                {numberFa(stat.kmSinceLastFuel)} کیلومتر
                              </span>
                            </div>
                            <div className="text-[10px] text-amber-700 flex items-center justify-between pt-0.5">
                              <span>کیلومترشمار در زمان سوخت: {numberFa(stat.lastFuelKm ?? 0)} km</span>
                              <span>کیلومتر فعلی GPS: {numberFa(stat.currentKm)} km</span>
                            </div>
                          </div>

                          {/* Consumption and Remaining Tank Estimation */}
                          <div className="grid grid-cols-2 gap-2 text-xs">
                            <div className="p-2 rounded-xl bg-slate-50 border border-slate-100 space-y-0.5">
                              <div className="text-[10px] text-slate-500">میانگین مصرف سوخت</div>
                              <div className="font-bold text-slate-800 font-mono tabular-nums">
                                {numberFa(stat.vehicleAvgConsumption)} L / ۱۰۰km
                              </div>
                            </div>

                            <div className="p-2 rounded-xl bg-slate-50 border border-slate-100 space-y-0.5">
                              <div className="text-[10px] text-slate-500">شعاع پیمایش باقی‌مانده</div>
                              <div className="font-bold text-blue-700 font-mono tabular-nums">
                                ~{numberFa(stat.estRemainingRangeKm)} کیلومتر
                              </div>
                            </div>
                          </div>

                          {/* Fuel Tank Visual Indicator */}
                          <div className="space-y-1">
                            <div className="flex items-center justify-between text-[11px]">
                              <span className="text-slate-600">برآورد باقیمانده باک:</span>
                              <span className="font-mono font-bold text-slate-800 tabular-nums">
                                ~{numberFa(stat.estRemainingFuelLiters)} لیتر ({numberFa(fuelPct)}٪)
                              </span>
                            </div>
                            <div className="w-full h-2 rounded-full bg-slate-200 overflow-hidden">
                              <div
                                className={`h-full rounded-full transition-all duration-300 ${
                                  fuelPct < 20
                                    ? 'bg-rose-500'
                                    : fuelPct < 45
                                      ? 'bg-amber-500'
                                      : 'bg-emerald-500'
                                }`}
                                style={{ width: `${fuelPct}%` }}
                              />
                            </div>
                          </div>

                          {/* Last Refueling Detail */}
                          <div className="text-[11px] text-slate-500 flex items-center justify-between pt-1 border-t border-slate-100">
                            <span>آخرین سوخت‌گیری: {formatTime(stat.lastFuelDate)}</span>
                            <span className="font-mono font-semibold">
                              {numberFa(stat.lastFuelLog?.liters ?? 0)} لیتر
                            </span>
                          </div>

                          {/* Action Button */}
                          <button
                            type="button"
                            onClick={() => openNewFuelModal(veh)}
                            className="w-full py-1.5 rounded-lg border border-slate-200 hover:bg-slate-50 text-xs font-bold text-blue-600 flex items-center justify-center gap-1 cursor-pointer"
                          >
                            <Fuel className="w-3.5 h-3.5" />
                            <span>ثبت سوخت‌گیری برای این خودرو</span>
                          </button>
                        </div>
                      );
                    })}
                  </div>
                </div>
              )}

              {/* Sub-Tab 2: Refueling Stages History */}
              {fuelTab === 'stages' && (
                <div className="flex-1 overflow-y-auto p-3 space-y-2.5">
                  <div className="text-xs font-bold text-slate-700">
                    تاریخچه مراحل سوخت‌گیری بر اساس ترتیب زمانی:
                  </div>

                  {fuelLogs.map((log) => (
                    <div
                      key={log.id}
                      className="p-3 rounded-2xl border border-slate-200 bg-white shadow-xs space-y-2 text-xs"
                    >
                      <div className="flex items-start justify-between">
                        <div>
                          <div className="flex items-center gap-1.5">
                            <span className="font-extrabold text-slate-900">{log.vehicleName}</span>
                            <span className="px-1.5 py-0.5 rounded-md bg-slate-100 text-slate-700 font-mono text-[10px]">
                              کد {log.vehicleCode}
                            </span>
                            {log.stageNumber && (
                              <span className="px-1.5 py-0.5 rounded-md bg-blue-100 text-blue-800 text-[10px] font-bold">
                                مرحله {numberFa(log.stageNumber)}
                              </span>
                            )}
                          </div>
                          <div className="text-[11px] text-slate-500 mt-0.5">
                            {formatTime(`${log.date}T${log.time || '12:00'}`)} · {log.gasStation}
                          </div>
                        </div>

                        <button
                          type="button"
                          onClick={() => handleDeleteFuelLog(log.id)}
                          className="text-slate-400 hover:text-rose-600 p-1 cursor-pointer"
                          title="حذف رکورد"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>

                      {/* Stage Mileage Highlight */}
                      <div className="p-2 rounded-xl bg-slate-50 border border-slate-100 grid grid-cols-2 gap-2 text-[11px]">
                        <div>
                          <span className="text-slate-500">کیلومترشمار:</span>
                          <span className="font-mono font-bold text-slate-800 mr-1 tabular-nums">
                            {numberFa(log.odometerKm)} km
                          </span>
                        </div>
                        <div>
                          <span className="text-slate-500">پیمایش مرحله:</span>
                          <span className="font-mono font-bold text-emerald-700 mr-1 tabular-nums">
                            {log.kmSincePreviousFuel
                              ? `${numberFa(log.kmSincePreviousFuel)} km`
                              : 'مرحله اول'}
                          </span>
                        </div>
                      </div>

                      {/* Fuel Volume, Cost & Consumption */}
                      <div className="flex items-center justify-between text-[11px] text-slate-600 pt-1 border-t border-slate-100">
                        <div className="flex items-center gap-1">
                          <Fuel className="w-3.5 h-3.5 text-amber-500" />
                          <span className="font-mono font-bold text-slate-900 tabular-nums">
                            {numberFa(log.liters)} لیتر
                          </span>
                          <span className="text-slate-400">·</span>
                          <span className="tabular-nums">
                            {numberFa(log.totalCostToman)} تومان
                          </span>
                        </div>

                        {log.consumptionL100km != null && (
                          <span className="font-mono font-bold text-blue-700 tabular-nums text-[10px]">
                            مصرف: {numberFa(log.consumptionL100km)} L/100km
                          </span>
                        )}
                      </div>

                      {log.notes && (
                        <div className="text-[10px] text-slate-500 bg-slate-50 rounded-lg p-1.5">
                          {log.notes}
                        </div>
                      )}
                    </div>
                  ))}

                  {!fuelLogs.length && (
                    <div className="py-14 text-center space-y-3">
                      <Fuel className="w-10 h-10 text-slate-300 mx-auto" />
                      <div className="text-xs font-bold text-slate-500">
                        هنوز هیچ رکورد سوخت‌گیری در سامانه ثبت نشده است.
                      </div>
                      <button
                        type="button"
                        onClick={() => openNewFuelModal()}
                        className="px-4 py-2 rounded-xl bg-amber-500 text-white text-xs font-bold cursor-pointer hover:bg-amber-600 shadow-xs"
                      >
                        ثبت اولین سوخت‌گیری
                      </button>
                    </div>
                  )}
                </div>
              )}
            </div>
          )}

          {/* Drawer Content: NAVIGATION */}
          {activeDrawer === 'navigation' && (
            <div className="flex-1 overflow-y-auto p-4 space-y-3.5">
              <div className="bg-slate-50 border border-slate-200 rounded-xl p-3 space-y-2">
                <div className="text-xs font-bold text-slate-800">
                  مبدأ پیمایش:
                  <span className="text-blue-700 mr-1">
                    {selected
                      ? `${selected.name} (کد ${selected.vehicleCode})`
                      : userGps
                        ? 'موقعیت GPS من'
                        : 'یک خودرو را از نقشه انتخاب کنید'}
                  </span>
                </div>

                <div className="grid grid-cols-2 gap-2 pt-1">
                  <button
                    type="button"
                    onClick={() => {
                      if (!selected && !userGps) {
                        setNotice('ابتدا یک خودرو یا «موقعیت من» را انتخاب کنید');
                        return;
                      }
                      setNavPickMode((v) => !v);
                      if (window.innerWidth < 640) setActiveDrawer('none');
                    }}
                    className={`py-2 px-2.5 rounded-lg text-xs font-bold flex items-center justify-center gap-1.5 border transition-colors cursor-pointer ${
                      navPickMode
                        ? 'bg-emerald-600 text-white border-emerald-600'
                        : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-100'
                    }`}
                  >
                    <MapPin className="w-3.5 h-3.5" />
                    <span>{navPickMode ? 'لغو انتخاب' : 'مقصد روی نقشه'}</span>
                  </button>

                  <button
                    type="button"
                    onClick={toggleUserGps}
                    className={`py-2 px-2.5 rounded-lg text-xs font-bold flex items-center justify-center gap-1.5 border transition-colors cursor-pointer ${
                      userGpsActive
                        ? 'bg-sky-600 text-white border-sky-600'
                        : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-100'
                    }`}
                  >
                    <Crosshair className="w-3.5 h-3.5" />
                    <span>{userGpsActive ? 'GPS روشن است' : 'روشن‌کردن GPS من'}</span>
                  </button>
                </div>
              </div>

              <div>
                <div className="text-xs font-bold text-slate-600 mb-1.5">
                  پیمایش سریع به پایانه‌ها و انبارهای حامی
                </div>
                <div className="space-y-1.5">
                  {geofences.map((zone) => (
                    <button
                      key={zone.id}
                      type="button"
                      disabled={navLoading}
                      onClick={() => {
                        const origin: [number, number] | null = selected
                          ? [selected.latitude, selected.longitude]
                          : userGps
                            ? [userGps.latitude, userGps.longitude]
                            : null;
                        const originLabel = selected ? selected.name : 'موقعیت من';
                        if (!origin) {
                          setNotice('ابتدا یک خودرو را روی نقشه انتخاب کنید');
                          return;
                        }
                        void calculateNavigationRoute(
                          origin,
                          originLabel,
                          [zone.latitude, zone.longitude],
                          zone.name
                        );
                      }}
                      className="w-full text-right p-2.5 rounded-xl border border-slate-200 bg-white hover:border-emerald-400 hover:bg-emerald-50/40 transition-colors flex items-center justify-between gap-2 cursor-pointer"
                    >
                      <div className="min-w-0">
                        <div className="text-xs font-bold text-slate-800 truncate">{zone.name}</div>
                        <div className="text-[10px] text-slate-400 mt-0.5">
                          شعاع: {numberFa(zone.radiusMeters)} متر
                        </div>
                      </div>
                      <ChevronLeft className="w-4 h-4 text-slate-400 shrink-0" />
                    </button>
                  ))}
                </div>
              </div>

              <form onSubmit={searchDestinationPlace} className="space-y-2">
                <div className="text-xs font-bold text-slate-600">جست‌وجوی مقصد در ایران</div>
                <div className="flex gap-1.5">
                  <input
                    value={placeQuery}
                    onChange={(e) => setPlaceQuery(e.target.value)}
                    placeholder="مثلاً: میدان آزادی تهران، کرج، قزوین…"
                    className="flex-1 h-9 px-3 rounded-lg border border-slate-200 bg-white text-xs outline-none focus:border-blue-500"
                  />
                  <button
                    type="submit"
                    disabled={placeSearching}
                    className="px-3 h-9 rounded-lg bg-slate-900 hover:bg-slate-800 text-white text-xs font-bold shrink-0 cursor-pointer"
                  >
                    {placeSearching ? '...' : 'جست‌وجو'}
                  </button>
                </div>
              </form>

              {placeResults.length > 0 && (
                <div className="space-y-1.5 border-t border-slate-100 pt-2">
                  {placeResults.map((place, idx) => (
                    <button
                      key={`${place.latitude}-${place.longitude}-${idx}`}
                      type="button"
                      onClick={() => {
                        const origin: [number, number] | null = selected
                          ? [selected.latitude, selected.longitude]
                          : userGps
                            ? [userGps.latitude, userGps.longitude]
                            : null;
                        const originLabel = selected ? selected.name : 'موقعیت من';
                        if (!origin) {
                          setNotice('ابتدا یک خودرو را به‌عنوان مبدأ انتخاب کنید');
                          return;
                        }
                        void calculateNavigationRoute(
                          origin,
                          originLabel,
                          [place.latitude, place.longitude],
                          place.label.split('،')[0] || place.label
                        );
                      }}
                      className="w-full text-right p-2 rounded-lg border border-slate-200 hover:bg-blue-50 text-xs text-slate-700 line-clamp-2 cursor-pointer"
                    >
                      {place.label}
                    </button>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* Drawer Content: ALERTS */}
          {activeDrawer === 'alerts' && (
            <div className="flex-1 overflow-y-auto p-4 space-y-2.5">
              {alerts.map((alert) => (
                <button
                  key={alert.id}
                  type="button"
                  onClick={() => {
                    const v = cleanVehicles.find((x) => x.id === alert.vehicleId);
                    if (v) selectVehicle(v);
                    onAlertSelect?.(alert);
                  }}
                  className="w-full text-right p-3 rounded-xl border border-slate-200 bg-white hover:border-blue-300 hover:bg-slate-50 transition-colors flex items-start gap-3 cursor-pointer"
                >
                  <div
                    className={`w-8 h-8 rounded-lg flex items-center justify-center shrink-0 ${
                      alert.severity === 'high'
                        ? 'bg-rose-50 text-rose-600'
                        : alert.severity === 'low'
                          ? 'bg-teal-50 text-teal-600'
                          : 'bg-amber-50 text-amber-600'
                    }`}
                  >
                    <AlertTriangle className="w-4 h-4" />
                  </div>
                  <div className="min-w-0 flex-1">
                    <div className="text-xs font-bold text-slate-900">{alert.title}</div>
                    <div className="text-[11px] text-slate-600 truncate mt-0.5">
                      {alert.description}
                    </div>
                    <div className="text-[10px] text-slate-400 mt-1">
                      {formatTime(alert.occurredAt)}
                    </div>
                  </div>
                </button>
              ))}
              {!alerts.length && (
                <div className="py-12 text-center text-xs text-slate-400">هشداری برای نمایش وجود ندارد.</div>
              )}
            </div>
          )}

          {/* Drawer Content: REPORTS & CHARTS */}
          {activeDrawer === 'reports' && (
            <div className="flex-1 overflow-y-auto p-4 space-y-4">
              <div className="grid grid-cols-3 gap-1 p-1 bg-slate-100 rounded-xl text-xs font-bold">
                <button
                  type="button"
                  onClick={() => {
                    setOpsTab('daily');
                    onDailyReportOpen?.();
                  }}
                  className={`py-1.5 rounded-lg cursor-pointer text-center ${
                    opsTab === 'daily' ? 'bg-white text-blue-600 shadow-xs' : 'text-slate-600'
                  }`}
                >
                  نمودار ۲۴h
                </button>
                <button
                  type="button"
                  onClick={() => setOpsTab('drivers')}
                  className={`py-1.5 rounded-lg cursor-pointer text-center ${
                    opsTab === 'drivers' ? 'bg-white text-blue-600 shadow-xs' : 'text-slate-600'
                  }`}
                >
                  رانندگان
                </button>
                <button
                  type="button"
                  onClick={() => setOpsTab('zones')}
                  className={`py-1.5 rounded-lg cursor-pointer text-center ${
                    opsTab === 'zones' ? 'bg-white text-blue-600 shadow-xs' : 'text-slate-600'
                  }`}
                >
                  محدوده‌ها
                </button>
              </div>

              <label className="flex items-center justify-between text-xs font-semibold text-slate-600 bg-slate-50 p-2.5 rounded-xl border border-slate-200">
                <span>تاریخ گزارش:</span>
                <input
                  type="date"
                  value={selectedDate}
                  onChange={(e) => {
                    setSelectedDate(e.target.value);
                    onDailyDateChange?.(e.target.value);
                  }}
                  className="px-2 py-1 rounded-lg border border-slate-200 bg-white text-xs font-mono"
                  dir="ltr"
                />
              </label>

              {opsTab === 'daily' && (
                <div className="space-y-3">
                  {dailyLoading ? (
                    <div className="py-8 text-center text-xs text-slate-400">در حال دریافت داده‌های روزانه…</div>
                  ) : dailyStatus.length > 0 ? (
                    <div className="space-y-2">
                      <div className="flex items-center gap-3 text-xs text-slate-600">
                        <span className="flex items-center gap-1">
                          <span className="w-2.5 h-2.5 rounded-xs bg-emerald-500" />
                          <span>در حرکت</span>
                        </span>
                        <span className="flex items-center gap-1">
                          <span className="w-2.5 h-2.5 rounded-xs bg-amber-400" />
                          <span>متوقف</span>
                        </span>
                      </div>
                      <div className="h-36 flex items-end gap-1 pt-3 pb-1 border-b border-slate-100 overflow-x-auto">
                        {dailyStatus.map((pt, idx) => {
                          const activeTotal = Math.max(1, pt.moving + pt.stopped + (pt.unknown || 0));
                          const movingRatio = pt.moving / activeTotal;
                          const stoppedRatio = pt.stopped / activeTotal;
                          const movingHeightClass =
                            movingRatio > 0.75
                              ? 'h-4/5'
                              : movingRatio > 0.5
                                ? 'h-3/5'
                                : movingRatio > 0.25
                                  ? 'h-2/5'
                                  : 'h-1/5';
                          const stoppedHeightClass =
                            stoppedRatio > 0.75
                              ? 'h-4/5'
                              : stoppedRatio > 0.5
                                ? 'h-3/5'
                                : stoppedRatio > 0.25
                                  ? 'h-2/5'
                                  : 'h-1/5';
                          return (
                            <div
                              key={pt.hour}
                              className="flex-1 min-w-[14px] flex flex-col items-center gap-1 h-full justify-end"
                            >
                              <div className="w-full max-w-[16px] h-24 bg-slate-100 rounded-t-xs overflow-hidden flex flex-col justify-end">
                                {pt.moving > 0 && <div className={`w-full bg-emerald-500 ${movingHeightClass}`} />}
                                {pt.stopped > 0 && <div className={`w-full bg-amber-400 ${stoppedHeightClass}`} />}
                              </div>
                              <span className="text-[9px] font-mono text-slate-400 tabular-nums" dir="ltr">
                                {idx % 3 === 0 ? pt.hour.slice(0, 2) : ''}
                              </span>
                            </div>
                          );
                        })}
                      </div>
                    </div>
                  ) : (
                    <button
                      type="button"
                      onClick={() => onDailyReportOpen?.()}
                      className="w-full py-2.5 rounded-xl bg-blue-600 text-white text-xs font-bold cursor-pointer"
                    >
                      دریافت گزارش ساعتی روز {selectedDate}
                    </button>
                  )}
                </div>
              )}

              {opsTab === 'drivers' && (
                <div className="space-y-2">
                  {driverRows.map((d) => (
                    <div
                      key={d.id}
                      className="p-2.5 rounded-xl border border-slate-200 bg-slate-50/70 flex items-center justify-between text-xs"
                    >
                      <div className="min-w-0">
                        <div className="font-bold text-slate-900 truncate">{d.name}</div>
                        <div className="text-[11px] text-slate-500 truncate">راننده ناوگان</div>
                      </div>
                      <div className="text-emerald-700 font-extrabold tabular-nums">
                        امتیاز {numberFa(d.score ?? 96)}
                      </div>
                    </div>
                  ))}
                </div>
              )}

              {opsTab === 'zones' && (
                <div className="space-y-2">
                  <button
                    type="button"
                    onClick={() => {
                      setZoneName('');
                      setZoneLat(selected?.latitude.toFixed(6) || '35.697300');
                      setZoneLon(selected?.longitude.toFixed(6) || '51.246600');
                      setZoneRadius('800');
                      setZoneFormOpen((v) => !v);
                    }}
                    className="w-full py-2 rounded-xl bg-blue-600 text-white text-xs font-bold flex items-center justify-center gap-1.5 cursor-pointer"
                  >
                    <Plus className="w-4 h-4" />
                    <span>افزودن محدوده جدید</span>
                  </button>

                  {zoneFormOpen && (
                    <form
                      onSubmit={(e) => {
                        e.preventDefault();
                        const lat = Number(zoneLat);
                        const lon = Number(zoneLon);
                        const radius = Number(zoneRadius);
                        if (!zoneName.trim() || !Number.isFinite(lat) || !Number.isFinite(lon)) return;
                        const newZone: FleetGeofence = {
                          id: `hami-zone-${Date.now()}`,
                          name: zoneName.trim(),
                          latitude: lat,
                          longitude: lon,
                          radiusMeters: radius,
                          kind: zoneKind,
                          color: zoneKind === 'parking' ? '#2563eb' : '#d97706',
                          active: true,
                          userDefined: true,
                        };
                        onGeofencesChange?.([...geofences, newZone]);
                        setZoneFormOpen(false);
                        setNotice('محدوده جدید ذخیره شد');
                      }}
                      className="p-3 bg-slate-100 rounded-xl space-y-2 text-xs"
                    >
                      <input
                        value={zoneName}
                        onChange={(e) => setZoneName(e.target.value)}
                        placeholder="نام محدوده"
                        required
                        className="w-full h-8 px-2.5 rounded-lg border border-slate-200 bg-white"
                      />
                      <div className="grid grid-cols-2 gap-2">
                        <input
                          type="number"
                          step="any"
                          value={zoneLat}
                          onChange={(e) => setZoneLat(e.target.value)}
                          placeholder="عرض جغرافیایی"
                          required
                          className="h-8 px-2.5 rounded-lg border border-slate-200 bg-white font-mono"
                        />
                        <input
                          type="number"
                          step="any"
                          value={zoneLon}
                          onChange={(e) => setZoneLon(e.target.value)}
                          placeholder="طول جغرافیایی"
                          required
                          className="h-8 px-2.5 rounded-lg border border-slate-200 bg-white font-mono"
                        />
                      </div>
                      <div className="flex gap-2">
                        <button
                          type="button"
                          onClick={() => setZonePicking(true)}
                          className="flex-1 py-1.5 rounded-lg bg-blue-100 text-blue-800 font-bold"
                        >
                          انتخاب روی نقشه
                        </button>
                        <button type="submit" className="px-3 py-1.5 rounded-lg bg-blue-600 text-white font-bold">
                          ذخیره
                        </button>
                      </div>
                    </form>
                  )}

                  <div className="space-y-1.5">
                    {geofences.map((z) => (
                      <div
                        key={z.id}
                        className="p-2.5 rounded-xl border border-slate-200 bg-white flex items-center justify-between text-xs"
                      >
                        <div className="min-w-0">
                          <div className="font-bold text-slate-800 truncate">{z.name}</div>
                          <div className="text-[10px] text-slate-400">شعاع {numberFa(z.radiusMeters)}m</div>
                        </div>
                        {z.userDefined && (
                          <button
                            type="button"
                            onClick={() => onGeofencesChange?.(geofences.filter((x) => x.id !== z.id))}
                            className="text-rose-500 hover:bg-rose-50 p-1.5 rounded-lg cursor-pointer"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        )}
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          )}
        </div>
      )}

      {/* 7. Floating Selected Vehicle Telemetry Card (Bottom-Right Edge) */}
      {selected && (
        <section className="absolute bottom-4 right-3 left-3 sm:left-auto sm:w-[480px] z-20 bg-white/95 backdrop-blur-md rounded-2xl border border-slate-200/95 shadow-2xl p-4 space-y-3">
          <div className="flex items-center justify-between gap-3 pb-2.5 border-b border-slate-100">
            <div className="flex items-center gap-2.5 min-w-0">
              <div
                className={`w-9 h-9 rounded-full flex items-center justify-center font-extrabold text-xs shrink-0 ${
                  categories[selected.category]?.badgeBgClass
                } ${categories[selected.category]?.badgeTextClass}`}
              >
                {categories[selected.category]?.icon}
              </div>
              <div className="min-w-0">
                <div className="flex items-center gap-1.5">
                  <h2 className="text-xs lg:text-sm font-extrabold text-slate-900 truncate">{selected.name}</h2>
                  <button
                    type="button"
                    onClick={() => openEditModal(selected)}
                    className="text-blue-600 hover:text-blue-800 cursor-pointer p-0.5"
                    title="ویرایش مشخصات"
                  >
                    <Edit3 className="w-3.5 h-3.5" />
                  </button>
                </div>
                <p className="text-[11px] text-slate-500 truncate">
                  {categories[selected.category]?.label} · کد <strong>{selected.vehicleCode}</strong>
                  {selected.plateNumber && ` · پلاک ${selected.plateNumber}`}
                  {selected.driverName && ` · راننده: ${selected.driverName}`}
                </p>
              </div>
            </div>

            <div className="flex items-center gap-1.5 shrink-0">
              <span
                className={`text-[11px] font-extrabold px-2.5 py-1 rounded-lg ${
                  selected.online === false
                    ? 'bg-slate-100 text-slate-600'
                    : (selected.speedKph ?? 0) > 0
                      ? 'bg-emerald-50 text-emerald-700'
                      : 'bg-amber-50 text-amber-700'
                }`}
              >
                {selected.online === false
                  ? 'آفلاین'
                  : (selected.speedKph ?? 0) > 0
                    ? `در حرکت (${numberFa(selected.speedKph ?? 0)} km/h)`
                    : 'متوقف آنلاین'}
              </span>
              <button
                type="button"
                onClick={() => setSelectedId(null)}
                className="w-7 h-7 rounded-lg text-slate-400 hover:text-slate-800 flex items-center justify-center cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
          </div>

          {/* Quick Telemetry Strip */}
          <div className="grid grid-cols-4 gap-2 text-center text-xs">
            <div className="bg-slate-50 p-2 rounded-xl border border-slate-100">
              <div className="text-[10px] text-slate-400">سرعت</div>
              <div className="font-extrabold text-slate-800 tabular-nums mt-0.5">
                {selected.online ? `${numberFa(selected.speedKph ?? 0)} km/h` : '—'}
              </div>
            </div>
            <div className="bg-slate-50 p-2 rounded-xl border border-slate-100">
              <div className="text-[10px] text-slate-400">سوئیچ (ACC)</div>
              <div className="font-extrabold text-slate-800 mt-0.5">
                {selected.accStatus === true ? 'روشن' : selected.accStatus === false ? 'خاموش' : 'نامشخص'}
              </div>
            </div>
            <div className="bg-slate-50 p-2 rounded-xl border border-slate-100">
              <div className="text-[10px] text-slate-400">برق / باتری</div>
              <div className="font-extrabold text-slate-800 tabular-nums mt-0.5">
                {selected.externalPower ? `${selected.externalPower}V` : 'نرمال'}
              </div>
            </div>
            <div className="bg-slate-50 p-2 rounded-xl border border-slate-100">
              <div className="text-[10px] text-slate-400">جهت</div>
              <div className="font-extrabold text-slate-800 mt-0.5">
                {formatHeadingLabel(selected.heading)}
              </div>
            </div>
          </div>

          {/* Dedicated Oil Change & Maintenance Quick Summary for this vehicle */}
          {selectedVehicleMaintStatus && (
            <div className="p-2.5 rounded-xl bg-amber-50/60 border border-amber-200/80 space-y-1.5">
              <div className="flex items-center justify-between text-xs">
                <span className="font-bold text-amber-900 flex items-center gap-1">
                  <Fuel className="w-3.5 h-3.5 text-amber-600" />
                  <span>سرویس و تعویض روغن</span>
                </span>
                <button
                  type="button"
                  onClick={() =>
                    openRecordLogModal({
                      vehicleId: selected.id,
                      vehicleName: selected.name,
                      currentKm: selectedVehicleMaintStatus.currentKm,
                      serviceType: 'engine_oil',
                    })
                  }
                  className="text-[11px] font-bold text-emerald-700 hover:text-emerald-900 flex items-center gap-0.5 cursor-pointer"
                >
                  <Plus className="w-3 h-3" />
                  <span>ثبت تعویض روغن</span>
                </button>
              </div>

              {selectedVehicleMaintStatus.services[0] && (
                <div className="text-[11px] text-slate-700 space-y-1">
                  <div className="flex items-center justify-between">
                    <span>
                      مانده کیلومتری: {numberFa(selectedVehicleMaintStatus.services[0].kmRemaining)} km
                    </span>
                    <span>
                      سررسید: {numberFa(selectedVehicleMaintStatus.services[0].daysRemaining)} روز دیگر
                    </span>
                  </div>
                  <div className="w-full h-1.5 bg-amber-200/60 rounded-full overflow-hidden">
                    <div
                      className={`h-full rounded-full ${
                        selectedVehicleMaintStatus.services[0].isKmOverdue
                          ? 'bg-rose-600'
                          : selectedVehicleMaintStatus.services[0].isDueSoon
                            ? 'bg-amber-500'
                            : 'bg-emerald-600'
                      }`}
                      style={{
                        width: `${Math.min(100, selectedVehicleMaintStatus.services[0].kmPercentage)}%`,
                      }}
                    />
                  </div>
                </div>
              )}
            </div>
          )}

          {/* Location & Reverse Geocode */}
          <div className="text-[11px] text-slate-600 flex items-center justify-between gap-2 px-1">
            <span className="truncate">
              <strong>آدرس:</strong>{' '}
              {selected.locationLabel || resolvedAddress[selected.id] || 'در حال شناسایی آدرس…'}
            </span>
            <span className="font-mono text-[10px] text-slate-400 shrink-0 tabular-nums" dir="ltr">
              {selected.latitude.toFixed(4)}, {selected.longitude.toFixed(4)}
            </span>
          </div>

          {/* Action Buttons */}
          <div className="flex flex-wrap items-center gap-1.5 pt-1">
            <a
              href={neshanUrl(selected.latitude, selected.longitude)}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-rose-600 hover:bg-rose-700 text-white text-xs font-bold transition-colors whitespace-nowrap"
            >
              <span className="w-3.5 h-3.5 rounded bg-white text-rose-600 flex items-center justify-center font-black text-[9px]">
                ن
              </span>
              <span>نشان</span>
            </a>

            <a
              href={baladUrl(selected.latitude, selected.longitude)}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-sky-600 hover:bg-sky-700 text-white text-xs font-bold transition-colors whitespace-nowrap"
            >
              <Navigation className="w-3.5 h-3.5" />
              <span>بلد</span>
            </a>

            <a
              href={googleMapsUrl(selected.latitude, selected.longitude)}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-1 px-2.5 py-1.5 rounded-xl border border-slate-200 bg-white hover:bg-slate-50 text-slate-700 text-xs font-bold transition-colors whitespace-nowrap"
            >
              <MapPin className="w-3.5 h-3.5 text-emerald-600" />
              <span>گوگل</span>
            </a>

            <button
              type="button"
              onClick={() => void shareVehicle(selected)}
              className="inline-flex items-center gap-1 px-2.5 py-1.5 rounded-xl border border-slate-200 bg-white hover:bg-slate-50 text-slate-700 text-xs font-bold transition-colors whitespace-nowrap cursor-pointer"
            >
              <Share2 className="w-3.5 h-3.5" />
              <span>اشتراک</span>
            </button>

            <button
              type="button"
              onClick={beginRoutePlayback}
              className="inline-flex items-center gap-1 px-3 py-1.5 rounded-xl bg-blue-50 hover:bg-blue-100 text-blue-700 border border-blue-200 text-xs font-bold transition-colors whitespace-nowrap cursor-pointer"
            >
              <Route className="w-3.5 h-3.5" />
              <span>بازپخش مسیر ({numberFa(route.length)})</span>
            </button>

            <button
              type="button"
              onClick={() => {
                setNavPickMode(true);
                setActiveDrawer('navigation');
              }}
              className="inline-flex items-center gap-1 px-3 py-1.5 rounded-xl bg-emerald-50 hover:bg-emerald-100 text-emerald-700 border border-emerald-200 text-xs font-bold transition-colors whitespace-nowrap cursor-pointer"
            >
              <Compass className="w-3.5 h-3.5" />
              <span>پیمایش جاده‌ای</span>
            </button>
          </div>
        </section>
      )}

      {/* 8. Floating Route Playback Bar (Docks at Bottom Center) */}
      {routeOpen && selected && (
        <div className="absolute bottom-4 left-1/2 -translate-x-1/2 w-[92vw] sm:w-[600px] z-30 bg-white/95 backdrop-blur-md border border-blue-200 rounded-2xl p-3.5 shadow-2xl space-y-2.5">
          <div className="flex items-center justify-between text-xs font-bold text-slate-800">
            <span className="flex items-center gap-1.5">
              <Route className="w-4 h-4 text-blue-600" />
              <span>بازپخش مسیر: {selected.name}</span>
            </span>
            <div className="flex items-center gap-3">
              <span className="text-[11px] text-slate-500 font-mono tabular-nums">
                {currentPlaybackPoint ? formatTime(currentPlaybackPoint.timestamp) : ''} ·{' '}
                {currentPlaybackPoint ? `${numberFa(currentPlaybackPoint.speedKph ?? 0)} km/h` : ''}
              </span>
              <button
                type="button"
                onClick={() => {
                  setRouteOpen(false);
                  setRoutePlaying(false);
                }}
                className="text-slate-400 hover:text-slate-700 cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
          </div>

          <div className="flex items-center gap-2.5">
            <button
              type="button"
              onClick={() => {
                if (routeIndex >= route.length - 1) setRouteIndex(0);
                setRoutePlaying((v) => !v);
              }}
              className="px-3 py-1.5 rounded-lg bg-blue-600 text-white text-xs font-bold flex items-center gap-1 cursor-pointer"
            >
              {routePlaying ? <Pause className="w-3.5 h-3.5" /> : <Play className="w-3.5 h-3.5" />}
              <span>{routePlaying ? 'توقف' : 'پخش'}</span>
            </button>

            <div className="flex items-center bg-slate-100 rounded-lg p-0.5 text-[10px] font-bold">
              {([1, 2, 4] as const).map((spd) => (
                <button
                  key={spd}
                  type="button"
                  onClick={() => setRouteSpeedMultiplier(spd)}
                  className={`px-1.5 py-0.5 rounded cursor-pointer ${
                    routeSpeedMultiplier === spd ? 'bg-white text-blue-600 shadow-xs' : 'text-slate-600'
                  }`}
                >
                  {spd}x
                </button>
              ))}
            </div>

            <input
              type="range"
              min={0}
              max={Math.max(0, route.length - 1)}
              value={Math.min(routeIndex, Math.max(0, route.length - 1))}
              onChange={(e) => {
                setRouteIndex(Number(e.target.value));
                setRoutePlaying(false);
              }}
              className="flex-1 accent-blue-600 cursor-pointer"
            />

            <span className="text-[11px] text-slate-500 tabular-nums shrink-0">
              {numberFa(routeIndex + 1)} / {numberFa(route.length)}
            </span>
          </div>
        </div>
      )}

      {/* 9. Floating Active Navigation Guidance Card */}
      {activeNavRoute && (
        <div className="absolute top-20 right-3 left-3 sm:left-auto sm:w-[480px] z-20 bg-emerald-950/90 text-white backdrop-blur-md rounded-2xl p-3.5 border border-emerald-500/40 shadow-2xl flex items-center justify-between gap-3">
          <div className="min-w-0">
            <div className="flex items-center gap-2 text-xs font-extrabold text-emerald-400">
              <CornerUpLeft className="w-4 h-4 shrink-0" />
              <span className="truncate">{activeNavRoute.steps[0]?.name || activeNavRoute.toLabel}</span>
            </div>
            <div className="text-[11px] text-emerald-200/80 mt-0.5">
              مسافت: <strong className="text-white tabular-nums">{numberFa(activeNavRoute.distanceKm)} km</strong> · زمان
              تقریبی: <strong className="text-white tabular-nums">~{numberFa(activeNavRoute.durationMinutes)} دقیقه</strong>
            </div>
          </div>
          <button
            type="button"
            onClick={() => setActiveNavRoute(null)}
            className="text-emerald-300 hover:text-white p-1 rounded-lg cursor-pointer"
            title="پایان پیمایش"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* 10. Modal: Define / Edit Maintenance Rule (تعریف قوانین سه‌گانه سرعتی، کیلومتری، روزانه) */}
      {ruleModalOpen && (
        <div className="fixed inset-0 z-[1600] bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <form
            onSubmit={handleSaveRule}
            className="bg-white rounded-2xl border border-slate-200 p-5 w-full max-w-lg shadow-2xl space-y-4 max-h-[92vh] overflow-y-auto"
          >
            <div className="flex items-center justify-between border-b border-slate-100 pb-2.5">
              <div className="flex items-center gap-2">
                <Wrench className="w-5 h-5 text-blue-600" />
                <h3 className="text-sm font-extrabold text-slate-900">
                  {editingRuleId ? 'ویرایش قانون و لیمیت‌های سرویس' : 'تعریف قانون جدید سرویس و نگهداری'}
                </h3>
              </div>
              <button
                type="button"
                onClick={() => setRuleModalOpen(false)}
                className="text-slate-400 hover:text-slate-600 cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="space-y-3 text-xs">
              <label className="flex flex-col gap-1 font-semibold text-slate-700">
                <span>عنوان سرویس</span>
                <input
                  value={ruleTitle}
                  onChange={(e) => setRuleTitle(e.target.value)}
                  placeholder="مثلاً: تعویض روغن موتور و فیلترها"
                  required
                  className="h-9 px-3 rounded-lg border border-slate-200 text-xs"
                />
              </label>

              <div className="grid grid-cols-2 gap-3">
                <label className="flex flex-col gap-1 font-semibold text-slate-700">
                  <span>نوع قطعه / عملیات</span>
                  <select
                    value={ruleServiceType}
                    onChange={(e) => {
                      const st = e.target.value as ServiceType;
                      setRuleServiceType(st);
                      if (!editingRuleId) setRuleTitle(SERVICE_TYPE_LABELS[st]);
                    }}
                    className="h-9 px-2.5 rounded-lg border border-slate-200 bg-white text-xs"
                  >
                    <option value="engine_oil">روغن موتور و فیلتر روغن</option>
                    <option value="gearbox_oil">روغن گیربکس و واسکازین</option>
                    <option value="brake_pads">لنت ترمز و چرخ‌ها</option>
                    <option value="filters">فیلتر سوخت و هوا</option>
                    <option value="belts">تسمه تایم و دینام</option>
                    <option value="general">آچارکشی و سرویس کلی</option>
                    <option value="custom">سایر موارد سفارشی</option>
                  </select>
                </label>

                <label className="flex flex-col gap-1 font-semibold text-slate-700">
                  <span>دامنه اعمال قانون</span>
                  <select
                    value={ruleScope}
                    onChange={(e) => setRuleScope(e.target.value as any)}
                    className="h-9 px-2.5 rounded-lg border border-slate-200 bg-white text-xs"
                  >
                    <option value="all">تمام ناوگان</option>
                    <option value="category">دسته خاص (خاور، ایسوزو…)</option>
                    <option value="vehicle">یک خودروی خاص</option>
                  </select>
                </label>
              </div>

              {ruleScope === 'category' && (
                <label className="flex flex-col gap-1 font-semibold text-slate-700">
                  <span>انتخاب دسته خودرو</span>
                  <select
                    value={ruleCategory}
                    onChange={(e) => setRuleCategory(e.target.value as VehicleCategory)}
                    className="h-9 px-2.5 rounded-lg border border-slate-200 bg-white text-xs"
                  >
                    <option value="khavar">خاور / بنز</option>
                    <option value="hyundai">هیوندای مایتی</option>
                    <option value="isuzu">ایسوزو ۵.۲ و ۶ تن</option>
                    <option value="nissan">نیسان زامیاد</option>
                    <option value="other">سایر خودروها</option>
                  </select>
                </label>
              )}

              {ruleScope === 'vehicle' && (
                <label className="flex flex-col gap-1 font-semibold text-slate-700">
                  <span>انتخاب خودرو</span>
                  <select
                    value={ruleVehicleId}
                    onChange={(e) => setRuleVehicleId(e.target.value)}
                    className="h-9 px-2.5 rounded-lg border border-slate-200 bg-white text-xs"
                  >
                    {cleanVehicles.map((v) => (
                      <option key={v.id} value={v.id}>
                        {v.name} (کد {v.vehicleCode})
                      </option>
                    ))}
                  </select>
                </label>
              )}

              {/* Limits Box (کیلومتری و روزانه) */}
              <div className="bg-slate-50 border border-slate-200 rounded-xl p-3 space-y-3">
                <div className="text-[11px] font-extrabold text-slate-800 flex items-center gap-1.5">
                  <SlidersHorizontal className="w-3.5 h-3.5 text-blue-600" />
                  <span>تعریف لیمیت‌های سرویس (کیلومتری و روزانه)</span>
                </div>

                <div className="grid grid-cols-2 gap-2.5">
                  {/* 1. لیمیت کیلومتری */}
                  <label className="flex flex-col gap-1 font-semibold text-slate-700">
                    <span>۱. لیمیت کیلومتر (km)</span>
                    <input
                      type="number"
                      min={500}
                      step={100}
                      value={ruleKmInterval}
                      onChange={(e) => setRuleKmInterval(e.target.value)}
                      required
                      placeholder="مثلاً 5000"
                      className="h-9 px-2.5 rounded-lg border border-slate-200 bg-white font-mono text-xs"
                    />
                  </label>

                  {/* 2. لیمیت روزانه */}
                  <label className="flex flex-col gap-1 font-semibold text-slate-700">
                    <span>۲. لیمیت روزانه (روز)</span>
                    <input
                      type="number"
                      min={7}
                      value={ruleDaysInterval}
                      onChange={(e) => setRuleDaysInterval(e.target.value)}
                      required
                      placeholder="مثلاً 90"
                      className="h-9 px-2.5 rounded-lg border border-slate-200 bg-white font-mono text-xs"
                    />
                  </label>
                </div>

                <div className="grid grid-cols-2 gap-2.5 pt-1 text-slate-500 text-[11px]">
                  <label className="flex flex-col gap-1 font-semibold">
                    <span>هشدار زودهنگام کیلومتر (km قبل)</span>
                    <input
                      type="number"
                      value={ruleWarningKmLead}
                      onChange={(e) => setRuleWarningKmLead(e.target.value)}
                      className="h-8 px-2 rounded-lg border border-slate-200 bg-white font-mono text-xs"
                    />
                  </label>
                  <label className="flex flex-col gap-1 font-semibold">
                    <span>هشدار زودهنگام روزانه (روز قبل)</span>
                    <input
                      type="number"
                      value={ruleWarningDaysLead}
                      onChange={(e) => setRuleWarningDaysLead(e.target.value)}
                      className="h-8 px-2 rounded-lg border border-slate-200 bg-white font-mono text-xs"
                    />
                  </label>
                </div>
              </div>
            </div>

            <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-100">
              <button
                type="button"
                onClick={() => setRuleModalOpen(false)}
                className="px-4 py-2 rounded-lg border border-slate-200 text-xs font-bold text-slate-600 cursor-pointer"
              >
                انصراف
              </button>
              <button
                type="submit"
                disabled={savingRule}
                className="px-4 py-2 rounded-lg bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold cursor-pointer"
              >
                {savingRule ? 'در حال ثبت...' : 'ذخیره قانون سرویس'}
              </button>
            </div>
          </form>
        </div>
      )}

      {/* 11. Modal: Record Service Entry / Oil Change (ثبت انجام تعویض روغن یا سرویس) */}
      {logModalOpen && (
        <div className="fixed inset-0 z-[1600] bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <form
            onSubmit={handleRecordLog}
            className="bg-white rounded-2xl border border-slate-200 p-5 w-full max-w-md shadow-2xl space-y-3.5 max-h-[92vh] overflow-y-auto"
          >
            <div className="flex items-center justify-between border-b border-slate-100 pb-2.5">
              <div className="flex items-center gap-2">
                <CheckCircle2 className="w-5 h-5 text-emerald-600" />
                <h3 className="text-sm font-extrabold text-slate-900">
                  ثبت انجام سرویس / تعویض روغن
                </h3>
              </div>
              <button
                type="button"
                onClick={() => setLogModalOpen(false)}
                className="text-slate-400 hover:text-slate-600 cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="p-2.5 bg-blue-50 border border-blue-200 rounded-xl text-xs text-blue-900">
              <strong>خودرو:</strong> {logVehicleName}
              <div className="text-[11px] text-blue-700 mt-0.5">
                با ثبت این سرویس، لیمیت‌های کیلومتری و روزانه این خودرو از نو ریست خواهند شد.
              </div>
            </div>

            <div className="space-y-2.5 text-xs">
              <label className="flex flex-col gap-1 font-semibold text-slate-700">
                <span>نوع سرویس انجام‌شده</span>
                <select
                  value={logServiceType}
                  onChange={(e) => {
                    const st = e.target.value as ServiceType;
                    setLogServiceType(st);
                    setLogTitle(SERVICE_TYPE_LABELS[st]);
                  }}
                  className="h-9 px-2.5 rounded-lg border border-slate-200 bg-white"
                >
                  <option value="engine_oil">تعویض روغن موتور و فیلتر روغن</option>
                  <option value="gearbox_oil">واسکازین گیربکس و دیفرانسیل</option>
                  <option value="brake_pads">لنت ترمز و چرخ‌ها</option>
                  <option value="filters">فیلتر سوخت و فیلتر هوا</option>
                  <option value="belts">تسمه تایم و دینام</option>
                  <option value="general">آچارکشی و سرویس کلی</option>
                </select>
              </label>

              <div className="grid grid-cols-2 gap-2.5">
                <label className="flex flex-col gap-1 font-semibold text-slate-700">
                  <span>کیلومتر در زمان تعویض (km)</span>
                  <input
                    type="number"
                    value={logServiceKm}
                    onChange={(e) => setLogServiceKm(e.target.value)}
                    required
                    className="h-9 px-3 rounded-lg border border-slate-200 font-mono"
                  />
                </label>

                <label className="flex flex-col gap-1 font-semibold text-slate-700">
                  <span>تاریخ انجام سرویس</span>
                  <input
                    type="date"
                    value={logServiceDate}
                    onChange={(e) => setLogServiceDate(e.target.value)}
                    required
                    className="h-9 px-2.5 rounded-lg border border-slate-200 font-mono"
                    dir="ltr"
                  />
                </label>
              </div>

              <div className="grid grid-cols-2 gap-2.5">
                <label className="flex flex-col gap-1 font-semibold text-slate-700">
                  <span>برند و گرانروی روغن</span>
                  <input
                    value={logOilBrand}
                    onChange={(e) => setLogOilBrand(e.target.value)}
                    placeholder="مثلاً: بهران سوپر توربو 15W40"
                    className="h-9 px-3 rounded-lg border border-slate-200"
                  />
                </label>

                <label className="flex flex-col gap-1 font-semibold text-slate-700">
                  <span>محل تعویض / تعمیرگاه</span>
                  <input
                    value={logWorkshopName}
                    onChange={(e) => setLogWorkshopName(e.target.value)}
                    placeholder="نام تعمیرگاه یا پایانه"
                    className="h-9 px-3 rounded-lg border border-slate-200"
                  />
                </label>
              </div>

              <div className="grid grid-cols-2 gap-2.5">
                <label className="flex flex-col gap-1 font-semibold text-slate-700">
                  <span>نام سرویس‌کار</span>
                  <input
                    value={logTechnicianName}
                    onChange={(e) => setLogTechnicianName(e.target.value)}
                    placeholder="نام اوستا یا راننده"
                    className="h-9 px-3 rounded-lg border border-slate-200"
                  />
                </label>

                <label className="flex flex-col gap-1 font-semibold text-slate-700">
                  <span>هزینه کل فاکتور (تومان)</span>
                  <input
                    type="number"
                    value={logCostToman}
                    onChange={(e) => setLogCostToman(e.target.value)}
                    placeholder="مبلغ به تومان"
                    className="h-9 px-3 rounded-lg border border-slate-200 font-mono"
                  />
                </label>
              </div>

              <label className="flex flex-col gap-1 font-semibold text-slate-700">
                <span>یادداشت و اقلام تعویضی</span>
                <input
                  value={logNotes}
                  onChange={(e) => setLogNotes(e.target.value)}
                  placeholder="مثلاً: تعویض روغن + فیلتر سرکان و فیلتر گازوئیل"
                  className="h-9 px-3 rounded-lg border border-slate-200"
                />
              </label>
            </div>

            <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-100">
              <button
                type="button"
                onClick={() => setLogModalOpen(false)}
                className="px-4 py-2 rounded-lg border border-slate-200 text-xs font-bold text-slate-600 cursor-pointer"
              >
                انصراف
              </button>
              <button
                type="submit"
                disabled={savingLog}
                className="px-4 py-2 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold cursor-pointer"
              >
                {savingLog ? 'در حال ثبت...' : 'ثبت قطعی و ریست دوره'}
              </button>
            </div>
          </form>
        </div>
      )}

      {/* 12. Edit Vehicle Metadata Modal */}
      {editingVehicle && (
        <div className="fixed inset-0 z-[1500] bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <form
            onSubmit={handleSaveMeta}
            className="bg-white rounded-2xl border border-slate-200 p-5 w-full max-w-md shadow-2xl space-y-3.5"
          >
            <div className="flex items-center justify-between border-b border-slate-100 pb-2.5">
              <h3 className="text-sm font-extrabold text-slate-900">ویرایش مشخصات خودرو و راننده</h3>
              <button
                type="button"
                onClick={() => setEditingVehicle(null)}
                className="text-slate-400 hover:text-slate-600 cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="space-y-2.5 text-xs">
              <label className="flex flex-col gap-1 font-semibold text-slate-700">
                <span>نام نمایشی وسیله</span>
                <input
                  value={editName}
                  onChange={(e) => setEditName(e.target.value)}
                  required
                  className="h-9 px-3 rounded-lg border border-slate-200"
                />
              </label>

              <div className="grid grid-cols-2 gap-2.5">
                <label className="flex flex-col gap-1 font-semibold text-slate-700">
                  <span>دسته‌بندی خودرو</span>
                  <select
                    value={editCategory}
                    onChange={(e) => setEditCategory(e.target.value as VehicleCategory)}
                    className="h-9 px-2.5 rounded-lg border border-slate-200 bg-white"
                  >
                    <option value="khavar">خاور</option>
                    <option value="hyundai">هیوندای</option>
                    <option value="isuzu">ایسوزو</option>
                    <option value="nissan">نیسان</option>
                    <option value="other">سایر</option>
                  </select>
                </label>

                <label className="flex flex-col gap-1 font-semibold text-slate-700">
                  <span>کد داخلی وسیله</span>
                  <input
                    value={editCode}
                    onChange={(e) => setEditCode(e.target.value)}
                    required
                    className="h-9 px-3 rounded-lg border border-slate-200 font-mono"
                  />
                </label>
              </div>

              <div className="grid grid-cols-2 gap-2.5">
                <label className="flex flex-col gap-1 font-semibold text-slate-700">
                  <span>نام راننده</span>
                  <input
                    value={editDriver}
                    onChange={(e) => setEditDriver(e.target.value)}
                    placeholder="نام و نام خانوادگی"
                    className="h-9 px-3 rounded-lg border border-slate-200"
                  />
                </label>

                <label className="flex flex-col gap-1 font-semibold text-slate-700">
                  <span>شماره پلاک</span>
                  <input
                    value={editPlate}
                    onChange={(e) => setEditPlate(e.target.value)}
                    placeholder="مثلاً 55 ایران 54 ع 122"
                    className="h-9 px-3 rounded-lg border border-slate-200"
                  />
                </label>
              </div>

              <label className="flex flex-col gap-1 font-semibold text-slate-700">
                <span>مانده تا سرویس دوره‌ای بعدی (کیلومتر)</span>
                <input
                  type="number"
                  value={editServiceKm}
                  onChange={(e) => setEditServiceKm(e.target.value)}
                  placeholder="مثلاً 3500"
                  className="h-9 px-3 rounded-lg border border-slate-200 font-mono"
                />
              </label>
            </div>

            <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-100">
              <button
                type="button"
                onClick={() => setEditingVehicle(null)}
                className="px-4 py-2 rounded-lg border border-slate-200 text-xs font-bold text-slate-600 cursor-pointer"
              >
                انصراف
              </button>
              <button
                type="submit"
                disabled={savingMeta}
                className="px-4 py-2 rounded-lg bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold cursor-pointer"
              >
                {savingMeta ? 'در حال ذخیره...' : 'ذخیره تغییرات'}
              </button>
            </div>
          </form>
        </div>
      )}

      {/* 12b. Fuel Entry Modal (ثبت مرحله جدید سوخت‌گیری ناوگان) */}
      {fuelModalOpen && (
        <div className="fixed inset-0 z-[1600] bg-slate-950/60 backdrop-blur-xs flex items-center justify-center p-4">
          <form
            onSubmit={handleSaveFuelSubmit}
            className="w-full max-w-md rounded-2xl bg-white border border-slate-200 shadow-2xl p-4 space-y-3 text-xs"
          >
            <div className="flex items-center justify-between pb-2 border-b border-slate-100">
              <div className="flex items-center gap-1.5 font-bold text-slate-800 text-sm">
                <Fuel className="w-4 h-4 text-amber-500" />
                <span>ثبت مرحله جدید سوخت‌گیری ناوگان</span>
              </div>
              <button
                type="button"
                onClick={() => setFuelModalOpen(false)}
                className="text-slate-400 hover:text-slate-600 p-1 cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="space-y-2.5">
              <label className="flex flex-col gap-1 font-semibold text-slate-700">
                <span>انتخاب خودرو از ناوگان *</span>
                <select
                  value={fuelVehicleId}
                  onChange={(e) => {
                    const id = e.target.value;
                    setFuelVehicleId(id);
                    const v = cleanVehicles.find((veh) => veh.id === id);
                    if (v) {
                      setFuelVehicleCode(v.vehicleCode);
                      setFuelVehicleName(v.name);
                      setFuelOdometer(String(v.odometerKm || 42000));
                      setFuelType(v.category === 'nissan' ? 'petrol_regular' : 'diesel');
                      setFuelPricePerLiter(v.category === 'nissan' ? '3000' : '600');
                    }
                  }}
                  required
                  className="h-9 px-2.5 rounded-lg border border-slate-200 bg-white"
                >
                  {cleanVehicles.map((v) => (
                    <option key={v.id} value={v.id}>
                      کد {v.vehicleCode} - {v.name} ({v.driverName || 'بدون راننده'})
                    </option>
                  ))}
                </select>
              </label>

              <div className="grid grid-cols-2 gap-2">
                <label className="flex flex-col gap-1 font-semibold text-slate-700">
                  <span>تاریخ سوخت‌گیری</span>
                  <input
                    type="date"
                    value={fuelDate}
                    onChange={(e) => setFuelDate(e.target.value)}
                    required
                    className="h-9 px-2.5 rounded-lg border border-slate-200 font-mono text-xs"
                    dir="ltr"
                  />
                </label>

                <label className="flex flex-col gap-1 font-semibold text-slate-700">
                  <span>ساعت سوخت‌گیری</span>
                  <input
                    type="time"
                    value={fuelTime}
                    onChange={(e) => setFuelTime(e.target.value)}
                    className="h-9 px-2.5 rounded-lg border border-slate-200 font-mono text-xs"
                    dir="ltr"
                  />
                </label>
              </div>

              <div className="grid grid-cols-2 gap-2">
                <label className="flex flex-col gap-1 font-semibold text-slate-700">
                  <span>کیلومترشمار در زمان سوخت (km) *</span>
                  <input
                    type="number"
                    value={fuelOdometer}
                    onChange={(e) => setFuelOdometer(e.target.value)}
                    required
                    placeholder="مثلاً 42800"
                    className="h-9 px-3 rounded-lg border border-slate-200 font-mono text-xs font-bold"
                  />
                </label>

                <label className="flex flex-col gap-1 font-semibold text-slate-700">
                  <span>حجم سوخت‌گیری (لیتر) *</span>
                  <input
                    type="number"
                    step="0.1"
                    value={fuelLiters}
                    onChange={(e) => {
                      const liters = Number(e.target.value) || 0;
                      setFuelLiters(e.target.value);
                      const unit = Number(fuelPricePerLiter) || 600;
                      setFuelTotalCost(String(Math.round(liters * unit)));
                    }}
                    required
                    placeholder="مثلاً 110"
                    className="h-9 px-3 rounded-lg border border-slate-200 font-mono text-xs font-bold text-amber-600"
                  />
                </label>
              </div>

              <div className="grid grid-cols-2 gap-2">
                <label className="flex flex-col gap-1 font-semibold text-slate-700">
                  <span>نوع سوخت</span>
                  <select
                    value={fuelType}
                    onChange={(e) => {
                      const t = e.target.value as FuelType;
                      setFuelType(t);
                      if (t === 'petrol_regular' || t === 'petrol_super') {
                        setFuelPricePerLiter('3000');
                        setFuelTotalCost(String(Math.round((Number(fuelLiters) || 0) * 3000)));
                      } else {
                        setFuelPricePerLiter('600');
                        setFuelTotalCost(String(Math.round((Number(fuelLiters) || 0) * 600)));
                      }
                    }}
                    className="h-9 px-2.5 rounded-lg border border-slate-200 bg-white"
                  >
                    <option value="diesel">گازوئیل (دیزل سهمیه‌ای/آزاد)</option>
                    <option value="petrol_regular">بنزین معمولی</option>
                    <option value="petrol_super">بنزین سوپر</option>
                    <option value="cng">گاز طبیعی (CNG)</option>
                  </select>
                </label>

                <label className="flex flex-col gap-1 font-semibold text-slate-700">
                  <span>هزینه کل سوخت (ریال)</span>
                  <input
                    type="number"
                    value={fuelTotalCost}
                    onChange={(e) => setFuelTotalCost(e.target.value)}
                    placeholder="مبلغ به ریال"
                    className="h-9 px-3 rounded-lg border border-slate-200 font-mono text-xs font-bold"
                  />
                </label>
              </div>

              <label className="flex flex-col gap-1 font-semibold text-slate-700">
                <span>نام یا شماره جایگاه سوخت</span>
                <input
                  type="text"
                  value={fuelGasStation}
                  onChange={(e) => setFuelGasStation(e.target.value)}
                  placeholder="مثلاً جایگاه اختصاصی ۲۱۴ فتح"
                  className="h-9 px-3 rounded-lg border border-slate-200"
                />
              </label>

              <div className="flex items-center gap-2 pt-1">
                <input
                  type="checkbox"
                  id="fullTankCheck"
                  checked={fuelFullTank}
                  onChange={(e) => setFuelFullTank(e.target.checked)}
                  className="w-4 h-4 rounded text-blue-600 border-slate-300 cursor-pointer"
                />
                <label htmlFor="fullTankCheck" className="text-xs text-slate-700 font-bold cursor-pointer">
                  باک کاملاً پر شد (برای محاسبه دقیق نرخ مصرف لیتر در ۱۰۰ کیلومتر)
                </label>
              </div>

              <label className="flex flex-col gap-1 font-semibold text-slate-700">
                <span>یادداشت سوخت‌گیری</span>
                <input
                  type="text"
                  value={fuelNotes}
                  onChange={(e) => setFuelNotes(e.target.value)}
                  placeholder="مثلاً کارت سوخت شماره ۲، بارگیری قبل از سفر"
                  className="h-9 px-3 rounded-lg border border-slate-200"
                />
              </label>
            </div>

            <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-100">
              <button
                type="button"
                onClick={() => setFuelModalOpen(false)}
                className="px-4 py-2 rounded-lg border border-slate-200 text-xs font-bold text-slate-600 cursor-pointer"
              >
                انصراف
              </button>
              <button
                type="submit"
                disabled={savingFuel}
                className="px-4 py-2 rounded-lg bg-amber-500 hover:bg-amber-600 text-white text-xs font-bold cursor-pointer shadow-xs"
              >
                {savingFuel ? 'در حال ثبت...' : 'ثبت و محاسبه پیمایش'}
              </button>
            </div>
          </form>
        </div>
      )}

      {/* 13. Toast Notification */}
      {notice && (
        <div
          role="status"
          className="fixed bottom-5 left-1/2 -translate-x-1/2 z-[2000] px-4 py-2.5 rounded-xl bg-slate-900/95 text-white text-xs font-bold shadow-2xl flex items-center gap-2 border border-slate-700 backdrop-blur-md"
        >
          <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
          <span>{notice}</span>
        </div>
      )}
    </div>
  );
}

export default memo(FleetMapModule);
