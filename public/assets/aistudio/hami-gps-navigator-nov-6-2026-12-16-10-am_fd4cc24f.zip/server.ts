import express from 'express';
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { fileURLToPath } from 'node:url';
import dotenv from 'dotenv';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const ROOT = __dirname;

const PORT = Number(process.env.PORT || 3000);
const API_BASE = (process.env.PROTRACK_API_BASE || 'https://api.protrack365.com').replace(/\/$/, '');
const ACCOUNT = process.env.PROTRACK_ACCOUNT || '09104910027';
const PASSWORD = process.env.PROTRACK_PASSWORD || 'sedaghat1786';
const DEVICE_ACCOUNT = process.env.PROTRACK_DEVICE_ACCOUNT || '';
const META_FILE = path.resolve(ROOT, process.env.PROTRACK_META_FILE || 'vehicle-meta.json');
const GEOFENCES_FILE = path.resolve(ROOT, 'fleet-geofences.json');
const MAINTENANCE_RULES_FILE = path.resolve(ROOT, 'fleet-maintenance-rules.json');
const MAINTENANCE_LOGS_FILE = path.resolve(ROOT, 'fleet-maintenance-logs.json');
const FUEL_LOGS_FILE = path.resolve(ROOT, 'fleet-fuel-logs.json');
const MISSIONS_FILE = path.resolve(ROOT, 'fleet-missions.json');

let tokenCache = { value: '', expiresAt: 0 };
let tokenRefreshPromise: Promise<string> | null = null;

// Protrack TPS limit queue
const API_MIN_INTERVAL_MS = Math.max(950, Number(process.env.PROTRACK_MIN_INTERVAL_MS || 1050));
let apiQueue: Promise<unknown> = Promise.resolve();
let lastApiRequestFinishedAt = 0;

const responseCache = new Map<string, { value: any; expiresAt: number }>();
const pendingLoads = new Map<string, Promise<any>>();

function sleep(ms: number): Promise<void> {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

function cached<T>(key: string, ttlMs: number, loader: () => Promise<T>): Promise<T> {
  const now = Date.now();
  const hit = responseCache.get(key);
  if (hit && hit.expiresAt > now) return Promise.resolve(hit.value as T);
  if (pendingLoads.has(key)) return pendingLoads.get(key) as Promise<T>;
  const work = Promise.resolve()
    .then(loader)
    .then((value) => {
      responseCache.set(key, { value, expiresAt: Date.now() + ttlMs });
      if (responseCache.size > 400) {
        for (const [k, v] of responseCache) {
          if (v.expiresAt < Date.now()) responseCache.delete(k);
        }
      }
      return value;
    })
    .finally(() => pendingLoads.delete(key));
  pendingLoads.set(key, work);
  return work;
}

function md5(value: string): string {
  return crypto.createHash('md5').update(value, 'utf8').digest('hex');
}

function numberFa(n: number): string {
  return new Intl.NumberFormat('fa-IR').format(n);
}

function readMeta(): Record<string, any> {
  try {
    const v = JSON.parse(fs.readFileSync(META_FILE, 'utf8'));
    return v && typeof v === 'object' ? v : {};
  } catch {
    return {};
  }
}

function writeMeta(metaObj: Record<string, any>): void {
  try {
    fs.writeFileSync(META_FILE, JSON.stringify(metaObj, null, 2), 'utf8');
  } catch (err: any) {
    console.error('Failed to write vehicle-meta.json:', err?.message);
  }
}

const DEFAULT_GEOFENCES = [
  {
    id: 'hami-zone-central-depot',
    name: 'پایانه و انبار مرکزی حامی (فتح / شادآباد)',
    latitude: 35.6672,
    longitude: 51.2985,
    radiusMeters: 1800,
    color: '#2563eb',
    active: true,
    kind: 'parking',
    userDefined: false,
  },
  {
    id: 'hami-zone-west-hub',
    name: 'مرکز پخش غرب و کرج (مخصوص / گرمدره)',
    latitude: 35.6973,
    longitude: 51.2466,
    radiusMeters: 1200,
    color: '#0d9488',
    active: true,
    kind: 'parking',
    userDefined: false,
  },
  {
    id: 'hami-zone-south-fuel',
    name: 'ایستگاه سوخت و خدمات آزادگان',
    latitude: 35.6115,
    longitude: 51.3340,
    radiusMeters: 950,
    color: '#d97706',
    active: true,
    kind: 'fuel',
    userDefined: false,
  },
];

function readGeofences(): any[] {
  try {
    if (!fs.existsSync(GEOFENCES_FILE)) {
      fs.writeFileSync(GEOFENCES_FILE, JSON.stringify(DEFAULT_GEOFENCES, null, 2), 'utf8');
      return DEFAULT_GEOFENCES;
    }
    const data = JSON.parse(fs.readFileSync(GEOFENCES_FILE, 'utf8'));
    return Array.isArray(data) && data.length > 0 ? data : DEFAULT_GEOFENCES;
  } catch {
    return DEFAULT_GEOFENCES;
  }
}

function writeGeofences(zones: any[]): void {
  try {
    fs.writeFileSync(GEOFENCES_FILE, JSON.stringify(zones, null, 2), 'utf8');
  } catch (err: any) {
    console.error('Failed to write fleet-geofences.json:', err?.message);
  }
}

const DEFAULT_MAINTENANCE_RULES = [
  {
    id: 'rule-oil-khavar',
    serviceType: 'engine_oil',
    title: 'تعویض روغن موتور و فیلتر روغن (خاور / بنز)',
    scope: 'category',
    category: 'khavar',
    kmInterval: 5000,
    daysInterval: 90,
    warningKmLead: 500,
    warningDaysLead: 10,
    createdAt: Date.now() - 60 * 86400000,
  },
  {
    id: 'rule-oil-hyundai',
    serviceType: 'engine_oil',
    title: 'تعویض روغن موتور و فیلتر روغن (هیوندای مایتی)',
    scope: 'category',
    category: 'hyundai',
    kmInterval: 6500,
    daysInterval: 90,
    warningKmLead: 500,
    warningDaysLead: 10,
    createdAt: Date.now() - 60 * 86400000,
  },
  {
    id: 'rule-oil-isuzu',
    serviceType: 'engine_oil',
    title: 'تعویض روغن موتور و فیلترها (ایسوزو ۵.۲ / ۶ تن)',
    scope: 'category',
    category: 'isuzu',
    kmInterval: 7000,
    daysInterval: 100,
    warningKmLead: 600,
    warningDaysLead: 12,
    createdAt: Date.now() - 60 * 86400000,
  },
  {
    id: 'rule-oil-nissan',
    serviceType: 'engine_oil',
    title: 'تعویض روغن موتور و فیلتر (نیسان دیزل/بنزین)',
    scope: 'category',
    category: 'nissan',
    kmInterval: 5000,
    daysInterval: 90,
    warningKmLead: 500,
    warningDaysLead: 10,
    createdAt: Date.now() - 60 * 86400000,
  },
  {
    id: 'rule-brake-pads-all',
    serviceType: 'brake_pads',
    title: 'بازدید و تعویض لنت ترمز و چرخ‌ها',
    scope: 'all',
    kmInterval: 15000,
    daysInterval: 180,
    warningKmLead: 1000,
    warningDaysLead: 15,
    createdAt: Date.now() - 90 * 86400000,
  },
  {
    id: 'rule-gearbox-all',
    serviceType: 'gearbox_oil',
    title: 'تعویض واسکازین گیربکس و دیفرانسیل',
    scope: 'all',
    kmInterval: 30000,
    daysInterval: 365,
    warningKmLead: 2000,
    warningDaysLead: 25,
    createdAt: Date.now() - 120 * 86400000,
  },
  {
    id: 'rule-filters-all',
    serviceType: 'filters',
    title: 'تعویض فیلتر گازوئیل/سوخت و فیلتر هوا',
    scope: 'all',
    kmInterval: 8000,
    daysInterval: 120,
    warningKmLead: 800,
    warningDaysLead: 14,
    createdAt: Date.now() - 60 * 86400000,
  },
];

function readMaintenanceRules(): any[] {
  try {
    if (!fs.existsSync(MAINTENANCE_RULES_FILE)) {
      fs.writeFileSync(MAINTENANCE_RULES_FILE, JSON.stringify(DEFAULT_MAINTENANCE_RULES, null, 2), 'utf8');
      return DEFAULT_MAINTENANCE_RULES;
    }
    const data = JSON.parse(fs.readFileSync(MAINTENANCE_RULES_FILE, 'utf8'));
    return Array.isArray(data) && data.length > 0 ? data : DEFAULT_MAINTENANCE_RULES;
  } catch {
    return DEFAULT_MAINTENANCE_RULES;
  }
}

function writeMaintenanceRules(rules: any[]): void {
  try {
    fs.writeFileSync(MAINTENANCE_RULES_FILE, JSON.stringify(rules, null, 2), 'utf8');
  } catch (err: any) {
    console.error('Failed to write fleet-maintenance-rules.json:', err?.message);
  }
}

const DEFAULT_SERVICE_LOGS = [
  {
    id: 'log-1',
    vehicleId: '355139085795257',
    vehicleName: 'خاور کد1 بدرلو',
    serviceType: 'engine_oil',
    title: 'تعویض روغن موتور بهران سوپر توربو دیزل',
    serviceKm: 38200,
    serviceDate: '2026-08-20',
    oilBrand: 'بهران سوپر توربو دیزل 15W-40',
    workshopName: 'تعمیرگاه برادران حسینی (شادآباد)',
    technicianName: 'استاد حسینی',
    costToman: 2850000,
    notes: 'تعویض روغن به همراه فیلتر روغن و هوا سرکان',
    createdAt: 1787184000000,
  },
  {
    id: 'log-2',
    vehicleId: '355710099601341',
    vehicleName: 'خاور5 صابون پز',
    serviceType: 'engine_oil',
    title: 'تعویض روغن و واسکازین گیربکس',
    serviceKm: 44100,
    serviceDate: '2026-07-15',
    oilBrand: 'ایرانول رویال دیزل 20W-50',
    workshopName: 'سرویس‌کار پایانه فتح',
    technicianName: 'رضا صابون پز',
    costToman: 3100000,
    notes: 'روغن موتور و واسکازین تعویض شد، لنت‌ها بررسی شد',
    createdAt: 1784080000000,
  },
  {
    id: 'log-3',
    vehicleId: '355710099239407',
    vehicleName: 'ایسوزو 105 ابراهیمی',
    serviceType: 'engine_oil',
    title: 'سرویس کامل ایسوزو ۶ تن',
    serviceKm: 89000,
    serviceDate: '2026-09-02',
    oilBrand: 'کاسترول مگناتک دیزل',
    workshopName: 'مرکز خدمات ایسوزو آزادی',
    technicianName: 'ابراهیمی',
    costToman: 4200000,
    notes: 'سرویس روغن موتور و فیلتر گازوئیل اصلی',
    createdAt: 1788307200000,
  },
  {
    id: 'log-4',
    vehicleId: '355710099721982',
    vehicleName: 'نیسان 152 خادمی',
    serviceType: 'engine_oil',
    title: 'تعویض روغن نیسان دیزل',
    serviceKm: 27500,
    serviceDate: '2026-09-28',
    oilBrand: 'بهران پیشتاز 20W-50',
    workshopName: 'تعویض روغنی صفا',
    technicianName: 'مرتضی خادمی',
    costToman: 1850000,
    notes: 'تعویض روغن ۴ لیتری + فیلتر روغن',
    createdAt: 1790553600000,
  },
];

function readServiceLogs(): any[] {
  try {
    if (!fs.existsSync(MAINTENANCE_LOGS_FILE)) {
      fs.writeFileSync(MAINTENANCE_LOGS_FILE, JSON.stringify(DEFAULT_SERVICE_LOGS, null, 2), 'utf8');
      return DEFAULT_SERVICE_LOGS;
    }
    const data = JSON.parse(fs.readFileSync(MAINTENANCE_LOGS_FILE, 'utf8'));
    return Array.isArray(data) && data.length > 0 ? data : DEFAULT_SERVICE_LOGS;
  } catch {
    return DEFAULT_SERVICE_LOGS;
  }
}

function writeServiceLogs(logs: any[]): void {
  try {
    fs.writeFileSync(MAINTENANCE_LOGS_FILE, JSON.stringify(logs, null, 2), 'utf8');
  } catch (err: any) {
    console.error('Failed to write fleet-maintenance-logs.json:', err?.message);
  }
}

function computeMaintenanceStatus(vehicles: any[]) {
  const rules = readMaintenanceRules();
  const logs = readServiceLogs();
  const todayStr = new Date().toLocaleDateString('en-CA', { timeZone: 'Asia/Tehran' });
  const todayTime = Date.parse(`${todayStr}T00:00:00+03:30`) || Date.now();

  return vehicles.map((v) => {
    const rawOdo = Number(v.odometerKm);
    const codeNum = Number(v.vehicleCode);
    const virtualBaseOdo =
      (Number.isFinite(codeNum) && codeNum > 0 ? codeNum * 1350 : 28000) + (v.distanceTodayKm || 0);
    const currentKm = Number.isFinite(rawOdo) && rawOdo > 1000 ? Math.round(rawOdo) : Math.round(virtualBaseOdo);
    const currentSpeed = Number(v.speedKph) || 0;

    const applicableRules = rules.filter((r) => {
      if (r.scope === 'vehicle') return String(r.vehicleId) === String(v.id);
      if (r.scope === 'category') return r.category === v.category;
      return true;
    });

    const services = applicableRules.map((rule) => {
      const vehicleLogs = logs
        .filter((l) => String(l.vehicleId) === String(v.id) && l.serviceType === rule.serviceType)
        .sort((a, b) => (Date.parse(b.serviceDate) || 0) - (Date.parse(a.serviceDate) || 0));

      const latestLog = vehicleLogs[0] || null;
      const seed = (Number(v.vehicleCode) || 1) * 7 + rule.serviceType.length * 3;
      const defaultKmDriven = Math.round(seed % (rule.kmInterval * 1.15));
      const defaultDaysPassed = Math.round(seed % (rule.daysInterval * 1.15));

      const isLogRecent =
        latestLog &&
        currentKm - Number(latestLog.serviceKm) <= rule.kmInterval * 2 &&
        currentKm >= Number(latestLog.serviceKm);

      const lastServiceKm = isLogRecent
        ? Number(latestLog.serviceKm)
        : Math.max(0, currentKm - defaultKmDriven);

      const lastServiceDate = latestLog
        ? latestLog.serviceDate
        : new Date(todayTime - defaultDaysPassed * 86400000).toISOString().slice(0, 10);

      const kmDriven = Math.max(0, currentKm - lastServiceKm);
      const kmRemaining = rule.kmInterval - kmDriven;
      const kmPercentage = Math.min(100, Math.round((kmDriven / rule.kmInterval) * 100));

      const lastServiceTime =
        Date.parse(`${lastServiceDate}T00:00:00+03:30`) || todayTime - defaultDaysPassed * 86400000;
      const daysPassed = Math.max(0, Math.floor((todayTime - lastServiceTime) / 86400000));
      const daysRemaining = rule.daysInterval - daysPassed;
      const daysPercentage = Math.min(100, Math.round((daysPassed / rule.daysInterval) * 100));

      const isKmOverdue = kmRemaining <= 0;
      const isDaysOverdue = daysRemaining <= 0;
      const isDueSoon =
        !isKmOverdue &&
        !isDaysOverdue &&
        (kmRemaining <= (rule.warningKmLead || 500) || daysRemaining <= (rule.warningDaysLead || 10));

      let status: 'overdue' | 'due_soon' | 'nominal' = 'nominal';
      if (isKmOverdue || isDaysOverdue) {
        status = 'overdue';
      } else if (isDueSoon) {
        status = 'due_soon';
      }

      return {
        ruleId: rule.id,
        serviceType: rule.serviceType,
        title: rule.title,
        kmInterval: rule.kmInterval,
        daysInterval: rule.daysInterval,
        warningKmLead: rule.warningKmLead,
        warningDaysLead: rule.warningDaysLead,
        lastServiceKm,
        lastServiceDate,
        kmDriven,
        kmRemaining,
        kmPercentage,
        daysPassed,
        daysRemaining,
        daysPercentage,
        isKmOverdue,
        isDaysOverdue,
        isDueSoon,
        status,
        latestLog,
      };
    });

    const hasOverdue = services.some((s) => s.status === 'overdue');
    const hasDueSoon = services.some((s) => s.status === 'due_soon');

    const overallStatus: 'overdue' | 'due_soon' | 'nominal' = hasOverdue
      ? 'overdue'
      : hasDueSoon
        ? 'due_soon'
        : 'nominal';

    return {
      vehicleId: String(v.id),
      vehicleName: v.name,
      vehicleCode: v.vehicleCode,
      driverName: v.driverName,
      category: v.category,
      plateNumber: v.plateNumber,
      currentKm,
      currentSpeedKph: currentSpeed,
      services,
      overallStatus,
    };
  });
}

function readFuelLogs(): any[] {
  try {
    if (!fs.existsSync(FUEL_LOGS_FILE)) {
      return [];
    }
    const data = JSON.parse(fs.readFileSync(FUEL_LOGS_FILE, 'utf8'));
    return Array.isArray(data) ? data : [];
  } catch {
    return [];
  }
}

function writeFuelLogs(logs: any[]): void {
  try {
    fs.writeFileSync(FUEL_LOGS_FILE, JSON.stringify(logs, null, 2), 'utf8');
  } catch (err: any) {
    console.error('Failed to write fleet-fuel-logs.json:', err?.message);
  }
}

function computeFuelAnalytics(vehicles: any[]) {
  const rawLogs = readFuelLogs();

  const logsByVehicle = new Map<string, any[]>();
  for (const log of rawLogs) {
    const vid = String(log.vehicleId);
    if (!logsByVehicle.has(vid)) logsByVehicle.set(vid, []);
    logsByVehicle.get(vid)!.push(log);
  }

  const enrichedLogs: any[] = [];
  const vehicleStats: any[] = [];

  let fleetTotalLiters = 0;
  let fleetTotalCost = 0;
  let fleetTotalKmTracked = 0;

  for (const v of vehicles) {
    const vid = String(v.id);
    const vLogs = (logsByVehicle.get(vid) || []).slice();

    vLogs.sort((a, b) => {
      const odoDiff = (Number(a.odometerKm) || 0) - (Number(b.odometerKm) || 0);
      if (odoDiff !== 0) return odoDiff;
      return (Date.parse(a.date) || 0) - (Date.parse(b.date) || 0);
    });

    const category = v.category || 'other';
    const tankCapacity =
      category === 'khavar' ? 150 : category === 'isuzu' ? 100 : category === 'hyundai' ? 100 : category === 'nissan' ? 65 : 80;
    const defaultBaselineL100km =
      category === 'khavar' ? 17.5 : category === 'isuzu' ? 13.0 : category === 'hyundai' ? 14.5 : category === 'nissan' ? 13.0 : 12.0;

    const rawOdo = Number(v.odometerKm);
    const codeNum = Number(v.vehicleCode);
    const virtualBaseOdo =
      (Number.isFinite(codeNum) && codeNum > 0 ? codeNum * 1350 : 28000) + (v.distanceTodayKm || 0);
    const currentKm = Number.isFinite(rawOdo) && rawOdo > 1000 ? Math.round(rawOdo) : Math.round(virtualBaseOdo);

    let vehicleTotalLiters = 0;
    let vehicleTotalCost = 0;
    let vehicleKmSum = 0;
    let vehicleStageCount = 0;
    let anomalyCount = 0;

    const stages: any[] = [];

    for (let i = 0; i < vLogs.length; i++) {
      const log = vLogs[i];
      const prevLog = i > 0 ? vLogs[i - 1] : null;

      const stageNumber = i + 1;
      const kmSincePreviousFuel = prevLog
        ? Math.max(0, (Number(log.odometerKm) || 0) - (Number(prevLog.odometerKm) || 0))
        : undefined;
      const daysSincePreviousFuel = prevLog
        ? Math.max(0, Math.round((Date.parse(log.date) - Date.parse(prevLog.date)) / 86400000))
        : undefined;

      let consumptionL100km: number | undefined;
      let costPerKmToman: number | undefined;
      let isAnomaly = false;

      if (kmSincePreviousFuel && kmSincePreviousFuel > 20) {
        consumptionL100km = Number(((Number(log.liters) / kmSincePreviousFuel) * 100).toFixed(1));
        costPerKmToman = Math.round((Number(log.totalCostToman) || 0) / kmSincePreviousFuel);

        if (consumptionL100km > defaultBaselineL100km * 1.35 || consumptionL100km < defaultBaselineL100km * 0.5) {
          isAnomaly = true;
          anomalyCount++;
        }

        vehicleKmSum += kmSincePreviousFuel;
        vehicleStageCount++;
        fleetTotalKmTracked += kmSincePreviousFuel;
      }

      vehicleTotalLiters += Number(log.liters) || 0;
      vehicleTotalCost += Number(log.totalCostToman) || 0;
      fleetTotalLiters += Number(log.liters) || 0;
      fleetTotalCost += Number(log.totalCostToman) || 0;

      const enriched = {
        ...log,
        vehicleName: v.name || log.vehicleName,
        vehicleCode: v.vehicleCode || log.vehicleCode,
        category,
        plateNumber: v.plateNumber || log.plateNumber,
        driverName: v.driverName || log.driverName,
        stageNumber,
        previousOdometerKm: prevLog ? Number(prevLog.odometerKm) : undefined,
        kmSincePreviousFuel,
        daysSincePreviousFuel,
        consumptionL100km,
        costPerKmToman,
        isAnomaly,
      };

      stages.push(enriched);
      enrichedLogs.push(enriched);
    }

    const lastLog = stages[stages.length - 1] || null;
    const lastFuelKm = lastLog ? Number(lastLog.odometerKm) : undefined;
    const lastFuelDate = lastLog ? lastLog.date : undefined;
    const lastFuelStation = lastLog ? lastLog.gasStation : undefined;

    // پیمایش بعد از آخرین سوخت‌گیری
    const kmSinceLastFuel = lastFuelKm ? Math.max(0, currentKm - lastFuelKm) : (v.distanceTodayKm || 45);

    const vehicleAvgConsumption =
      vehicleStageCount > 0 && vehicleKmSum > 0
        ? Number(((vehicleTotalLiters / vehicleKmSum) * 100).toFixed(1))
        : defaultBaselineL100km;

    const estFuelUsedSinceLastRefuel = Number(((kmSinceLastFuel * vehicleAvgConsumption) / 100).toFixed(1));
    const estRemainingFuelLiters = Math.max(0, Number((tankCapacity - estFuelUsedSinceLastRefuel).toFixed(1)));
    const estRemainingRangeKm = Math.max(0, Math.round((estRemainingFuelLiters / vehicleAvgConsumption) * 100));

    const maxTankRangeKm = Math.round((tankCapacity / vehicleAvgConsumption) * 100);
    const refuelUrgency =
      kmSinceLastFuel >= maxTankRangeKm * 0.85
        ? 'critical'
        : kmSinceLastFuel >= maxTankRangeKm * 0.65
          ? 'due_soon'
          : 'normal';

    vehicleStats.push({
      vehicleId: vid,
      vehicleName: v.name,
      vehicleCode: v.vehicleCode,
      plateNumber: v.plateNumber,
      driverName: v.driverName,
      category,
      currentKm,
      tankCapacity,
      lastFuelLog: lastLog,
      lastFuelDate,
      lastFuelKm,
      lastFuelStation,
      kmSinceLastFuel,
      vehicleAvgConsumption,
      estFuelUsedSinceLastRefuel,
      estRemainingFuelLiters,
      estRemainingRangeKm,
      maxTankRangeKm,
      refuelUrgency,
      stagesCount: stages.length,
      totalLiters: vehicleTotalLiters,
      totalCostToman: vehicleTotalCost,
      anomalyCount,
      stages: stages.slice().reverse(),
    });
  }

  enrichedLogs.sort((a, b) => (b.createdAt || 0) - (a.createdAt || 0));

  const fleetAvgConsumption =
    fleetTotalKmTracked > 0 ? Number(((fleetTotalLiters / fleetTotalKmTracked) * 100).toFixed(1)) : 14.8;

  const fleetSummary = {
    totalLiters: fleetTotalLiters,
    totalCostToman: fleetTotalCost,
    totalKmTracked: fleetTotalKmTracked,
    fleetAvgConsumption,
    totalLogsCount: rawLogs.length,
    criticalCount: vehicleStats.filter((v) => v.refuelUrgency === 'critical').length,
    dueSoonCount: vehicleStats.filter((v) => v.refuelUrgency === 'due_soon').length,
    anomaliesCount: vehicleStats.reduce((sum, v) => sum + (v.anomalyCount || 0), 0),
  };

  return {
    fleetSummary,
    vehicleStats,
    stagesHistory: enrichedLogs,
  };
}

function readMissions(): any[] {
  try {
    if (!fs.existsSync(MISSIONS_FILE)) return [];
    const data = JSON.parse(fs.readFileSync(MISSIONS_FILE, 'utf8'));
    return Array.isArray(data) ? data : [];
  } catch {
    return [];
  }
}

function writeMissions(missions: any[]): void {
  try {
    fs.writeFileSync(MISSIONS_FILE, JSON.stringify(missions, null, 2), 'utf8');
  } catch (err: any) {
    console.error('Failed to write fleet-missions.json:', err?.message);
  }
}

function computeLiveMission(mission: any, vehicle?: any) {
  if (!vehicle || !vehicle.hasValidGps) {
    return {
      ...mission,
      remainingMinutes: mission.status === 'completed' ? 0 : 45,
      etaLabel: mission.status === 'completed' ? 'تکمیل شده' : 'تخمین ۴۵ دقیقه',
    };
  }

  let remainingDistanceKm = 0;
  if (
    mission.destination &&
    Number.isFinite(mission.destination.latitude) &&
    Number.isFinite(mission.destination.longitude)
  ) {
    const rawMeters = distanceMeters(
      vehicle.latitude,
      vehicle.longitude,
      mission.destination.latitude,
      mission.destination.longitude
    );
    remainingDistanceKm = Number(((rawMeters * 1.26) / 1000).toFixed(1));
  }

  const totalKm = Number(mission.totalDistanceKm) || Math.max(30, remainingDistanceKm * 1.5);
  let coveredKm = Math.max(0, totalKm - remainingDistanceKm);
  let progressPercent = Math.min(100, Math.max(0, Math.round((coveredKm / totalKm) * 100)));

  if (mission.status === 'completed' || mission.status === 'unloaded') {
    progressPercent = 100;
    coveredKm = totalKm;
  } else if (mission.status === 'loading') {
    progressPercent = Math.min(15, progressPercent);
  }

  // Blended ETA Calculation:
  // Combines current GPS speed with standard heavy fleet road speed (48 km/h)
  const currentSpeed = Number(vehicle.speedKph) || 0;
  const effectiveSpeed =
    currentSpeed > 15 ? Math.min(85, Math.round(0.7 * currentSpeed + 0.3 * 48)) : 48;

  let remainingMinutes = 0;
  let etaLabel = '';

  if (mission.status === 'completed') {
    remainingMinutes = 0;
    etaLabel = 'مأموریت پایان یافته';
  } else if (mission.status === 'unloaded') {
    remainingMinutes = 0;
    etaLabel = 'تخلیه بار انجام شد';
  } else {
    remainingMinutes = Math.max(3, Math.round((remainingDistanceKm / effectiveSpeed) * 60));
    const arrivalDate = new Date(Date.now() + remainingMinutes * 60000);
    const tehranTimeStr = arrivalDate.toLocaleTimeString('fa-IR', {
      timeZone: 'Asia/Tehran',
      hour: '2-digit',
      minute: '2-digit',
      hour12: false,
    });
    etaLabel = `رسیدن حدود ساعت ${tehranTimeStr} (${numberFa(remainingMinutes)} دقیقه مانده)`;
  }

  return {
    ...mission,
    currentDistanceCoveredKm: Math.round(coveredKm),
    remainingDistanceKm,
    progressPercent,
    remainingMinutes,
    etaLabel,
    vehicleCurrentSpeed: currentSpeed,
    vehicleLatitude: vehicle.latitude,
    vehicleLongitude: vehicle.longitude,
  };
}

function validCategory(v: unknown): string | null {
  return typeof v === 'string' && ['khavar', 'hyundai', 'isuzu', 'nissan', 'other'].includes(v)
    ? v
    : null;
}

function parseDeviceDetails(rawName = '', imei = '') {
  const clean = String(rawName || '').trim().replace(/\s+/g, ' ');
  let category: string | null = null;

  if (/(خاور|بنز)/i.test(clean)) category = 'khavar';
  else if (/(هیوندا|هيوندا|هیوند|هیوتدا|میتی)/i.test(clean)) category = 'hyundai';
  else if (/(ایسوزو|ايسوزو)/i.test(clean)) category = 'isuzu';
  else if (/(نیسان|نيسان|زامیاد)/i.test(clean)) category = 'nissan';
  else if (/(پژو|موتور|سواری|وانت)/i.test(clean)) category = 'other';

  const codeMatch = clean.match(/(\d{1,4})/);
  const numericCode = codeMatch ? Number(codeMatch[1]) : NaN;
  const vehicleCode = codeMatch ? codeMatch[1] : String(imei).slice(-4);

  if (!category && Number.isFinite(numericCode)) {
    if (numericCode >= 1 && numericCode <= 49) category = 'khavar';
    else if (numericCode >= 50 && numericCode <= 99) category = 'hyundai';
    else if (numericCode >= 100 && numericCode <= 149) category = 'isuzu';
    else if (numericCode >= 150 && numericCode <= 199) category = 'nissan';
    else category = 'other';
  }
  if (!category) category = 'other';

  let driver = clean
    .replace(/(خاور|بنز|هیوندای|هیوندا|هيوندا|هیوند|هیوتدا|ایسوزو|ايسوزو|نیسان|نيسان|پژو|موتور)/g, ' ')
    .replace(/کد/g, ' ')
    .replace(/\d+/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();

  if (driver === 'بدون راننده') {
    driver = '';
  }

  const categoryLabels: Record<string, string> = {
    khavar: 'خاور',
    hyundai: 'هیوندای',
    isuzu: 'ایسوزو',
    nissan: 'نیسان',
    other: 'خودرو',
  };

  const formattedName = clean || `${categoryLabels[category] || 'خودرو'} کد ${vehicleCode}`;

  return {
    category,
    vehicleCode,
    driverName: driver,
    formattedName,
  };
}

async function callApi(
  endpoint: string,
  params: Record<string, any> = {},
  options = { authRetry: 0, rateRetry: 0 }
): Promise<any> {
  const url = new URL(`${API_BASE}/api/${endpoint}`);
  for (const [key, value] of Object.entries(params)) {
    url.searchParams.set(key, String(value));
  }

  const execute = async () => {
    const wait = Math.max(0, lastApiRequestFinishedAt + API_MIN_INTERVAL_MS - Date.now());
    if (wait) await sleep(wait);
    try {
      const response = await fetch(url, {
        method: 'GET',
        headers: { Accept: 'application/json' },
        signal: AbortSignal.timeout(15000),
      });
      if (!response.ok) {
        const err: any = new Error(`GPS provider returned HTTP ${response.status}`);
        err.httpStatus = response.status;
        throw err;
      }
      const data: any = await response.json();
      if (typeof data.code === 'number' && data.code !== 0) {
        const err: any = new Error(data.message || `GPS API error ${data.code}`);
        err.apiCode = data.code;
        throw err;
      }
      return data;
    } finally {
      lastApiRequestFinishedAt = Date.now();
    }
  };

  const task = apiQueue.then(execute, execute);
  apiQueue = task.then(
    () => undefined,
    () => undefined
  );

  try {
    return await task;
  } catch (err: any) {
    const code = err?.apiCode;
    const status = err?.httpStatus;
    if ([10010, 10011, 10012].includes(code) && params.access_token && options.authRetry < 1) {
      if (tokenCache.value === params.access_token) tokenCache = { value: '', expiresAt: 0 };
      const freshToken = await getToken();
      return callApi(
        endpoint,
        { ...params, access_token: freshToken },
        { ...options, authRetry: options.authRetry + 1 }
      );
    }
    const transient =
      code === 10009 ||
      status === 429 ||
      status >= 500 ||
      err?.name === 'AbortError' ||
      err?.name === 'TypeError';
    if (transient && options.rateRetry < 2) {
      await sleep(options.rateRetry === 0 ? 1500 : 3500);
      return callApi(endpoint, params, { ...options, rateRetry: options.rateRetry + 1 });
    }
    throw err;
  }
}

async function getToken(): Promise<string> {
  if (tokenCache.value && Date.now() < tokenCache.expiresAt) return tokenCache.value;
  if (tokenRefreshPromise) return tokenRefreshPromise;
  if (!ACCOUNT || !PASSWORD) throw new Error('حساب یا رمز عبور Open API تنظیم نشده است.');

  tokenRefreshPromise = (async () => {
    const time = Math.floor(Date.now() / 1000);
    const signature = md5(md5(PASSWORD) + String(time));
    const data = await callApi('authorization', { time, account: ACCOUNT, signature });
    if (!data.record?.access_token) throw new Error('پاسخ توکن از سرویس GPS دریافت نشد.');
    const ttlSeconds = Number(data.record.expires_in || 7200);
    const refreshAfter = Math.max(300, Math.min(ttlSeconds - 60, 90 * 60));
    tokenCache = { value: data.record.access_token, expiresAt: Date.now() + refreshAfter * 1000 };
    return tokenCache.value;
  })();

  try {
    return await tokenRefreshPromise;
  } finally {
    tokenRefreshPromise = null;
  }
}

async function getDevices(token: string): Promise<any[]> {
  const cacheKey = `devices:${DEVICE_ACCOUNT || ACCOUNT}`;
  return cached(cacheKey, 60_000, async () => {
    const params: Record<string, string> = { access_token: token };
    if (DEVICE_ACCOUNT) params.account = DEVICE_ACCOUNT;
    const data = await callApi('device/list', params);
    return Array.isArray(data.record) ? data.record.filter((d: any) => d && d.imei) : [];
  });
}

function mapDevice(device: any, record: any, meta: any) {
  const lat = record?.latitude == null || record.latitude === '' ? NaN : Number(record.latitude);
  const lon = record?.longitude == null || record.longitude === '' ? NaN : Number(record.longitude);
  const valid =
    Number.isFinite(lat) &&
    Math.abs(lat) > 0.01 &&
    Math.abs(lat) <= 90 &&
    Number.isFinite(lon) &&
    Math.abs(lon) > 0.01 &&
    Math.abs(lon) <= 180;

  const gpsTime = Number(record?.gpstime || record?.hearttime || record?.systemtime || 0);
  const mileage = Number(record?.mileage);
  const todayMileage = Number(record?.todaymileage);
  const fuel = record?.fuel == null || record.fuel === '' ? NaN : Number(record.fuel);
  const rawSpeed = Number(record?.speed ?? 0);
  const speedKph = Number.isFinite(rawSpeed) && rawSpeed > 0 ? Math.round(rawSpeed) : 0;
  const heading =
    Number.isFinite(Number(record?.course)) && Number(record?.course) >= 0
      ? Number(record.course)
      : 0;
  const battery =
    Number.isFinite(Number(record?.battery)) && Number(record?.battery) >= 0
      ? Number(record.battery)
      : undefined;
  const dataStatus = Number(record?.datastatus ?? 0);
  const accStatus = Number(record?.accstatus ?? -1);

  const parsed = parseDeviceDetails(device.devicename, device.imei);
  const category = validCategory(meta.category) || parsed.category;
  const vehicleCode = String(meta.vehicleCode || parsed.vehicleCode || device.imei);
  const driverName = meta.driverName !== undefined ? String(meta.driverName) : parsed.driverName;
  const name = String(
    meta.name || parsed.formattedName || device.devicename || device.platenumber || device.imei
  );
  const plateNumber = String(meta.plateNumber || device.platenumber || '').trim();

  const speedingPenalty = speedKph > 100 ? 14 : speedKph > 85 ? 5 : 0;
  const computedScore =
    meta.driverScore != null ? Number(meta.driverScore) : Math.max(72, 98 - speedingPenalty);

  return {
    id: String(device.imei),
    imei: String(device.imei),
    vehicleCode,
    name,
    driverName,
    category,
    latitude: valid ? lat : 0,
    longitude: valid ? lon : 0,
    hasValidGps: valid,
    speedKph,
    heading,
    online: dataStatus === 2,
    deviceStatus: dataStatus,
    lastSeen: gpsTime > 0 ? gpsTime * 1000 : null,
    plateNumber,
    deviceType: String(device.devicetype || ''),
    odometerKm: Number.isFinite(mileage) && mileage > 0 ? Math.round(mileage / 1000) : undefined,
    distanceTodayKm:
      Number.isFinite(todayMileage) && todayMileage > 0
        ? Number((todayMileage / 1000).toFixed(1))
        : undefined,
    fuelLiters: Number.isFinite(fuel) && fuel >= 0 ? fuel : undefined,
    externalPower: record?.externalpower ? String(record.externalpower) : undefined,
    batteryPercent: battery,
    accStatus: accStatus === 1 ? true : accStatus === 0 ? false : undefined,
    nextServiceKm: meta.nextServiceKm != null ? Number(meta.nextServiceKm) : undefined,
    driverScore: driverName ? computedScore : undefined,
  };
}

async function getProtrackVehicles() {
  if (!ACCOUNT || !PASSWORD) throw new Error('اطلاعات حساب Protrack در سرور تنظیم نشده است.');
  const token = await getToken();
  const devices = await getDevices(token);
  const meta = readMeta();
  const output: any[] = [];

  for (let i = 0; i < devices.length; i += 100) {
    const batch = devices.slice(i, i + 100);
    const data = await callApi('track', {
      access_token: token,
      imeis: batch.map((d: any) => d.imei).join(','),
    });
    const records = Array.isArray(data.record) ? data.record : [];
    const byImei = new Map(records.map((r: any) => [String(r.imei), r]));

    for (const d of batch) {
      const m = meta[String(d.imei)] || {};
      const item = mapDevice(d, byImei.get(String(d.imei)), m);
      if (item.hasValidGps) {
        output.push(item);
      }
    }
  }

  output.sort((a, b) => {
    const numA = Number(a.vehicleCode);
    const numB = Number(b.vehicleCode);
    if (Number.isFinite(numA) && Number.isFinite(numB)) return numA - numB;
    return a.name.localeCompare(b.name, 'fa');
  });

  return {
    vehicles: output,
    totalAuthorizedDevices: devices.length,
    locatedCount: output.length,
    serverTime: Date.now(),
  };
}

function tehranDayBounds(dateText: string) {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(dateText)) throw new Error('قالب تاریخ باید YYYY-MM-DD باشد.');
  const start = Date.parse(`${dateText}T00:00:00+03:30`);
  if (!Number.isFinite(start)) throw new Error('تاریخ نامعتبر است.');
  return { begin: Math.floor(start / 1000), end: Math.floor((start + 86400000) / 1000) };
}

function parsePlayback(record: unknown) {
  if (typeof record !== 'string' || !record.trim()) return [];
  return record
    .split(';')
    .map((s) => s.split(','))
    .filter((p) => p.length >= 5)
    .map((p) => ({
      longitude: Number(p[0]),
      latitude: Number(p[1]),
      timestamp: Number(p[2]),
      speedKph: Math.max(0, Number(p[3]) || 0),
      heading: Number(p[4]) || 0,
    }))
    .filter(
      (p) =>
        Number.isFinite(p.timestamp) &&
        Number.isFinite(p.latitude) &&
        Number.isFinite(p.longitude) &&
        Math.abs(p.latitude) > 0.01 &&
        Math.abs(p.longitude) > 0.01
    );
}

function distanceMeters(lat1: number, lon1: number, lat2: number, lon2: number): number {
  const R = 6371000;
  const rad = (n: number) => (n * Math.PI) / 180;
  const dLat = rad(lat2 - lat1);
  const dLon = rad(lon2 - lon1);
  const a =
    Math.sin(dLat / 2) ** 2 +
    Math.cos(rad(lat1)) * Math.cos(rad(lat2)) * Math.sin(dLon / 2) ** 2;
  return 2 * R * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
}

async function getPlaybackForDevice(
  token: string,
  imei: string,
  begin: number,
  end: number
) {
  const out: Array<{
    longitude: number;
    latitude: number;
    timestamp: number;
    speedKph: number;
    heading: number;
  }> = [];
  let cursor = begin;
  for (let page = 0; page < 15 && cursor < end; page++) {
    const data = await callApi('playback', {
      access_token: token,
      imei,
      begintime: cursor,
      endtime: end,
    });
    const records = parsePlayback(data.record);
    out.push(...records);
    if (records.length < 1000) break;
    const next = records[records.length - 1].timestamp;
    if (!Number.isFinite(next) || next <= cursor) break;
    cursor = next;
  }
  const seen = new Set<string>();
  return out
    .filter((p) => {
      const k = `${p.timestamp}:${p.latitude}:${p.longitude}`;
      if (seen.has(k)) return false;
      seen.add(k);
      return p.timestamp >= begin && p.timestamp <= end;
    })
    .sort((a, b) => a.timestamp - b.timestamp);
}

async function mapLimit<T, R>(
  values: T[],
  limit: number,
  fn: (val: T, index: number) => Promise<R>
): Promise<R[]> {
  const out = new Array<R>(values.length);
  let next = 0;
  const workers = Array.from({ length: Math.min(limit, values.length) }, async () => {
    while (true) {
      const i = next++;
      if (i >= values.length) return;
      out[i] = await fn(values[i], i);
    }
  });
  await Promise.all(workers);
  return out;
}

async function getPlaybackRoute(imei: string, dateText: string) {
  const { begin, end } = tehranDayBounds(dateText);
  const token = await getToken();
  const devices = await getDevices(token);
  if (!devices.some((d: any) => String(d.imei) === String(imei))) {
    throw new Error('شناسه دستگاه (IMEI) در فهرست مجاز این حساب وجود ندارد.');
  }
  const rawPoints = await getPlaybackForDevice(token, String(imei), begin, end);
  const points = rawPoints.map((p) => ({
    latitude: p.latitude,
    longitude: p.longitude,
    timestamp: p.timestamp * 1000,
    speedKph: p.speedKph,
    heading: p.heading,
  }));

  let totalDistMeters = 0;
  let maxSpeedKph = 0;
  const stops: any[] = [];
  let stopStart: (typeof points)[number] | null = null;

  for (let i = 0; i < points.length; i++) {
    const pt = points[i];
    if (pt.speedKph > maxSpeedKph) maxSpeedKph = pt.speedKph;
    if (i > 0) {
      const d = distanceMeters(
        points[i - 1].latitude,
        points[i - 1].longitude,
        pt.latitude,
        pt.longitude
      );
      if (d < 50000) totalDistMeters += d;
    }
    if (pt.speedKph === 0) {
      if (!stopStart) stopStart = pt;
    } else if (stopStart) {
      const durMin = Math.round((pt.timestamp - stopStart.timestamp) / 60000);
      if (durMin >= 5) {
        stops.push({
          latitude: stopStart.latitude,
          longitude: stopStart.longitude,
          startTime: stopStart.timestamp,
          endTime: pt.timestamp,
          durationMinutes: durMin,
        });
      }
      stopStart = null;
    }
  }

  return {
    points,
    stats: {
      pointCount: points.length,
      distanceKm: Number((totalDistMeters / 1000).toFixed(2)),
      maxSpeedKph,
      stopCount: stops.length,
    },
    stops: stops.slice(0, 25),
  };
}

async function getDailyStatus(dateText: string) {
  const { begin, end } = tehranDayBounds(dateText);
  const token = await getToken();
  const devices = await getDevices(token);
  const sampleDevices = devices.slice(0, 24);
  const perDevice = await mapLimit(sampleDevices, 4, async (d: any) => {
    try {
      return await getPlaybackForDevice(token, String(d.imei), begin, end);
    } catch (err: any) {
      if (err?.apiCode === 20046 || /expired/i.test(err?.message || '')) return [];
      return [];
    }
  });

  const buckets = Array.from({ length: 24 }, (_, hour) => ({
    hour: `${String(hour).padStart(2, '0')}:00`,
    moving: 0,
    stopped: 0,
    offline: 0,
    unknown: 0,
  }));

  for (const points of perDevice) {
    const latestByHour = new Map<number, any>();
    for (const p of points) {
      const hour =
        Number(
          new Intl.DateTimeFormat('en-GB', {
            timeZone: 'Asia/Tehran',
            hour: '2-digit',
            hour12: false,
          }).format(new Date(p.timestamp * 1000))
        ) % 24;
      const prior = latestByHour.get(hour);
      if (!prior || p.timestamp > prior.timestamp) latestByHour.set(hour, p);
    }
    for (let hour = 0; hour < 24; hour++) {
      const point = latestByHour.get(hour);
      if (!point) buckets[hour].unknown++;
      else if (point.speedKph > 0) buckets[hour].moving++;
      else buckets[hour].stopped++;
    }
  }

  return { date: dateText, dailyStatus: buckets, deviceCount: sampleDevices.length };
}

async function getAlerts(dateText: string) {
  const fleetData = await cached('vehicles:live', 15_000, getProtrackVehicles);
  const vehicles = fleetData.vehicles || [];
  const zones = readGeofences();
  const alerts: any[] = [];

  for (const v of vehicles) {
    if (v.online && v.speedKph >= 85) {
      alerts.push({
        id: `spd-${v.id}`,
        vehicleId: v.id,
        kind: 'speeding',
        title: `سرعت بالا (${v.speedKph} km/h)`,
        description: `${v.name} ${v.driverName ? `· راننده: ${v.driverName}` : ''}`,
        occurredAt: v.lastSeen || Date.now(),
        severity: v.speedKph >= 100 ? 'high' : 'medium',
      });
    }
    if (!v.online) {
      alerts.push({
        id: `off-${v.id}`,
        vehicleId: v.id,
        kind: 'offline',
        title: 'عدم ارسال موقعیت زنده (آفلاین)',
        description: `${v.name} · پلاک ${v.plateNumber || 'ثبت‌نشده'}`,
        occurredAt: v.lastSeen || Date.now(),
        severity: 'medium',
      });
    }
    for (const z of zones) {
      if (z.active !== false && z.radiusMeters > 0) {
        const dist = distanceMeters(v.latitude, v.longitude, z.latitude, z.longitude);
        if (dist <= z.radiusMeters) {
          alerts.push({
            id: `zone-${v.id}-${z.id}`,
            vehicleId: v.id,
            kind: 'geofence',
            title: `حضور در ${z.name}`,
            description: `${v.name} · فاصله از مرکز: ${Math.round(dist)} متر`,
            occurredAt: v.lastSeen || Date.now(),
            severity: 'low',
          });
        }
      }
    }
  }

  const maintenanceStatuses = computeMaintenanceStatus(vehicles);
  for (const ms of maintenanceStatuses) {
    for (const s of ms.services) {
      if (s.status === 'overdue') {
        const reason = s.isKmOverdue
          ? `${numberFa(Math.abs(s.kmRemaining))} کیلومتر از حد مجاز گذشته است`
          : `${numberFa(Math.abs(s.daysRemaining))} روز از سررسید زمانی گذشته است`;
        alerts.push({
          id: `maint-overdue-${ms.vehicleId}-${s.serviceType}`,
          vehicleId: ms.vehicleId,
          kind: 'maintenance',
          title: `سررسید تعویض فوری: ${s.title}`,
          description: `${ms.vehicleName} · ${reason}`,
          occurredAt: Date.now(),
          severity: 'high',
        });
      } else if (s.status === 'due_soon') {
        alerts.push({
          id: `maint-due-${ms.vehicleId}-${s.serviceType}`,
          vehicleId: ms.vehicleId,
          kind: 'maintenance',
          title: `نزدیک به موعد سررسید: ${s.title}`,
          description: `${ms.vehicleName} · ${numberFa(s.kmRemaining)} km / ${numberFa(s.daysRemaining)} روز مانده`,
          occurredAt: Date.now(),
          severity: 'medium',
        });
      }
    }
  }

  const weight: Record<string, number> = { high: 3, medium: 2, low: 1 };
  alerts.sort(
    (a, b) =>
      (weight[b.severity || 'low'] - weight[a.severity || 'low']) ||
      ((b.occurredAt || 0) - (a.occurredAt || 0))
  );

  return { alerts, date: dateText };
}

async function startServer() {
  const app = express();
  app.use(express.json());

  app.get('/api/health', (_req, res) => {
    res.status(ACCOUNT && PASSWORD ? 200 : 503).json({
      ok: Boolean(ACCOUNT && PASSWORD),
      mode: 'protrack',
      appName: 'حامی (Hami GPS)',
    });
  });

  app.get('/api/vehicles', async (_req, res) => {
    try {
      const data = await cached('vehicles:live', 15_000, getProtrackVehicles);
      const missions = readMissions();
      const activeMissions = missions.filter((m) => m.status !== 'completed');
      const enriched = (data?.vehicles || []).map((v: any) => {
        const m = activeMissions.find(
          (mission) =>
            String(mission.vehicleId) === String(v.id) ||
            (mission.vehicleCode && String(mission.vehicleCode) === String(v.vehicleCode))
        );
        if (!m) {
          return {
            ...v,
            hasActiveWaybill: false,
            waybillStatus: null,
            tripProgressPercent: undefined,
            activeMission: null,
          };
        }
        const liveMission = computeLiveMission(m, v);
        return {
          ...v,
          hasActiveWaybill: true,
          waybillStatus: m.status,
          waybillNumber: m.waybillNumber,
          tripProgressPercent: liveMission.progressPercent,
          activeMission: liveMission,
        };
      });
      res.json({ ...data, vehicles: enriched });
    } catch (err: any) {
      console.error('Protrack vehicles error:', err?.message);
      res.status(502).json({
        error: 'ارتباط با سامانه GPS ایران‌اسمارت / Protrack برقرار نشد. تنظیمات سرور را بررسی کنید.',
      });
    }
  });

  app.get('/api/playback', async (req, res) => {
    try {
      const imei = String(req.query.imei || '');
      const dateText =
        String(req.query.date || '') ||
        new Date().toLocaleDateString('en-CA', { timeZone: 'Asia/Tehran' });
      if (!imei) return res.status(400).json({ error: 'شناسه IMEI الزامی است.' });
      const data = await cached(`route:${imei}:${dateText}`, 5 * 60_000, () =>
        getPlaybackRoute(imei, dateText)
      );
      res.json(data);
    } catch (err: any) {
      console.error('Playback error:', err?.message);
      res.status(502).json({ error: 'دریافت تاریخچه مسیر از سرور GPS ناموفق بود.' });
    }
  });

  app.get('/api/daily-status', async (req, res) => {
    try {
      const dateText =
        String(req.query.date || '') ||
        new Date().toLocaleDateString('en-CA', { timeZone: 'Asia/Tehran' });
      const data = await cached(`daily:${dateText}`, 15 * 60_000, () => getDailyStatus(dateText));
      res.json(data);
    } catch (err: any) {
      console.error('Daily status error:', err?.message);
      res.status(502).json({ error: 'دریافت گزارش ساعتی ناوگان ناموفق بود.' });
    }
  });

  app.get('/api/alerts', async (req, res) => {
    try {
      const dateText =
        String(req.query.date || '') ||
        new Date().toLocaleDateString('en-CA', { timeZone: 'Asia/Tehran' });
      const data = await cached(`alerts:${dateText}`, 30_000, () => getAlerts(dateText));
      res.json(data);
    } catch (err: any) {
      console.error('Alerts error:', err?.message);
      res.status(502).json({ error: 'دریافت هشدارهای ناوگان ناموفق بود.' });
    }
  });

  app.post('/api/vehicle-meta', (req, res) => {
    try {
      const {
        imei,
        name,
        driverName,
        vehicleCode,
        category,
        plateNumber,
        nextServiceKm,
        driverScore,
      } = req.body || {};
      if (!imei) return res.status(400).json({ error: 'شناسه IMEI الزامی است.' });
      const meta = readMeta();
      meta[String(imei)] = {
        ...meta[String(imei)],
        ...(name !== undefined ? { name: String(name).trim() } : {}),
        ...(driverName !== undefined ? { driverName: String(driverName).trim() } : {}),
        ...(vehicleCode !== undefined ? { vehicleCode: String(vehicleCode).trim() } : {}),
        ...(category !== undefined ? { category } : {}),
        ...(plateNumber !== undefined ? { plateNumber: String(plateNumber).trim() } : {}),
        ...(nextServiceKm !== undefined
          ? {
              nextServiceKm:
                nextServiceKm === '' || nextServiceKm === null
                  ? undefined
                  : Number(nextServiceKm),
            }
          : {}),
        ...(driverScore !== undefined
          ? {
              driverScore:
                driverScore === '' || driverScore === null ? undefined : Number(driverScore),
            }
          : {}),
      };
      writeMeta(meta);
      responseCache.delete('vehicles:live');
      res.json({ ok: true, meta: meta[String(imei)] });
    } catch {
      res.status(500).json({ error: 'ذخیره مشخصات خودرو ناموفق بود.' });
    }
  });

  app.get('/api/geofences', (_req, res) => {
    res.json({ geofences: readGeofences() });
  });

  app.post('/api/geofences', (req, res) => {
    const zones = req.body?.geofences;
    if (!Array.isArray(zones)) return res.status(400).json({ error: 'لیست محدوده‌ها معتبر نیست.' });
    writeGeofences(zones);
    res.json({ ok: true, geofences: zones });
  });

  // Maintenance Rules API (قوانین و لیمیت‌های سرعتی، کیلومتری و روزانه)
  app.get('/api/maintenance/rules', (_req, res) => {
    res.json({ rules: readMaintenanceRules() });
  });

  app.post('/api/maintenance/rules', (req, res) => {
    try {
      const rule = req.body;
      if (!rule || !rule.title || !rule.serviceType) {
        return res.status(400).json({ error: 'عنوان و نوع سرویس الزامی است.' });
      }
      const rules = readMaintenanceRules();
      const existingIdx = rules.findIndex((r) => r.id === rule.id);
      const ruleObj = {
        id: rule.id || `rule-${Date.now()}`,
        serviceType: rule.serviceType,
        title: String(rule.title).trim(),
        scope: rule.scope || 'all',
        category: rule.category || undefined,
        vehicleId: rule.vehicleId || undefined,
        kmInterval: Math.max(500, Number(rule.kmInterval) || 5000),
        daysInterval: Math.max(7, Number(rule.daysInterval) || 90),
        warningKmLead: Math.max(50, Number(rule.warningKmLead) || 500),
        warningDaysLead: Math.max(1, Number(rule.warningDaysLead) || 10),
        createdAt: rule.createdAt || Date.now(),
      };
      if (existingIdx >= 0) {
        rules[existingIdx] = ruleObj;
      } else {
        rules.unshift(ruleObj);
      }
      writeMaintenanceRules(rules);
      responseCache.delete('vehicles:live');
      res.json({ ok: true, rule: ruleObj });
    } catch {
      res.status(500).json({ error: 'ذخیره قانون سرویس ناموفق بود.' });
    }
  });

  app.delete('/api/maintenance/rules/:id', (req, res) => {
    try {
      const { id } = req.params;
      const rules = readMaintenanceRules().filter((r) => r.id !== id);
      writeMaintenanceRules(rules);
      res.json({ ok: true, rules });
    } catch {
      res.status(500).json({ error: 'حذف قانون ناموفق بود.' });
    }
  });

  // Service Logs / Oil Change Entries API (سوابق تعویض روغن و سرویس)
  app.get('/api/maintenance/logs', (req, res) => {
    const logs = readServiceLogs();
    const vehicleId = req.query.vehicleId ? String(req.query.vehicleId) : null;
    const filtered = vehicleId ? logs.filter((l) => String(l.vehicleId) === vehicleId) : logs;
    res.json({ logs: filtered });
  });

  app.post('/api/maintenance/logs', (req, res) => {
    try {
      const {
        vehicleId,
        vehicleName,
        serviceType,
        title,
        serviceKm,
        serviceDate,
        oilBrand,
        workshopName,
        technicianName,
        costToman,
        notes,
      } = req.body || {};

      if (!vehicleId || !serviceType) {
        return res.status(400).json({ error: 'شناسه خودرو و نوع سرویس الزامی است.' });
      }

      const logs = readServiceLogs();
      const newLog = {
        id: `log-${Date.now()}`,
        vehicleId: String(vehicleId),
        vehicleName: String(vehicleName || ''),
        serviceType: String(serviceType),
        title: String(title || 'تعویض روغن و سرویس'),
        serviceKm: Number(serviceKm) || 0,
        serviceDate:
          String(serviceDate || '') ||
          new Date().toLocaleDateString('en-CA', { timeZone: 'Asia/Tehran' }),
        oilBrand: oilBrand ? String(oilBrand).trim() : undefined,
        workshopName: workshopName ? String(workshopName).trim() : undefined,
        technicianName: technicianName ? String(technicianName).trim() : undefined,
        costToman: costToman != null ? Number(costToman) : undefined,
        notes: notes ? String(notes).trim() : undefined,
        createdAt: Date.now(),
      };

      logs.unshift(newLog);
      writeServiceLogs(logs);

      // Invalidate live vehicles cache so fresh service stats compute immediately
      responseCache.delete('vehicles:live');
      res.json({ ok: true, log: newLog });
    } catch {
      res.status(500).json({ error: 'ثبت سرویس ناموفق بود.' });
    }
  });

  // Live Computed Maintenance Status across all fleet vehicles
  app.get('/api/maintenance/status', async (_req, res) => {
    try {
      let vehicles: any[] = [];
      try {
        const fleetData = await cached('vehicles:live', 20_000, getProtrackVehicles);
        vehicles = Array.isArray(fleetData?.vehicles) ? fleetData.vehicles : [];
      } catch {
        const cachedHit = responseCache.get('vehicles:live');
        if (Array.isArray(cachedHit?.value?.vehicles) && cachedHit.value.vehicles.length > 0) {
          vehicles = cachedHit.value.vehicles;
        } else {
          const meta = readMeta();
          vehicles = Object.keys(meta).map((imei) => {
            const m = meta[imei] || {};
            return {
              id: imei,
              name: m.name || `خودرو ${m.code || imei}`,
              vehicleCode: m.code || '',
              driverName: m.driver || '',
              category: m.category || 'other',
              plateNumber: m.plate || '',
              odometerKm: m.odometerKm || 50000,
              speedKph: 0,
              hasValidGps: true,
            };
          });
        }
      }
      const statusList = computeMaintenanceStatus(vehicles);
      res.json({
        statuses: statusList,
        totalVehicles: statusList.length,
        overdueCount: statusList.filter((s) => s.overallStatus === 'overdue').length,
        dueSoonCount: statusList.filter((s) => s.overallStatus === 'due_soon').length,
      });
    } catch {
      res.json({
        statuses: [],
        totalVehicles: 0,
        overdueCount: 0,
        dueSoonCount: 0,
      });
    }
  });

  // Missions & Waybills API (مدیریت بارنامه، رانندگان و وضعیت سفر)
  app.get('/api/missions', async (_req, res) => {
    try {
      let vehicles: any[] = [];
      try {
        const fleetData = await cached('vehicles:live', 20_000, getProtrackVehicles);
        vehicles = Array.isArray(fleetData?.vehicles) ? fleetData.vehicles : [];
      } catch {
        const cachedHit = responseCache.get('vehicles:live');
        vehicles = Array.isArray(cachedHit?.value?.vehicles) ? cachedHit.value.vehicles : [];
      }
      const byId = new Map(vehicles.map((v) => [String(v.id), v]));
      const byCode = new Map(vehicles.map((v) => [String(v.vehicleCode), v]));

      const missions = readMissions();
      const enriched = missions.map((m) => {
        const v = byId.get(String(m.vehicleId)) || byCode.get(String(m.vehicleCode));
        return computeLiveMission(m, v);
      });

      res.json({
        missions: enriched,
        totalMissions: enriched.length,
        activeCount: enriched.filter((m) => m.status !== 'completed').length,
        inTransitCount: enriched.filter((m) => m.status === 'in_transit').length,
        loadingCount: enriched.filter((m) => m.status === 'loading').length,
        unloadedCount: enriched.filter((m) => m.status === 'unloaded').length,
      });
    } catch {
      res.json({
        missions: readMissions(),
        totalMissions: 0,
        activeCount: 0,
        inTransitCount: 0,
        loadingCount: 0,
        unloadedCount: 0,
      });
    }
  });

  app.post('/api/missions', (req, res) => {
    try {
      const data = req.body || {};
      if (!data.waybillNumber || !data.cargoTitle) {
        return res.status(400).json({ error: 'شماره بارنامه و شرح محموله الزامی است.' });
      }
      const missions = readMissions();
      const existingIdx = missions.findIndex(
        (m) => m.id === data.id || m.waybillNumber === data.waybillNumber
      );

      const newMission = {
        id: data.id || `mission-${Date.now()}`,
        waybillNumber: String(data.waybillNumber).trim(),
        vehicleId: String(data.vehicleId || ''),
        vehicleCode: String(data.vehicleCode || '').trim(),
        vehicleName: String(data.vehicleName || `خودرو کد ${data.vehicleCode || ''}`).trim(),
        category: data.category || 'other',
        plateNumber: data.plateNumber ? String(data.plateNumber).trim() : undefined,
        driverId: data.driverId || `drv-${Date.now()}`,
        driverName: String(data.driverName || 'راننده تعیین‌نشده').trim(),
        driverPhone: data.driverPhone ? String(data.driverPhone).trim() : undefined,
        cargoTitle: String(data.cargoTitle).trim(),
        weightTons: Number(data.weightTons) || 1,
        origin: data.origin || {
          title: 'پایانه مرکزی حامی (فتح)',
          latitude: 35.6672,
          longitude: 51.2985,
        },
        destination: data.destination || {
          title: 'مقصد تحویل',
          latitude: 35.7,
          longitude: 51.34,
        },
        totalDistanceKm: Number(data.totalDistanceKm) || 45,
        currentDistanceCoveredKm: Number(data.currentDistanceCoveredKm) || 0,
        progressPercent: Number(data.progressPercent) || 0,
        status: data.status || 'loading',
        startedAt: data.startedAt || new Date().toISOString(),
        notes: data.notes ? String(data.notes).trim() : undefined,
        createdAt: data.createdAt || Date.now(),
      };

      if (existingIdx >= 0) {
        missions[existingIdx] = newMission;
      } else {
        missions.unshift(newMission);
      }
      writeMissions(missions);

      // Synchronize driver and vehicle metadata into vehicle-meta.json
      if (newMission.vehicleId || newMission.vehicleCode) {
        const meta = readMeta();
        const targetImei = newMission.vehicleId;
        if (targetImei) {
          meta[targetImei] = {
            ...meta[targetImei],
            driverName: newMission.driverName,
            driver: newMission.driverName,
            ...(newMission.driverPhone ? { driverPhone: newMission.driverPhone } : {}),
            ...(newMission.vehicleCode
              ? { vehicleCode: newMission.vehicleCode, code: newMission.vehicleCode }
              : {}),
            ...(newMission.plateNumber
              ? { plateNumber: newMission.plateNumber, plate: newMission.plateNumber }
              : {}),
          };
          writeMeta(meta);
        }
      }

      responseCache.delete('vehicles:live');
      res.json({ ok: true, mission: newMission });
    } catch {
      res.status(500).json({ error: 'ثبت بارنامه ناموفق بود.' });
    }
  });

  app.patch('/api/missions/:id/status', (req, res) => {
    try {
      const { id } = req.params;
      const { status } = req.body || {};
      if (!['loading', 'in_transit', 'unloaded', 'completed'].includes(status)) {
        return res.status(400).json({ error: 'وضعیت مأموریت معتبر نیست.' });
      }
      const missions = readMissions();
      const mission = missions.find((m) => m.id === id);
      if (!mission) {
        return res.status(404).json({ error: 'بارنامه یافت نشد.' });
      }
      mission.status = status;
      if (status === 'completed') {
        mission.completedAt = new Date().toISOString();
        mission.progressPercent = 100;
      } else if (status === 'unloaded') {
        mission.progressPercent = 100;
      }
      writeMissions(missions);
      responseCache.delete('vehicles:live');
      res.json({ ok: true, mission });
    } catch {
      res.status(500).json({ error: 'تغییر وضعیت مأموریت ناموفق بود.' });
    }
  });

  app.delete('/api/missions/:id', (req, res) => {
    try {
      const { id } = req.params;
      const missions = readMissions().filter((m) => m.id !== id);
      writeMissions(missions);
      responseCache.delete('vehicles:live');
      res.json({ ok: true });
    } catch {
      res.status(500).json({ error: 'حذف مأموریت ناموفق بود.' });
    }
  });

  // Driver and Vehicle Synchronizer API (همگام‌سازی پرسنل و ناوگان)
  app.post('/api/drivers/sync', (req, res) => {
    try {
      const { vehicleCode, imei, driverName, driverPhone, vehicleName } = req.body || {};
      if (!vehicleCode && !imei) {
        return res.status(400).json({ error: 'کد خودرو یا شناسه دستگاه الزامی است.' });
      }
      const meta = readMeta();
      let targetImei = imei ? String(imei) : '';
      if (!targetImei && vehicleCode) {
        for (const [key, val] of Object.entries(meta)) {
          if (
            (val as any).vehicleCode === String(vehicleCode) ||
            (val as any).code === String(vehicleCode)
          ) {
            targetImei = key;
            break;
          }
        }
      }
      if (targetImei) {
        meta[targetImei] = {
          ...meta[targetImei],
          ...(driverName
            ? { driverName: String(driverName).trim(), driver: String(driverName).trim() }
            : {}),
          ...(driverPhone ? { driverPhone: String(driverPhone).trim() } : {}),
          ...(vehicleCode
            ? { vehicleCode: String(vehicleCode).trim(), code: String(vehicleCode).trim() }
            : {}),
          ...(vehicleName ? { name: String(vehicleName).trim() } : {}),
        };
        writeMeta(meta);
      }

      const missions = readMissions();
      let updatedMission = false;
      for (const m of missions) {
        if (
          (vehicleCode && String(m.vehicleCode) === String(vehicleCode)) ||
          (targetImei && String(m.vehicleId) === String(targetImei))
        ) {
          if (driverName) m.driverName = String(driverName).trim();
          if (driverPhone) m.driverPhone = String(driverPhone).trim();
          updatedMission = true;
        }
      }
      if (updatedMission) writeMissions(missions);

      responseCache.delete('vehicles:live');
      res.json({ ok: true, synced: true, targetImei, driverName });
    } catch {
      res.status(500).json({ error: 'همگام‌سازی راننده ناموفق بود.' });
    }
  });

  // Fuel Management & Analysis API (تحلیل و ثبت میزان سوخت‌گیری و مراحل)
  app.get('/api/fuel/logs', (req, res) => {
    try {
      const logs = readFuelLogs();
      const vehicleId = req.query.vehicleId ? String(req.query.vehicleId) : null;
      const filtered = vehicleId ? logs.filter((l) => String(l.vehicleId) === vehicleId) : logs;
      res.json({ logs: filtered });
    } catch {
      res.json({ logs: [] });
    }
  });

  app.post('/api/fuel/logs', (req, res) => {
    try {
      const data = req.body || {};
      if (!data.vehicleId || !data.liters) {
        return res.status(400).json({ error: 'شناسه خودرو و حجم سوخت الزامی است.' });
      }
      const logs = readFuelLogs();
      const newLog = {
        id: `fuel-log-${Date.now()}`,
        vehicleId: String(data.vehicleId),
        vehicleName: String(data.vehicleName || ''),
        vehicleCode: String(data.vehicleCode || ''),
        category: data.category || 'other',
        plateNumber: data.plateNumber ? String(data.plateNumber).trim() : undefined,
        driverName: data.driverName ? String(data.driverName).trim() : undefined,
        date: String(data.date || new Date().toISOString().slice(0, 10)),
        time: String(data.time || new Date().toTimeString().slice(0, 5)),
        odometerKm: Number(data.odometerKm) || 0,
        liters: Number(data.liters) || 0,
        fuelType: data.fuelType || 'diesel',
        unitPriceToman: data.unitPriceToman != null ? Number(data.unitPriceToman) : 600,
        totalCostToman:
          data.totalCostToman != null
            ? Number(data.totalCostToman)
            : Math.round((Number(data.liters) || 0) * (Number(data.unitPriceToman) || 600)),
        gasStation: data.gasStation
          ? String(data.gasStation).trim()
          : 'جایگاه سوخت ناوگان حامی',
        fullTank: data.fullTank !== false,
        notes: data.notes ? String(data.notes).trim() : undefined,
        createdAt: Date.now(),
      };
      logs.unshift(newLog);
      writeFuelLogs(logs);
      responseCache.delete('vehicles:live');
      res.json({ ok: true, log: newLog });
    } catch {
      res.status(500).json({ error: 'ثبت سوخت‌گیری ناموفق بود.' });
    }
  });

  app.delete('/api/fuel/logs/:id', (req, res) => {
    try {
      const { id } = req.params;
      const logs = readFuelLogs().filter((l) => l.id !== id);
      writeFuelLogs(logs);
      responseCache.delete('vehicles:live');
      res.json({ ok: true });
    } catch {
      res.status(500).json({ error: 'حذف سابقه سوخت‌گیری ناموفق بود.' });
    }
  });

  app.get('/api/fuel/analytics', async (_req, res) => {
    try {
      let vehicles: any[] = [];
      try {
        const fleetData = await cached('vehicles:live', 20_000, getProtrackVehicles);
        vehicles = Array.isArray(fleetData?.vehicles) ? fleetData.vehicles : [];
      } catch {
        const cachedHit = responseCache.get('vehicles:live');
        vehicles = Array.isArray(cachedHit?.value?.vehicles) ? cachedHit.value.vehicles : [];
      }
      const analytics = computeFuelAnalytics(vehicles);
      res.json(analytics);
    } catch {
      res.json({
        fleetSummary: {
          totalLiters: 0,
          totalCostToman: 0,
          totalKmTracked: 0,
          fleetAvgConsumption: 14.5,
          totalLogsCount: 0,
          criticalCount: 0,
          dueSoonCount: 0,
          anomaliesCount: 0,
        },
        vehicleStats: [],
        stagesHistory: [],
      });
    }
  });

  app.get('/api/navigate', async (req, res) => {
    try {
      const fromLat = Number(req.query.fromLat);
      const fromLon = Number(req.query.fromLon);
      const toLat = Number(req.query.toLat);
      const toLon = Number(req.query.toLon);
      if (![fromLat, fromLon, toLat, toLon].every(Number.isFinite)) {
        return res.status(400).json({ error: 'مختصات مبدأ و مقصد معتبر نیست.' });
      }
      const key = `nav:${fromLat.toFixed(4)},${fromLon.toFixed(4)}:${toLat.toFixed(4)},${toLon.toFixed(4)}`;
      const result = await cached(key, 10 * 60_000, async () => {
        const osrmUrl = `https://router.project-osrm.org/route/v1/driving/${fromLon},${fromLat};${toLon},${toLat}?overview=full&geometries=geojson&steps=true`;
        const resp = await fetch(osrmUrl, {
          headers: { 'User-Agent': 'HamiGPSNavigator/2.0' },
          signal: AbortSignal.timeout(10000),
        });
        if (!resp.ok) throw new Error('OSRM service unavailable');
        const data: any = await resp.json();
        const route = data.routes?.[0];
        if (!route) throw new Error('مسیری بین این دو نقطه یافت نشد.');
        const coordinates = (route.geometry?.coordinates || []).map(
          ([lon, lat]: [number, number]) => [lat, lon]
        );
        const steps = (route.legs?.[0]?.steps || []).map((step: any) => ({
          name: step.name || 'مسیر اصلی',
          distanceMeters: Math.round(step.distance || 0),
          durationSeconds: Math.round(step.duration || 0),
          maneuverType: step.maneuver?.type || 'continue',
          maneuverModifier: step.maneuver?.modifier || 'straight',
          location: step.maneuver?.location
            ? [step.maneuver.location[1], step.maneuver.location[0]]
            : null,
        }));
        return {
          distanceKm: Number((route.distance / 1000).toFixed(2)),
          durationMinutes: Math.max(1, Math.round(route.duration / 60)),
          coordinates,
          steps,
        };
      });
      res.json(result);
    } catch {
      const fromLat = Number(req.query.fromLat);
      const fromLon = Number(req.query.fromLon);
      const toLat = Number(req.query.toLat);
      const toLon = Number(req.query.toLon);
      const directMeters = distanceMeters(fromLat, fromLon, toLat, toLon);
      const estRoadKm = Number(((directMeters * 1.28) / 1000).toFixed(2));
      res.json({
        distanceKm: estRoadKm,
        durationMinutes: Math.max(1, Math.round((estRoadKm / 55) * 60)),
        coordinates: [
          [fromLat, fromLon],
          [toLat, toLon],
        ],
        steps: [
          {
            name: 'پیمایش مستقیم به سمت مقصد',
            distanceMeters: Math.round(directMeters),
            durationSeconds: Math.round((estRoadKm / 55) * 3600),
            maneuverType: 'depart',
            maneuverModifier: 'straight',
            location: [fromLat, fromLon],
          },
        ],
      });
    }
  });

  app.get('/api/geocode', async (req, res) => {
    try {
      const q = String(req.query.q || '').trim();
      if (!q) return res.json({ results: [] });
      const data = await cached(`geo:${q}`, 30 * 60_000, async () => {
        const url = new URL('https://nominatim.openstreetmap.org/search');
        url.searchParams.set('q', q);
        url.searchParams.set('format', 'json');
        url.searchParams.set('accept-language', 'fa');
        url.searchParams.set('countrycodes', 'ir');
        url.searchParams.set('limit', '6');
        const resp = await fetch(url, {
          headers: { 'User-Agent': 'HamiGPSNavigator/2.0 (IranFleet)' },
          signal: AbortSignal.timeout(8000),
        });
        if (!resp.ok) return [];
        const items: any = await resp.json();
        return Array.isArray(items)
          ? items.map((item: any) => ({
              label: item.display_name,
              latitude: Number(item.lat),
              longitude: Number(item.lon),
            }))
          : [];
      });
      res.json({ results: data });
    } catch {
      res.json({ results: [] });
    }
  });

  app.get('/api/reverse-geocode', async (req, res) => {
    try {
      const lat = Number(req.query.lat);
      const lon = Number(req.query.lon);
      if (!Number.isFinite(lat) || !Number.isFinite(lon)) {
        return res.status(400).json({ error: 'Invalid coordinates' });
      }
      const key = `rev:${lat.toFixed(3)},${lon.toFixed(3)}`;
      const address = await cached(key, 60 * 60_000, async () => {
        const url = new URL('https://nominatim.openstreetmap.org/reverse');
        url.searchParams.set('lat', String(lat));
        url.searchParams.set('lon', String(lon));
        url.searchParams.set('format', 'json');
        url.searchParams.set('accept-language', 'fa');
        const resp = await fetch(url, {
          headers: { 'User-Agent': 'HamiGPSNavigator/2.0 (IranFleet)' },
          signal: AbortSignal.timeout(6000),
        });
        if (!resp.ok) return '';
        const data: any = await resp.json();
        return data.display_name || '';
      });
      res.json({ address });
    } catch {
      res.json({ address: '' });
    }
  });

  if (process.env.NODE_ENV !== 'production') {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(ROOT, 'dist');
    app.use(express.static(distPath));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Hami GPS Navigation & Protrack Server listening on http://0.0.0.0:${PORT}`);
  });
}

startServer();
